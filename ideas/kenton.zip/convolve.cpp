#include "../prompt.h"
#include "VCFix.h"
#include "convolve.h"
#include "pi.h"

#include <vector>

using namespace std;
using namespace my;


// TO DO:
// 1) Change all convolutions based on Gaussian to use Gaussian2D::cutoff to
//    size filter.


// class Convolution2D --------------------------------------------------------

Convolution2D::Convolution2D (const PixelFormat & format)
: Image (format)
{
}

Convolution2D::Convolution2D (const Image & image)
: Image (image)
{
}

Image
Convolution2D::filter (const Image & image)
{
  if (*format != *image.format)
  {
	if (format->precedence <= image.format->precedence)
	{
	  Convolution2D temp = (*this) * (*image.format);
	  return image * temp;
	}
	return filter (image * (*format));
  }

  int lastH = width - 1;
  int lastV = height - 1;

  if (*format == GrayFloat)
  {
	ImageOf<float> result (image.width - lastH, image.height - lastV, GrayFloat);
	ImageOf<float> that (image);

	//result.bias = max (bias, image.bias);
	//result.scale = min (scale, image.scale);

    for (int x = 0; x < result.width; x++)
    {
	  for (int y = 0; y < result.height; y++)
	  {
		float sum = 0;
		for (int h = 0; h <= lastH; h++)
	    {
		  for (int v = 0; v <= lastV; v++)
		  {
			sum += ((float *) buffer)[v * width + h] * that (x - h + lastH, y - v + lastV);
		  }
		}
		result (x, y) = sum;
	  }
	}

	return result;
  }
  else if (*format == GrayDouble)
  {
	ImageOf<double> result (image.width - lastH, image.height - lastV, GrayDouble);
	ImageOf<double> that (image);

	//result.bias = max (bias, image.bias);
	//result.scale = min (scale, image.scale);

    for (int x = 0; x < result.width; x++)
    {
	  for (int y = 0; y < result.height; y++)
	  {
		double sum = 0;
		for (int h = 0; h <= lastH; h++)
	    {
		  for (int v = 0; v <= lastV; v++)
		  {
			sum += ((double *) buffer)[v * width + h] * that (x - h + lastH, y - v + lastV);
		  }
		}
		result (x, y) = sum;
	  }
	}

	return result;
  }
  /*
  else if (*format == GrayChar)
  {
	result.bias = 128;  // May change this to be dynamic, based on statistics gathered during processing.
	result.scale = 128;

    // (x, y) iterate over the output image
    for (int x = 0; x < result.width; x++)
    {
	  for (int y = 0; y < result.height; y++)
	  {
		// h an v iterate over the differences (x - i, y - j).  Ie: suppose (i, j) iterates over the input
		// image, and that the standard form of a convolution is: Out(x,y) = sum_(i,j) K(x - i, y - j) * In(i,j).
		// Furthermore, the function vanishes outside the boundaries of the kernel.
		// We perform a change of variables:  h = x - i  and  v = y - j.  Then the convolution is:
		// Out(x,y) = sum_(h,v) K(h,v) * In(x - h, y - v).  In addition, we must compensate for the change
		// in image size due to the fact that the kernel can't go past the boundary of the source image.
		int sum = 0;
		for (int h = 0; h <= lastH; h++)
	    {
		  for (int v = 0; v <= lastV; v++)
		  {
			sum += (buffer[v * width + h] - bias) * (image.pixelGray8 (x - h + lastH, y - v + lastV) - image.bias);
		  }
		}
		sum *= result.scale;
		sum /= scale * image.scale;
		sum += result.bias;
        sum = min (sum, 255);
		sum = max (sum, 0);
		result.pixelGray8 (x, y) = sum;
	  }
	}
  }
  */
  else
  {
	throw "Convolution2D::filter: unimplemented format";
  }
}

//KenFix
#define max(a,b)  (a)>(b)? (a) : (b)
#define min(a,b)  (a)<(b)? (a) : (b)

double
Convolution2D::response (const Image & image, const Point & p) const
{
  if (*format != *image.format)
  {
	if (format->precedence <= image.format->precedence)
	{
	  Convolution2D temp = (*this) * (*image.format);
	  return temp.response (image, p);
	}
	return response (image * (*format), p);
  }

  int x = (int) rint (p.x);
  int y = (int) rint (p.y);

  int midX = width / 2;
  int midY = height / 2;
  int hh = midX + ((x < midX) ? x : midX);
  int hl = (image.width > (x + midX + 1) ? image.width : (x + midX + 1)) - image.width;
  int vh = midY + (y < midY ? y : midY);
  int vl = (image.height > (y + midY + 1) ? image.height : (y + midY + 1)) - image.height;

  if (*format == GrayFloat)
  {
	float result = 0;
	ImageOf<float> that (image);
	for (int h = hl; h <= hh; h++)
	{
	  for (int v = vl; v <= vh; v++)
	  {
		result += ((float *) buffer)[v * width + h] * that (x + midX - h, y + midY - v);
	  }
	}
	return result;
  }
  else if (*format == GrayDouble)
  {
	double result = 0;
	ImageOf<double> that (image);
	for (int h = hl; h <= hh; h++)
	{
	  for (int v = vl; v <= vh; v++)
	  {
		result += ((double *) buffer)[v * width + h] * that (x + midX - h, y + midY - v);
	  }
	}
	return result;
  }
  /*
  else if (*format == GrayChar)
  {
	int sum = 0;
	for (int h = hl; h <= hh; h++)
	{
	  for (int v = vl; v <= vh; v++)
	  {
		sum += (buffer[v * width + h] - bias) * (image.pixelGray8 (x + midX - h, y + midY - v) - image.bias);
	  }
	}
	result = (float) sum / (scale * image.scale);
  }
  */
  else
  {
	throw "Convolution2D::response: unimplemented format";
  }
}


// class Gaussian2D -----------------------------------------------------------

double Gaussian2D::cutoff = 4.0;

Gaussian2D::Gaussian2D (double sigma, const PixelFormat & format)
: Convolution2D (format)
{
  //bias = 0;
  //scale = 256;

  double sigma2 = sigma * sigma;

  const double C = 2 * PI * sigma2;
  int h = (int) rint (cutoff * sigma);  // "half" = distance from middle until cell values become insignificant
  int s = 2 * h + 1;  // "size" of kernel

  ImageOf<double> temp (s, s, GrayDouble);

  for (int row = 0; row < s; row++)
  {
	for (int column = 0; column < s; column++)
	{
	  double x = column - h;
	  double y = row - h;
	  temp (column, row) = (1 / C) * exp (- (x * x + y * y) / (2 * sigma2));
	}
  }

  *this <<= temp * format;
}

/* Disabled until I add ability to choose border handling mode in Convolution2D
Image
Gaussian2D::filter (const Image & image)
{
  // This specialized filter function takes advantage of two facts about
  // Gaussian2D: 1) It sums to 1.  2) It is symmetric.  This means we can
  // "boost" the tails to get full coverage of the image area.  It also means
  // that a convolution is the same as a correlation, so we don't have to
  // write code to look at things backwards.


  // We are always GrayFloat (per constructor), so convert other object.
  // Alternately, we could handle a color object by splitting its channels,
  // convolving each one separately, and then rejoining.
  if (*image.format != GrayFloat)
  {
	return filter (image * GrayFloat);
  }

  Image result (image.width, image.height, *format);
  result.bias = max (bias, image.bias);
  result.scale = min (scale, image.scale);

  int midX = width / 2;
  int midY = height / 2;

  for (int x = 0; x < result.width; x++)
  {
	for (int y = 0; y < result.height; y++)
	{
	  int hl = 0 >? (midX - x);
	  int hh = width <? (midX + image.width - x);
	  int vl = 0 >? (midY - y);
	  int vh = height <? (midY + image.height - y);

	  float sum = 0;
	  float weight = 0;
	  for (int h = hl; h < hh; h++)
	  {
		for (int v = vl; v < vh; v++)
		{
		  float value = ((float *) buffer)[v * width + h];
		  sum += value * image.pixelGrayFloat (x - midX + h, y - midY + v);
		  weight += value;
		}
	  }
	  result.pixelGrayFloat (x, y) = sum / weight;
	}
  }

  return result;
}
*/

double
Gaussian2D::response (const Image & image, const Point & p) const
{
  if (*format != *image.format)
  {
	if (format->precedence <= image.format->precedence)
	{
	  Convolution2D temp = (*this) * (*image.format);
	  return temp.response (image, p);
	}
	return response (image * (*format), p);
  }

  int x = (int) rint (p.x);
  int y = (int) rint (p.y);

  int midX = width / 2;
  int midY = height / 2;
  int hl = (0 > (midX - x)) ? 0 : (midX - x);	//KenFix
  int hh = (width < (midX + image.width - x)) ? width : (midX + image.width - x);		//KenFix
  int vl = (0 > (midY - y))? 0 : (midY - y);	//KenFix
  int vh = (height < (midY + image.height - y)) ? height : (midY + image.height - y);	//KenFix

  if (*format == GrayFloat)
  {
	ImageOf<float> that (image);
	float result = 0;
	float weight = 0;
	for (int h = hl; h < hh; h++)
	{
	  for (int v = vl; v < vh; v++)
	  {
		float value = ((float *) buffer)[v * width + h];
		result += value * that (x - midX + h, y - midY + v);
		weight += value;
	  }
	}
	return result / weight;
  }
  else if (*format == GrayDouble)
  {
	ImageOf<double> that (image);
	double result = 0;
	double weight = 0;
	for (int h = hl; h < hh; h++)
	{
	  for (int v = vl; v < vh; v++)
	  {
		double value = ((double *) buffer)[v * width + h];
		result += value * that (x - midX + h, y - midY + v);
		weight += value;
	  }
	}
	return result / weight;
  }
  else
  {
	throw "Gaussian2D::response: unimplemented format";
  }
}


// class DifferenceOfGaussians ------------------------------------------------

DifferenceOfGaussians::DifferenceOfGaussians (double sigmaPlus, double sigmaMinus, const PixelFormat & format)
: Convolution2D (format)
{
  //bias = 128;
  //scale = 128;

  Gaussian2D plus (sigmaPlus, GrayDouble);
  Gaussian2D minus (sigmaMinus, GrayDouble);
  Image temp = plus - minus;

  if (format == GrayChar)
  {
	ImageOf<unsigned char> tempC = temp * GrayChar;

	int top    = tempC.height - 1;
	int bottom = 0;
	int left   = tempC.width - 1;
	int right  = 0;

	for (int x = 0; x < width; x++)
	{
	  for (int y = 0; y < height; y++)
	  {
		if (tempC (x, y) != 128)  // 128 is the standard bias for char images.
		{
		  top    = min (top,    y);
		  bottom = max (bottom, y);
		  left   = min (left,   x);
		  right  = max (right,  x);
		}
	  }
	}

	int w = right - left + 1;
	int h = bottom - top + 1;
	bitblt (tempC, 0, 0, left, top, w, h);
  }
  else
  {
	*this <<= temp * format;
  }
}


// class GaussianDerivativeFirst ----------------------------------------------

GaussianDerivativeFirst::GaussianDerivativeFirst (int xy, double sigmaX, double sigmaY, double angle, const PixelFormat & format)
: Convolution2D (format)
{
  //bias = 128;
  //scale = 128;

  if (sigmaY < 0)
  {
	sigmaY = sigmaX;
  }

  const double C = 2 * PI * sigmaX * sigmaY;
  int half = (int) rint (Gaussian2D::cutoff * ((sigmaX > sigmaY) ? sigmaX : sigmaY));	//KenFix
  int size = 2 * half + 1;

  ImageOf<double> temp (size, size, GrayDouble);

  double s = sin (- angle);
  double c = cos (- angle);

  double sigmaX2 = sigmaX * sigmaX;
  double sigmaY2 = sigmaY * sigmaY;

  for (int row = 0; row < size; row++)
  {
	for (int column = 0; column < size; column++)
	{
	  double u = column - half;
	  double v = row - half;
	  double x = u * c - v * s;
	  double y = u * s + v * c;

	  double value = (1 / C) * exp (-0.5 * (x * x / sigmaX2 + y * y / sigmaY2));
	  if (xy)  // Gy
	  {
		value *= - y / sigmaY2;
	  }
	  else  // Gx
	  {
		value *= - x / sigmaX2;
	  }
	  temp (column, row) = value;
	}
  }

  *this <<= temp * format;
}


// class GaussianDerivativeSecond ---------------------------------------------

GaussianDerivativeSecond::GaussianDerivativeSecond (int xy1, int xy2, double sigmaX, double sigmaY, double angle, const PixelFormat & format)
: Convolution2D (format)
{
  //bias = 128;
  //scale = 128;

  if (sigmaY < 0)
  {
	sigmaY = sigmaX;
  }

  const double C = 2 * PI * sigmaX * sigmaY;
  int half = (int) (Gaussian2D::cutoff * ((sigmaX > sigmaY) ? sigmaX : sigmaY));	//KenFix
  int size = 2 * half + 1;

  ImageOf<double> temp (size, size, GrayDouble);

  double s = sin (- angle);
  double c = cos (- angle);

  double sigmaX2 = sigmaX * sigmaX;
  double sigmaY2 = sigmaY * sigmaY;
  double sigmaX4 = sigmaX2 * sigmaX2;
  double sigmaY4 = sigmaY2 * sigmaY2;

  for (int row = 0; row < size; row++)
  {
	for (int column = 0; column < size; column++)
	{
	  double u = column - half;
	  double v = row - half;
	  double x = u * c - v * s;
	  double y = u * s + v * c;

	  double value = (1 / C) * exp (-0.5 * (x * x / sigmaX2 + y * y / sigmaY2));
	  if (! xy1  &&  ! xy2)  // Gxx
	  {
		value *= x * x / sigmaX4 - 1 / sigmaX2;
	  }
	  else if (xy1  &&  xy2)  // Gyy
	  {
		value *= y * y / sigmaY4 - 1 / sigmaY2;
	  }
	  else  // Gxy = Gyx
	  {
		value *= x * y / (sigmaX2 * sigmaY2);
	  }
	  temp (column, row) = value;
	}
  }

  // When (if) adding code for GrayChar, be sure to keep size at least 3 * sigma.

  *this <<= temp * format;
}


// class GaussianDerivativeThird ----------------------------------------------

GaussianDerivativeThird::GaussianDerivativeThird (int xy1, int xy2, int xy3, double sigmaX, double sigmaY, double angle, const PixelFormat & format)
: Convolution2D (format)
{
  //bias = 128;
  //scale = 128;

  // Count how many of each kind of derivative we have been given.
  int dxcount = 0;
  int dycount = 0;
  if (xy1)
  {
	dycount++;
  }
  else
  {
	dxcount++;
  }
  if (xy2)
  {
	dycount++;
  }
  else
  {
	dxcount++;
  }
  if (xy3)
  {
	dycount++;
  }
  else
  {
	dxcount++;
  }

  if (sigmaY < 0)
  {
	sigmaY = sigmaX;
  }

  const double C = 2 * PI * sigmaX * sigmaY;
  int half = (int) (Gaussian2D::cutoff * ((sigmaX > sigmaY) ? sigmaX : sigmaY));	//KenFix
  int size = 2 * half + 1;

  ImageOf<double> temp (size, size, GrayDouble);

  double s = sin (- angle);
  double c = cos (- angle);

  double sigmaX2 = sigmaX * sigmaX;
  double sigmaY2 = sigmaY * sigmaY;
  double sigmaX4 = sigmaX2 * sigmaX2;
  double sigmaY4 = sigmaY2 * sigmaY2;
  double sigmaX6 = sigmaX4 * sigmaX2;
  double sigmaY6 = sigmaY4 * sigmaY2;

  for (int row = 0; row < size; row++)
  {
	for (int column = 0; column < size; column++)
	{
	  double u = column - half;
	  double v = row - half;
	  double x = u * c - v * s;
	  double y = u * s + v * c;

	  double value = (1 / C) * exp (-0.5 * (x * x / sigmaX2 + y * y / sigmaY2));
	  if (dxcount == 2)  // Gxxy = Gxyx = Gyxx
	  {
		value *= (x * x / sigmaX4 - 1 / sigmaX2) * (- y / sigmaY2);
	  }
	  else if (dycount == 2)  // Gyyx = Gyxy = Gxyy
	  {
		value *= (y * y / sigmaY4 - 1 / sigmaY2) * (- x / sigmaX2);
	  }
	  else if (dxcount == 3)  // Gxxx
	  {
		value *= - pow (x, 3) / sigmaX6 + 3 * x / sigmaX4;
	  }
	  else  // Gyyy
	  {
		value *= - pow (y, 3) / sigmaY6 + 3 * y / sigmaY4;
	  }
	  temp (column, row) = value;
	}
  }

  *this <<= temp * format;
}


// class Laplacian ------------------------------------------------------------

Laplacian::Laplacian (double sigma, const PixelFormat & format)
: Convolution2D (format)
{
  // This constructs a Laplacian that is strictly circular.  It would not be
  // hard to make a version that separates sigmaX and sigmaY

  this->sigma = sigma;

  //bias = 128;
  //scale = 128;

  int half = (int) rint (Gaussian2D::cutoff * sigma);
  const int size = 2 * half + 1;

  ImageOf<double> temp (size, size, GrayDouble);

  double sigma2 = sigma * sigma;
  double sigma4 = sigma2 * sigma2;
  double C = 2.0 * PI * sigma2;
  for (int row = 0; row < size; row++)
  {
	for (int column = 0; column < size; column++)
	{
	  double x = column - half;
	  double y = row - half;
	  double x2 = x * x;
	  double y2 = y * y;
	  double value = (1 / C) * exp (- (x2 + y2) / (2 * sigma2)) * ((x2 + y2) / sigma4 - 2 / sigma2);
	  temp (column, row) = value;
	}
  }

  *this <<= temp * format;
}


// class LaplacianSearchable --------------------------------------------------

LaplacianSearchable::LaplacianSearchable (const Image & image, const Point & center, double min, double max)
: image (image)
{
  centerX = center.x;
  centerY = center.y;
  min_ = min;
  max_ = max;
}

double
LaplacianSearchable::value (Vector<double> point)
{
  double sigma = point[0];
  double sigma2 = sigma * sigma;
  double sigma4 = sigma2 * sigma2;
  double C = 2.0 * PI * sigma2;

  double half = sigma * ((Gaussian2D::cutoff > 4.0) ? Gaussian2D::cutoff : 4.0);  // cutoff must be at least 4 to make values at different scales form a smooth curve	//KenFix
  int hl = (0 > (int) rint (centerX - half)) ? 0 : (int) rint (centerX - half);	//KenFix
  int hh = ((image.width - 1) < (int) rint (centerX + half)) ? (image.width - 1) : (int) rint (centerX + half);		//KenFix
  int vl = (0 > (int) rint (centerY - half)) ? 0 : (int) rint (centerY - half);	//KenFix
  int vh = ((image.height - 1) < (int) rint (centerY + half)) ? (image.height - 1) : (int) rint (centerY + half);	//KenFix

  if (*image.format == GrayFloat)
  {
	ImageOf<float> temp (image);
	float result = 0;
	for (int row = vl; row <= vh; row++)
	{
	  for (int column = hl; column <= hh; column++)
	  {
		float x = column - centerX;
		float y = row - centerY;
		float x2 = x * x;
		float y2 = y * y;
		float value = (1 / C) * expf (- (x2 + y2) / (2 * sigma2)) * ((x2 + y2) / sigma4 - 2 / sigma2);
		result += temp (column, row) * value;
	  }
	}
	// Values of a Searchable must be comparable across the domain.  The domain
	// in this case is scale, so we must do scale normalization.
	return fabsf (result * sigma2);
  }
  else if (*image.format == GrayDouble)
  {
	ImageOf<double> temp (image);
	double result = 0;
	for (int row = vl; row <= vh; row++)
	{
	  for (int column = hl; column <= hh; column++)
	  {
		double x = column - centerX;
		double y = row - centerY;
		double x2 = x * x;
		double y2 = y * y;
		double value = (1 / C) * exp (- (x2 + y2) / (2 * sigma2)) * ((x2 + y2) / sigma4 - 2 / sigma2);
		result += temp (column, row) * value;
	  }
	}
	return fabs (result * sigma2);
  }
  else
  {
	throw "LaplacianSearchable: unimplemented format";
  }
}

int
LaplacianSearchable::dimension () const
{
  return 1;
}

//KenFix
#undef min
#undef max

double
LaplacianSearchable::min (int dimension) const
{
  return min_;
}

double
LaplacianSearchable::max (int dimension) const
{
  return max_;
}


// class Convolution1D --------------------------------------------------------

Convolution1D::Convolution1D (Direction direction, const PixelFormat & format)
: Image (format)
{
  this->direction = direction;
}

Convolution1D::Convolution1D (const Image & image)
: Image (image)
{
}

Image
Convolution1D::filter (const Image & image)
{
  // This code is essentially the same as Convolution2D::filter ().  However, it
  // removes one layer of looping, which saves a little bit of overhead.

  if (*format != *image.format)
  {
	if (format->precedence <= image.format->precedence)
	{
	  Convolution1D temp (direction);
	  (Image) temp = (*this) * (*image.format);
	  return image * temp;
	}
	return filter (image * (*format));
  }

  int last = width - 1;

  if (*format == GrayFloat)
  {
	ImageOf<float> that (image);
	if (direction == vertical)
    {
	  ImageOf<float> result (image.width, image.height - last, GrayFloat);
	  for (int x = 0; x < result.width; x++)
      {
		for (int y = 0; y < result.height; y++)
	    {
		  float sum = 0;
		  for (int v = 0; v <= last; v++)
		  {
			sum += ((float *) buffer)[v] * that (x, y - v + last);
		  }
		  result (x, y) = sum;
		}
	  }
	  return result;
	}
	else  // direction == horizontal
	{
	  ImageOf<float> result (image.width - last, image.height, GrayFloat);
	  for (int x = 0; x < result.width; x++)
	  {
		for (int y = 0; y < result.height; y++)
		{
		  float sum = 0;
		  for (int h = 0; h <= last; h++)
		  {
			sum += ((float *) buffer)[h] * that (x - h + last, y);
		  }
		  result (x, y) = sum;
		}
	  }
	  return result;
	}
  }
  else if (*format == GrayDouble)
  {
	ImageOf<double> that (image);
	if (direction == vertical)
    {
	  ImageOf<double> result (image.width, image.height - last, GrayDouble);
	  for (int x = 0; x < result.width; x++)
      {
		for (int y = 0; y < result.height; y++)
	    {
		  double sum = 0;
		  for (int v = 0; v <= last; v++)
		  {
			sum += ((double *) buffer)[v] * that (x, y - v + last);
		  }
		  result (x, y) = sum;
		}
	  }
	  return result;
	}
	else  // direction == horizontal
	{
	  ImageOf<double> result (image.width - last, image.height, GrayDouble);
	  for (int x = 0; x < result.width; x++)
	  {
		for (int y = 0; y < result.height; y++)
		{
		  double sum = 0;
		  for (int h = 0; h <= last; h++)
		  {
			sum += ((double *) buffer)[h] * that (x - h + last, y);
		  }
		  result (x, y) = sum;
		}
	  }
	  return result;
	}
  }
  /*
  else if (*format == GrayChar)
  {
	result.bias = 128;
	result.scale = 128;

	if (direction == vertical)
    {
	  // (x, y) iterate over the output image
	  for (int x = 0; x < result.width; x++)
      {
		for (int y = 0; y < result.height; y++)
	    {
		  int sum = 0;
		  for (int v = 0; v <= last; v++)
		  {
			sum += (buffer[v] - bias) * (image.pixelGray8 (x, y - v + last) - image.bias);
		  }
		  sum *= result.scale;
		  sum /= scale * image.scale;
		  sum += result.bias;
		  sum = min (sum, 255);
		  sum = max (sum, 0);
		  result.pixelGray8 (x, y) = sum;
		}
	  }
	}
	else  // direction == horizontal
	{
	  for (int x = 0; x < result.width; x++)
	  {
		for (int y = 0; y < result.height; y++)
		{
		  int sum = 0;
		  for (int h = 0; h <= last; h++)
		  {
			sum += (buffer[h] - bias) * (image.pixelGray8 (x - h + last, y) - image.bias);
		  }
		  sum *= result.scale;
		  sum /= scale * image.scale;
		  sum += result.bias;
		  sum = min (sum, 255);
		  sum = max (sum, 0);
		  result.pixelGray8 (x, y) = sum;
		}
	  }
	}
  }
  */
  else
  {
    throw "Convolution1D::filter: unimplemented format";
  }
}


//KenFix
#define max(a,b)  (a)>(b)? (a) : (b)
#define min(a,b)  (a)<(b)? (a) : (b)

double
Convolution1D::response (const Image & image, const Point & p) const
{
  if (*format != *image.format)
  {
	if (format->precedence <= image.format->precedence)
	{
	  Convolution1D temp (direction);
	  (Image) temp = (*this) * (*image.format);
	  return temp.response (image, p);
	}
	return response (image * (*format), p);
  }

  int x = (int) rint (p.x);
  int y = (int) rint (p.y);

  int mid = width / 2;
  int high;
  int low;
  if (direction == horizontal)
  {
	high = mid + min (x, mid);
	low = max (image.width, x + mid + 1) - image.width;
  }
  else // direction == vertical
  {
	high = mid + min (y, mid);
	low = max (image.height, y + mid + 1) - image.height;
  }

  if (*format == GrayFloat)
  {
	float result = 0;
	ImageOf<float> that (image);
	if (direction == horizontal)
	{
	  for (int h = low; h <= high; h++)
	  {
		result += ((float *) buffer)[h] * that (x + mid - h, y);
	  }
	}
	else  // direction == vertical
	{
	  for (int v = low; v <= high; v++)
	  {
		result += ((float *) buffer)[v] * that (x, y + mid - v);
	  }
	}
	return result;
  }
  else if (*format == GrayDouble)
  {
	double result = 0;
	ImageOf<double> that (image);
	if (direction == horizontal)
	{
	  for (int h = low; h <= high; h++)
	  {
		result += ((double *) buffer)[h] * that (x + mid - h, y);
	  }
	}
	else  // direction == vertical
	{
	  for (int v = low; v <= high; v++)
	  {
		result += ((double *) buffer)[v] * that (x, y + mid - v);
	  }
	}
	return result;
  }
  /*
  else if (*format == GrayChar)
  {
	int sum = 0;
	if (direction == horizontal)
	{
	  for (int h = low; h <= high; h++)
	  {
		sum += (buffer[h] - bias) * (image.pixelGray8 (x + mid - h, y) - image.bias);
	  }
	}
	else  // direction == vertical
	{
	  for (int v = low; v <= high; v++)
	  {
		sum += (buffer[v] - bias) * (image.pixelGray8 (x, y + mid - v) - image.bias);
	  }
	}
	result = (float) sum / (scale * image.scale);
  }
  */
  else
  {
	throw "Convolution1D::response: unimplemented format";
  }
}


// class Gaussian1D -----------------------------------------------------------

Gaussian1D::Gaussian1D (double sigma, Direction direction, const PixelFormat & format)
: Convolution1D (direction, GrayDouble)
{
  double sigma2 = sigma * sigma;
  double C = sqrt (2.0 * PI) * sigma;

  int h = (int) rint (Gaussian2D::cutoff * sigma);
  width = 2 * h + 1;
  height = 1;
  buffer.grow (width * GrayDouble.depth);

  ((double *) buffer)[h] = 1 / C;  // * exp (0)
  for (int i = 1; i <= h; i++)
  {
	double x = i;
	double value = (1 / C) * exp (- x * x / (2 * sigma2));
	((double *) buffer)[h + i] = value;
	((double *) buffer)[h - i] = value;
  }

  *this *= format;
}

/*  Disabled until I add way to choose border handling mode in Convolution1D
Image
Gaussian1D::filter (const Image & image)
{
  // See Gaussian2D::filter for commentary on why we override this function.

  if (*image.format != GrayFloat)
  {
	return filter (image * GrayFloat);
  }

  Image result (image.width, image.height, GrayFloat);
  result.bias = max (bias, image.bias);
  result.scale = min (scale, image.scale);

  int mid = width / 2;

  if (direction == vertical)
  {
	for (int x = 0; x < result.width; x++)
    {
	  for (int y = 0; y < result.height; y++)
	  {
		int vl = 0 >? (mid - y);
		int vh = width <? (mid + image.height - y);

		float sum = 0;
		float weight = 0;
		for (int v = vl; v < vh; v++)
		{
		  float value = ((float *) buffer)[v];
		  sum += value * image.pixelGrayFloat (x, y - mid + v);
		  weight += value;
		}
		result.pixelGrayFloat (x, y) = sum / weight;
	  }
	}
  }
  else  // direction == horizontal
  {
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		int hl = 0 >? (mid - x);
		int hh = width <? (mid + image.width - x);

		float sum = 0;
		float weight = 0;
		for (int h = hl; h < hh; h++)
		{
		  float value = ((float *) buffer)[h];
		  sum += value * image.pixelGrayFloat (x - mid + h, y);
		  weight += value;
		}
		result.pixelGrayFloat (x, y) = sum / weight;
	  }
	}
  }

  return result;
}
*/


// class GaussianDerivative1D -------------------------------------------------

GaussianDerivative1D::GaussianDerivative1D (double sigma, Direction direction, const PixelFormat & format)
: Convolution1D (direction, GrayDouble)
{
  double sigma2 = sigma * sigma;
  double C = sqrt (2.0 * PI) * sigma;

  int h = (int) rint (Gaussian2D::cutoff * sigma);
  width = 2 * h + 1;
  height = 1;
  buffer.grow (width * GrayDouble.depth);

  ((double *) buffer)[h] = 0;
  for (int i = 1; i <= h; i++)
  {
	double x = i;
	double value = (1 / C) * exp (- x * x / (2 * sigma2)) * (- x / sigma2);
	((double *) buffer)[h + i] = -value;
	((double *) buffer)[h - i] = value;
  }

  *this *= format;
}


// class FilterHarris ---------------------------------------------------------

const double FilterHarris::alpha = 0.06;

FilterHarris::FilterHarris (double sigmaI, double s, const PixelFormat & format)
: G_I (sigmaI, format),
  G1_I (sigmaI, Convolution1D::horizontal, format),
  G1_D (sigmaI * s, Convolution1D::horizontal, format),
  dG_D (sigmaI * s, Convolution1D::horizontal, format),
  xx (format),
  xy (format),
  yy (format)
{
  double sigmaD = sigmaI * s;
  dG_D *= sigmaD;  // Boost to make results comparable across scale.

  offsetI = G1_I.width / 2;
  offsetD = ((G1_D.width > dG_D.width) ? G1_D.width : dG_D.width) / 2;	//KenFix
  offset = offsetI + offsetD;

  offset1 = 0;
  offset2 = 0;
  int difference = (G1_D.width - dG_D.width) / 2;
  if (difference > 0)
  {
	offset1 = difference;
  }
  else if (difference < 0)
  {
	offset2 = -difference;
  }
}

Image
FilterHarris::filter (const Image & image)
{
  preprocess (image);
  return process ();
}

void
FilterHarris::preprocess (const Image & image)
{
  if (*image.format != *G1_D.format)
  {
	preprocess (image * (*G1_D.format));
  }

  G1_D.direction = Convolution1D::vertical;
  dG_D.direction = Convolution1D::horizontal;
  Image dx = image * G1_D * dG_D;

  G1_D.direction = Convolution1D::horizontal;
  dG_D.direction = Convolution1D::vertical;
  Image dy = image * G1_D * dG_D;

  xx.resize (((dx.width < dy.width) ? dx.width : dy.width), ((dx.height < dy.height) ? dx.height : dy.height));		//KenFix
  xy.resize (xx.width, xx.height);
  yy.resize (xx.width, xx.height);

  if (*dx.format == GrayFloat)
  {
	ImageOf<float> dxf (dx);
	ImageOf<float> dyf (dy);
	ImageOf<float> xxf (xx);
	ImageOf<float> xyf (xy);
	ImageOf<float> yyf (yy);
	for (int x = 0; x < xx.width; x++)
	{
	  for (int y = 0; y < xx.height; y++)
	  {
		float tx = dxf (x + offset1, y + offset2);
		float ty = dyf (x + offset2, y + offset1);
		xxf (x, y) = tx * tx;
		xyf (x, y) = tx * ty;
		yyf (x, y) = ty * ty;
	  }
	}
  }
  else if (*dx.format == GrayDouble)
  {
	ImageOf<double> dxd (dx);
	ImageOf<double> dyd (dy);
	ImageOf<double> xxd (xx);
	ImageOf<double> xyd (xy);
	ImageOf<double> yyd (yy);
	for (int x = 0; x < xx.width; x++)
	{
	  for (int y = 0; y < xx.height; y++)
	  {
		double tx = dxd (x + offset1, y + offset2);
		double ty = dyd (x + offset2, y + offset1);
		xxd (x, y) = tx * tx;
		xyd (x, y) = tx * ty;
		yyd (x, y) = ty * ty;
	  }
	}
  }
  else
  {
	throw "FilterHarris::preprocess: unimplemented format";
  }
}

Image
FilterHarris::process ()
{
  int last = G1_I.width - 1;

  G1_I.direction = Convolution1D::vertical;
  Image Sxx = xx * G1_I;
  Image Sxy = xy * G1_I;
  Image Syy = yy * G1_I;
  G1_I.direction = Convolution1D::horizontal;
  Sxx = Sxx * G1_I;
  Sxy = Sxy * G1_I;
  Syy = Syy * G1_I;

  if (*G1_I.format == GrayFloat)
  {
	ImageOf<float> result (xx.width - last, xx.height - last, GrayFloat);
	ImageOf<float> Sxxf (Sxx);
	ImageOf<float> Sxyf (Sxy);
	ImageOf<float> Syyf (Syy);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		float txx = Sxxf (x, y);
		float txy = Sxyf (x, y);
		float tyy = Syyf (x, y);
		result (x, y) = (txx * tyy - txy * txy) - alpha * (txx + tyy) * (txx + tyy);
	  }
	}
	return result;
  }
  else if (*G1_I.format == GrayDouble)
  {
	ImageOf<double> result (xx.width - last, xx.height - last, GrayDouble);
	ImageOf<double> Sxxd (Sxx);
	ImageOf<double> Sxyd (Sxy);
	ImageOf<double> Syyd (Syy);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		double txx = Sxxd (x, y);
		double txy = Sxyd (x, y);
		double tyy = Syyd (x, y);
		result (x, y) = (txx * tyy - txy * txy) - alpha * (txx + tyy) * (txx + tyy);
	  }
	}
	return result;
  }
  else
  {
	throw "FilterHarris::process: unimplemented format";
  }
}


// class NonMaxSuppress -------------------------------------------------------

NonMaxSuppress::NonMaxSuppress (int half)
{
  this->half = half;
  maximum = 0;
  average = 0;
}

Image
NonMaxSuppress::filter (const Image & image)
{
  maximum = 0;
  average = 0;
  int count = 0;

  if (*image.format == GrayFloat)
  {
	ImageOf<float> result (image.width, image.height, GrayFloat);
	ImageOf<float> that (image);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		int h;
		int hl = max (0, x - half);
		int hh = min (image.width, x + half + 1);
		int v;
		int vl = max (0, y - half);
		int vh = min (image.height, y + half + 1);
		float me = that (x, y);
	   	maximum = max (maximum, me);
		for (h = hl; me != 0  &&  h < hh; h++)
		{
		  for (v = vl; v < vh; v++)
		  {
			if (that (h, v) > me)
			{
			  me = 0;
			  break;
			}
		  }
		}
		result (x, y) = me;
		if (me != 0)
		{
		  average += me;
		  count++;
		}
	  }
	}
	average /= count;
	return result;
  }
  else if (*image.format == GrayDouble)
  {
	ImageOf<double> result (image.width, image.height, GrayDouble);
	ImageOf<double> that (image);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		int h;
		int hl = max (0, x - half);
		int hh = min (image.width, x + half + 1);
		int v;
		int vl = max (0, y - half);
		int vh = min (image.height, y + half + 1);
		double me = that (x, y);
		maximum = (maximum > me) ? maximum : me;	//KenFix
		for (h = hl; me != 0  &&  h < hh; h++)
		{
		  for (v = vl; v < vh; v++)
		  {
			if (that (h, v) > me)
			{
			  me = 0;
			  break;
			}
		  }
		}
		result (x, y) = me;
		if (me != 0)
		{
		  average += me;
		  count++;
		}
	  }
	}
	average /= count;
	return result;
  }
  else if (*image.format == GrayChar)
  {
	ImageOf<unsigned char> result (image.width, image.height, GrayChar);
	ImageOf<unsigned char> that (image);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		int h;
		int hl = max (0, x - half);
		int hh = min (image.width, x + half + 1);
		int v;
		int vl = max (0, y - half);
		int vh = min (image.height, y + half + 1);
		unsigned char me = that (x, y);
		maximum = max (maximum, (float) me);
		int c = 0;
		int cx = 0;
		int cy = 0;
		for (h = hl; me  &&  h < hh; h++)
		{
		  for (v = vl; v < vh; v++)
		  {
			if (that (h, v) > me)
			{
			  me = 0;
			  break;
			}
			else if (that (h, v) == me)
			{
			  c++;
			  cx += x - h;
			  cy += y - v;
			}
		  }
		}
		if (c > 1)
		{
		  if (cx / c > 1  ||  cy / c > 1)
		  {
			// We are not the center of our cluster of equal points.
			me = 0;
		  }
		  else
		  {
			// We are the center.  However, it is possible for more than one point to perceive this,
			// so arbitrate further by suppressing self if any point has already been added to output
			// within our neighborhood.

			// Scan everything to the left ...
			for (h = hl; me  &&  h < x; h++)
			{
			  for (v = vl; v < vh; v++)
			  {
				if (result (h, v))
				{
				  me = 0;
				  break;
				}
			  }
			}
			// ... and for extra measure, scan the column above us.
			if (me)
			{
			  for (v = vl; v < y; v++)
			  {
				if (result (x, v))
				{
				  me = 0;
				  break;
				}
			  }
			}
		  }
		}
		result (x, y) = me;
		if (me)
		{
		  average += me;
		  count++;
		}
	  }
	}
	average /= count;
	return result;
  }
  else
  {
	return filter (image * GrayFloat);
  }
}


// class Normalize ------------------------------------------------------------
//KenFix
Normalize::Normalize (double length)
{
  this->length = length;
}

Image
Normalize::filter (const Image & image)
{
  int x;	//KenFix

  if (*image.format == GrayFloat)
  {
	ImageOf<float> result (image.width, image.height, GrayFloat);
	result.timestamp = image.timestamp;
	ImageOf<float> that (image);
	float sum = 0;
	for (x = 0; x < image.width; x++)
    {
	  for (int y = 0; y < image.height; y++)
	  {
		sum += that (x, y) * that (x, y);
	  }
	}
	sum = sqrt (sum);
	for (x = 0; x < image.width; x++)
    {
	  for (int y = 0; y < image.height; y++)
	  {
		result (x, y) = that (x, y) * length / sum;
	  }
	}
	return result;
  }
  else if (*image.format == GrayDouble)
  {
	ImageOf<double> result (image.width, image.height, GrayDouble);
	result.timestamp = image.timestamp;
	ImageOf<double> that (image);
	double sum = 0;
	for (x = 0; x < image.width; x++)
    {
	  for (int y = 0; y < image.height; y++)
	  {
		sum += that (x, y) * that (x, y);
	  }
	}
	sum = sqrt (sum);
	for (x = 0; x < image.width; x++)
    {
	  for (int y = 0; y < image.height; y++)
	  {
		result (x, y) = that (x, y) * length / sum;
	  }
	}
	return result;
  }
  else
  {
	throw "Normalize::filter: unimplemented format";
  }
}

Normalize my::UnitNorm;


// class Transform ------------------------------------------------------------

Transform::Transform (const MatrixAbstract<float> & A, bool inverse)
{
  if (inverse)
  {
	IA = A;
	this->A = !IA;
	needInverse = false;
  }
  else
  {
	this->A = A;
	needInverse = true;
  }

  defaultViewport = true;

  if (A.columns () >= 3)
  {
	peg = false;
	if (inverse)
	{
	  translateX = - (this->A(0,0) * A(0,2) + this->A(0,1) * A(1,2));
	  translateY = - (this->A(1,0) * A(0,2) + this->A(1,1) * A(1,2));
	}
	else
	{
	  translateX = A(0,2);
	  translateY = A(1,2);
	}
  }
  else
  {
	peg = true;
	translateX = 0;
	translateY = 0;
  }
}

Transform::Transform (const MatrixAbstract<double> & A, bool inverse)
{
  if (inverse)
  {
	IA <<= A;
	this->A = !IA;
	needInverse = false;
  }
  else
  {
	this->A <<= A;
	needInverse = true;
  }

  defaultViewport = true;

  if (A.columns () >= 3)
  {
	peg = false;
	if (inverse)
	{
	  translateX = - (this->A(0,0) * A(0,2) + this->A(0,1) * A(1,2));
	  translateY = - (this->A(1,0) * A(0,2) + this->A(1,1) * A(1,2));
	}
	else
	{
	  translateX = A(0,2);
	  translateY = A(1,2);
	}
  }
  else
  {
	peg = true;
	translateX = 0;
	translateY = 0;
  }
}

Transform::Transform (float angle)
{
  A (0, 0) = cos (angle);
  A (1, 0) = sin (angle);
  A (0, 1) = - A (1, 0);
  A (1, 1) = A (0, 0);

  needInverse = true;
  defaultViewport = true;
  peg = true;
  translateX = 0;
  translateY = 0;
}

Transform::Transform (float scaleX, float scaleY)
{
  A (0, 0) = scaleX;
  A (0, 1) = 0;
  A (1, 0) = 0;
  A (1, 1) = scaleY;

  needInverse = true;
  defaultViewport = true;
  peg = true;
  translateX = 0;
  translateY = 0;
}

Image
Transform::filter (const Image & image)
{
  if (needInverse)
  {
	IA = !A;
	needInverse = false;
  }

  Vector<float> cs (2);  // Center of source image
  Vector<float> cd (2);  // Center of destination image

  const float fImageWidth  = image.width - 0.5;
  const float fImageHeight = image.height - 0.5;
  const int   iImageWidth  = image.width - 1;
  const int   iImageHeight = image.height - 1;

  if (*image.format == GrayFloat)
  {
	ImageOf<float> result (GrayFloat);
	prepareResult (image, result, cs, cd);
	ImageOf<float> that (image);
	for (int toX = 0; toX < result.width; toX++)
	{
	  for (int toY = 0; toY < result.height; toY++)
	  {
		float x = toX - cd[0];
		float y = toY - cd[1];
		float tx =  IA (0, 0) * x + IA (0, 1) * y;
		y        = (IA (1, 0) * x + IA (1, 1) * y) + cs[1];
		x        = tx + cs[0];
		if (x > -0.5  &&  x < fImageWidth  &&  y > -0.5  &&  y < fImageHeight)
		{
		  int fromX = (int) floor (x);
		  int fromY = (int) floor (y);
		  float dx = x - fromX;
		  float dy = y - fromY;
		  float p00 = (fromX < 0             ||  fromY < 0            ) ? 0 : that (fromX,     fromY);
		  float p01 = (fromX < 0             ||  fromY >= iImageHeight) ? 0 : that (fromX,     fromY + 1);
		  float p10 = (fromX >= iImageWidth  ||  fromY < 0            ) ? 0 : that (fromX + 1, fromY);
		  float p11 = (fromX >= iImageWidth  ||  fromY >= iImageHeight) ? 0 : that (fromX + 1, fromY + 1);
		  result (toX, toY) =   (1.0 - dy) * ((1.0 - dx) * p00 + dx * p10)
			                  +  dy        * ((1.0 - dx) * p01 + dx * p11);
		}
	  }
	}
	return result;
  }
  else if (*image.format == GrayDouble)
  {
	ImageOf<double> result (GrayDouble);
	prepareResult (image, result, cs, cd);
	ImageOf<double> that (image);
	for (int toX = 0; toX < result.width; toX++)
	{
	  for (int toY = 0; toY < result.height; toY++)
	  {
		float x = toX - cd[0];
		float y = toY - cd[1];
		float tx =  IA (0, 0) * x + IA (0, 1) * y;
		y        = (IA (1, 0) * x + IA (1, 1) * y) + cs[1];
		x        = tx + cs[0];
		if (x > -0.5  &&  x < fImageWidth  &&  y > -0.5  &&  y < fImageHeight)
		{
		  int fromX = (int) floor (x);
		  int fromY = (int) floor (y);
		  double dx = x - fromX;
		  double dy = y - fromY;
		  double p00 = (fromX < 0             ||  fromY < 0            ) ? 0 : that (fromX,     fromY);
		  double p01 = (fromX < 0             ||  fromY >= iImageHeight) ? 0 : that (fromX,     fromY + 1);
		  double p10 = (fromX >= iImageWidth  ||  fromY < 0            ) ? 0 : that (fromX + 1, fromY);
		  double p11 = (fromX >= iImageWidth  ||  fromY >= iImageHeight) ? 0 : that (fromX + 1, fromY + 1);
		  result (toX, toY) =   (1.0 - dy) * ((1.0 - dx) * p00 + dx * p10)
			                  +  dy        * ((1.0 - dx) * p01 + dx * p11);
		}
	  }
	}
	return result;
  }
  else
  {
	return filter (image * GrayFloat);
  }
}

void
Transform::setPeg (float originX, float originY, int width, int height)
{
  defaultViewport = false;
  peg = true;

  this->originX = originX;
  this->originY = originY;
  this->width   = width;
  this->height  = height;
}

void
Transform::setWindow (float originX, float originY, int width, int height)
{
  defaultViewport = false;
  peg = false;

  this->originX = originX;
  this->originY = originY;
  this->width   = width;
  this->height  = height;
}

Transform
Transform::operator * (const Transform & that) const
{
  Transform result (A * that.A);
  result.translateX = A (0, 0) * that.translateX + A (0, 1) * that.translateY + translateX;
  result.translateY = A (1, 0) * that.translateX + A (1, 1) * that.translateY + translateY;
  result.peg = result.translateX == 0  &&  result.translateY == 0;
  return result;
}

void
Transform::prepareResult (const Image & image, Image & result, Vector<float> & cs, Vector<float> & cd) const
{
  // Prepare image and various parameters
  if (peg)
  {
	if (defaultViewport)
	{
	  cs[0] = (image.width - 1) / 2.0;
	  cs[1] = (image.height - 1) / 2.0;

	  float l = cs[0];
	  float r = cs[0];
	  float t = cs[1];
	  float b = cs[1];

	  //KenFix
      #define twistCorner(inx,iny) \
	  { \
	    float outx = inx - cs[0]; \
	    float outy = iny - cs[1]; \
	    float tx =  A (0, 0) * outx + A (0, 1) * outy; \
	    outy     = (A (1, 0) * outx + A (1, 1) * outy) + cs[1]; \
	    outx     = tx + cs[0]; \
		l = (l < outx) ? l : outx; \
		r = (r > outx) ? r : outx; \
		t = (t < outy) ? t : outy; \
		b = (b > outy) ? b : outy; \
      }

	  twistCorner (-0.5,                -0.5);                  // Upper  left  corner
	  twistCorner ((image.width - 0.5), -0.5);                  // Upper  right corner
	  twistCorner (-0.5,                (image.height - 0.5)); // Bottom left  corner
	  twistCorner ((image.width - 0.5), (image.height - 0.5)); // Bottom right corner

	  cd[0] = cs[0] - l - 0.5;
	  cd[1] = cs[1] - t - 0.5;
	  result.resize ((int) ceil (r - l), (int) ceil (b - t));
	}
	else
	{
	  int w = width < 0 ? image.width : width;
	  int h = height < 0 ? image.height : height;
	  result.resize (w, h);
	  cd[0] = (w - 1) / 2.0;
	  cd[1] = (h - 1) / 2.0;
	  cs[0] = originX < 0 ? (image.width - 1)  / 2.0 : originX;
	  cs[1] = originY < 0 ? (image.height - 1) / 2.0 : originY;
	}
  }
  else
  {
	if (defaultViewport)
	{
	  cd[0] = translateX;
	  cd[1] = translateY;
	  cs[0] = 0;
	  cs[1] = 0;
	  result.resize (image.width, image.height);
	}
	else
	{
	  cd[0] = translateX - (originX - width  / 2.0);
	  cd[1] = translateY - (originY - height / 2.0);
	  cs[0] = 0;
	  cs[1] = 0;
	  result.resize (width, height);
	}
  }
}


// class TransformGauss ------------------------------------------------------------

void
TransformGauss::prepareG ()
{
  // Calculate size and shape of Gaussian
  const float sigma2 = 0.25;  // radius of support squared
  Matrix2x2<float> S = IA * ~IA * sigma2;
  sigmaX = sqrt (S (0, 0));
  sigmaY = sqrt (S (1, 1));
  float C = 2.0 * PI * sigmaX * sigmaY;
  Gshw = (int) ceil (sigmaX * 3);
  Gshh = (int) ceil (sigmaY * 3);
  S = !S;

  // Generate discretized Gaussian
  const float stepsPerZ = 6;
  GstepX = (int) (ceil(stepsPerZ / sigmaX) > 1) ? ceil(stepsPerZ / sigmaX) : 1;  // (steps / pixel) = (steps / Z) / (pixels / Z)	//KenFix
  GstepY = (int) (ceil(stepsPerZ / sigmaY) > 1) ? ceil(stepsPerZ / sigmaY) : 1;	//KenFix
  G.resize ((2 * Gshw + 1) * GstepX,
			(2 * Gshh + 1) * GstepY);
  int hw = G.width / 2;
  int hh = G.height / 2;
  for (int x = 0; x < G.width; x++)
  {
	for (int y = 0; y < G.height; y++)
	{
	  float dx = (float) (x - hw) / GstepX;
	  float dy = (float) (y - hh) / GstepY;
	  float tx = S (0, 0) * dx + S (0, 1) * dy;
	  float ty = S (1, 0) * dx + S (1, 1) * dy;
	  float value = (1 / C) * exp (-0.5 * (dx * tx + dy * ty));
	  if (value < 1e-38  &&  dx >= -0.5  &&  dx < 0.5  &&  dy >= -0.5  &&  dy < 0.5)
	  {
		value = 1e-38;
	  }
	  G (x, y) = value;
	}
  }

  needG = false;
}

Image
TransformGauss::filter (const Image & image)
{
  if (needInverse)
  {
	IA = !A;
	needInverse = false;
	needG = true;
  }

  if (needG)
  {
	prepareG ();
  }

  Vector<float> cs (2);  // Center of source image
  Vector<float> cd (2);  // Center of destination image

  if (*image.format == GrayFloat)
  {
	ImageOf<float> result (GrayFloat);
	prepareResult (image, result, cs, cd);
	ImageOf<float> that (image);
	for (int toX = 0; toX < result.width; toX++)
	{
	  for (int toY = 0; toY < result.height; toY++)
	  {
		float x = toX - cd[0];
		float y = toY - cd[1];
		float tx =  IA (0, 0) * x + IA (0, 1) * y;
		y        = (IA (1, 0) * x + IA (1, 1) * y) + cs[1];
		x        = tx + cs[0];
		if (x > -0.5 - sigmaX  &&  x < image.width - 0.5 + sigmaX  &&  y > -0.5 - sigmaY  &&  y < image.height - 0.5 + sigmaY)
		{
		  int rx = (int) rint (x);
		  int ry = (int) rint (y);
		  int beginX = rx - Gshw;
		  int beginY = ry - Gshh;
		  int endX = beginX + 2 * Gshw;
		  int endY = beginY + 2 * Gshh;
		  endX = (endX < (image.width - 1)) ? endX : (image.width - 1);		//KenFix
		  endY = (endY < (image.height - 1)) ? endY : (image.height - 1);	//KenFix
		  float weight = 0;
		  float sum = 0;
		  int Gx      = (int) ((0.499999 + rx - x) * GstepX);  // 0.499999 rather than 0.5 to ensure we get [0, GstepX) rather than [0, GstepX].
		  int offsetY = (int) ((0.499999 + ry - y) * GstepY);
		  if (beginX < 0)
		  {
			Gx -= GstepX * beginX;
			beginX = 0;
		  }
		  if (beginY < 0)
		  {
			offsetY -= GstepY * beginY;
			beginY = 0;
		  }
		  for (int fromX = beginX; fromX <= endX; fromX++)
		  {
			int Gy = offsetY;
			for (int fromY = beginY; fromY <= endY; fromY++)
			{
			  float w = G (Gx, Gy);
			  weight += w;
			  sum += that (fromX, fromY) * w;
			  Gy += GstepY;
			}
			Gx += GstepX;
		  }
		  result (toX, toY) = sum / weight;
		}
	  }
	}
	return result;
  }
  else if (*image.format == GrayDouble)
  {
	ImageOf<double> result (GrayDouble);
	prepareResult (image, result, cs, cd);
	ImageOf<double> that (image);
	for (int toX = 0; toX < result.width; toX++)
	{
	  for (int toY = 0; toY < result.height; toY++)
	  {
		float x = toX - cd[0];
		float y = toY - cd[1];
		float tx =  IA (0, 0) * x + IA (0, 1) * y;
		y        = (IA (1, 0) * x + IA (1, 1) * y) + cs[1];
		x        = tx + cs[0];
		if (x > -0.5 - sigmaX  &&  x < image.width - 0.5 + sigmaX  &&  y > -0.5 - sigmaY  &&  y < image.height - 0.5 + sigmaY)
		{
		  int rx = (int) rint (x);
		  int ry = (int) rint (y);
		  int beginX = rx - Gshw;
		  int beginY = ry - Gshh;
		  int endX = beginX + 2 * Gshw;
		  int endY = beginY + 2 * Gshh;
		  endX = (endX < (image.width - 1)) ? endX : (image.width - 1);		//KenFix
		  endY = (endY < (image.height - 1)) ? endY : (image.height - 1);	//KenFix
		  double weight = 0;
		  double sum = 0;
		  int Gx      = (int) ((0.499999 + rx - x) * GstepX);  // 0.499999 rather than 0.5 to ensure we get [0, GstepX) rather than [0, GstepX].
		  int offsetY = (int) ((0.499999 + ry - y) * GstepY);
		  if (beginX < 0)
		  {
			Gx -= GstepX * beginX;
			beginX = 0;
		  }
		  if (beginY < 0)
		  {
			offsetY -= GstepY * beginY;
			beginY = 0;
		  }
		  for (int fromX = beginX; fromX <= endX; fromX++)
		  {
			int Gy = offsetY;
			for (int fromY = beginY; fromY <= endY; fromY++)
			{
			  double w = G (Gx, Gy);
			  weight += w;
			  sum += that (fromX, fromY) * w;
			  Gy += GstepY;
			}
			Gx += GstepX;
		  }
		  result (toX, toY) = sum / weight;
		}
	  }
	}
	return result;
  }
  else
  {
	return filter (image * GrayFloat);
  }
}


// class Rotate180 ------------------------------------------------------------

Image
Rotate180::filter (const Image & image)
{
  Image result (image.width, image.height, *image.format);
  result.timestamp = image.timestamp;

  int pixels = image.width * image.height;

  #define transfer(size) \
  { \
	for (int i = 0; i < pixels; i++) \
    { \
	  ((size *) result.buffer)[i] = ((size *) image.buffer)[pixels - 1 - i]; \
	} \
  }
  switch (image.format->depth)
  {
    case 8:
	  transfer (double);
	  break;
    case 4:
	  transfer (unsigned int);
	  break;
    case 2:
	  transfer (unsigned short);
	  break;
    case 1:
    default:
	  transfer (unsigned char);
  }

  return result;
}
