#ifndef matrix_h
#define matrix_h


#include "pointer.h"

#include <math.h>
#include <iostream>
#include <strstream>


// The linear algebra package has the following goals:
// * Be simple and straightforward for a programmer to use.  It should be
//   easy to express most common linear algebra calculations using
//   overloaded operators.
// * Work seamlessly with LAPACK.  To this end, storage is always column
//   major.
// * Be lightweight to compile.  We avoid putting much implementation in
//   the headers, even though we are using templates.
// * Be lightweight at run-time.  Eg: shallow copy semantics, and only a
//   couple of variables that need to be copied.  Should limit total copying
//   to 16 bytes or less.


namespace my
{
  // Forward declarations
  template <class T> class Matrix;
  template <class T> class MatrixTranspose;


  // Matrix general interface -------------------------------------------------

  // We reserve the name "Matrix" for a dense matrix, rather than for the
  // abstract type.  This makes coding a little prettier, since dense
  // matrices are the most common case.
  template <class T>
  class MatrixAbstract
  {
  public:
	virtual ~MatrixAbstract ();

	// Structural functions
	virtual T & operator () (const int row, const int column) const = 0;  // Element accesss
    virtual T & operator [] (const int row) const;  // Element access, treating us as a vector.
	virtual int rows () const;
	virtual int columns () const;
	virtual MatrixAbstract * duplicate () const = 0; // Make a new instance of self on the heap, with shallow copy semantics.  Used for views.  Since this is class sensitive, it must be overridden.
	virtual void clear ();  // Set all elements to zero.
	virtual void resize (const int rows, const int columns = 1) = 0;  // Change number of rows and columns.  Does not preserve data.

	// Higher level functions
	virtual T norm (int n) const;  // 0=infinity norm (ie: max), 1=one norm, 2=two norm, etc.
	virtual void normalize (const T scalar = 1.0);  // View matrix as vector and adjust so norm (2) == scalar.
	virtual T dot (const MatrixAbstract & B) const;  // View both matrices as vectors and return dot product.  Ie: returns the sum of the products of corresponding elements.
	virtual void identity (const T scalar = 1.0);  // Set main diagonal to scalar and everything else to zero.

	// Basic operations
	// The reason to have operators at this abstract level is to allow some
	// manipulation of matrices even if we know nothing of their storage
	// method.  The other possible motivation (laziness thru inheritance)
	// doesn't really pan out, since C++ tries to resolve an overloaded
	// function name in the current class rather than looking up the hierarchy.
	// However, polymorphism is still a valid motivation.
	// Only operations for which an acceptable general implementation exists
	// are listed here.  Because these are virtual, the signature of each
	// function becomes "nailed down" to one type for all subclasses.
	// Therefore, if a given return type is not universally useful, the
	// function can't be declared (or used) at this abstract level.
	// For basic arithmetic each class may have up to 24 operators:
	// 3 overloads for each of 8 operators: * / + - *= /= += -=
	// The overloads are for: 1) MatrixAbstract, 2) the current class,
	// and 3) a scalar.  A class may have more overloads if it wishes to
	// directly interract with other matrix classes.

	//virtual M<T> operator ! () const;  // Invert matrix (or create pseudo-inverse)
	//virtual M<T> operator ~ () const;  // Transpose matrix

	virtual Matrix<T> operator * (const MatrixAbstract & B) const;  // Multiply matrices: this * B
	//virtual M<T> operator * (const T scalar) const;  // Multiply each element by scalar
	//virtual M<T> operator / (const M<T> & B) const;  // result (i, j) = this (i, j) / B (i, j)
	//virtual M<T> operator / (const T scalar) const;  // Divide each element by scalar
	virtual Matrix<T> operator + (const MatrixAbstract & B) const;  // Elementwise sum.
	//virtual M<T> operator + (const T scalar) const;  // Add scalar to each element
	virtual Matrix<T> operator - (const MatrixAbstract & B) const;  // Elementwise difference.
	//virtual M<T> operator - (const T scalar) const;  // Subtract scalar from each element

	virtual MatrixAbstract & operator *= (const T scalar);  // this = this * scalar
	virtual MatrixAbstract & operator /= (const T scalar);  // this = this / scalar
	// The rest of the "=" operators also parallel the regular operators.

	// Serialization
	static MatrixAbstract * factory (std::istream & stream);  // Constructs any matrix class from a stream.
	virtual void read (std::istream & stream);
	virtual void write (std::ostream & stream, bool withName = true) const;

	// Global Data
	static int displayWidth;  // Number of character positions per cell to use when printing out matrix.
	static int displayPrecision;  // Number of significant digits to output.
  };


  // Concrete matrices  -------------------------------------------------------

  template <class T>
  class Matrix : public MatrixAbstract<T>
  {
  public:
	Matrix ();
	Matrix (const int rows, const int columns = 1);
	Matrix (const MatrixAbstract<T> & that);
	Matrix (std::istream & stream);
	virtual ~Matrix ();

	virtual T & operator () (const int row, const int column) const;
    virtual T & operator [] (const int row) const;
	virtual int rows () const;
	virtual int columns () const;
	virtual MatrixAbstract<T> * duplicate () const;
	virtual void clear ();
	virtual void resize (const int rows, const int columns = 1);
	virtual void copyFrom (const MatrixAbstract<T> & that);  // Deep copy
	virtual void copyFrom (const Matrix<T> & that);

	virtual T norm (int n) const;
	virtual T dot (const Matrix & B);

	virtual MatrixTranspose<T> operator ~ () const;
	virtual Matrix operator * (const MatrixAbstract<T> & B) const;
	virtual Matrix operator * (const Matrix & B) const;
	virtual Matrix operator * (const T scalar) const;
	virtual Matrix operator / (const T scalar) const;
	virtual Matrix operator + (const Matrix & B) const;
	virtual Matrix operator - (const Matrix & B) const;
	virtual Matrix & operator *= (const Matrix & B);
	virtual MatrixAbstract<T> & operator *= (const T scalar);
	virtual MatrixAbstract<T> & operator /= (const T scalar);

	virtual void read (std::istream & stream);
	virtual void write (std::ostream & stream, bool withName = true) const;

	// Data
	Pointer data;
	int rows_;
	int columns_;
  };

  // Vector is not a special class in this package.  All operations and
  // functions are on matrices.  Period.  This Vector class is
  // a specialization of Matrix that makes it more convenient to access
  // elements without referring to column 0 all the time.
  template <class T>
  class Vector : public Matrix<T>
  {
  public:
	Vector ();
	Vector (const int rows);
	Vector (const MatrixAbstract<T> & that);
	Vector (const Matrix<T> & that);
	Vector (std::istream & stream);

	virtual MatrixAbstract<T> * duplicate () const;
	virtual void resize (const int rows, const int columns = 1);
	virtual Vector & operator = (const Matrix<T> & that);
  };

  // This Matrix is presumed to be Symmetric.  It could also be Hermitian
  // or Triangular, but these require more specialization.  The whole point
  // of having this class is to take advantage of symmetry to cut down on
  // memory accesses.
  template <class T>
  class MatrixPacked : public MatrixAbstract<T>
  {
  public:
	MatrixPacked ();
	MatrixPacked (const int rows);  // columns = rows
	MatrixPacked (const MatrixAbstract<T> & that);
	MatrixPacked (std::istream & stream);

	virtual T & operator () (const int row, const int column) const;
    virtual T & operator [] (const int row) const;
	virtual int rows () const;
	virtual int columns () const;
	virtual MatrixAbstract<T> * duplicate () const;
	virtual void clear ();
	virtual void resize (const int rows, const int columns = -1);
	virtual void copyFrom (const MatrixAbstract<T> & that);

	virtual MatrixPacked operator ~ () const;

	// Data
	Pointer data;
	int rows_;  // columns = rows
  };


  // Views --------------------------------------------------------------------

  // These matrices wrap other matrices and provide a different interpretation
  // of the row and column coordinates.  Views are always "dense" in the sense
  // that every element maps to an element in the wrapped Matrix.  However,
  // they have no storage of their own.

  // Views do two jobs:
  // 1) Make it convenient to access a Matrix in manners other than dense.
  //    E.g.: You could do strided access without having to write out the
  //    index offsets and multipliers.
  // 2) Act as a proxy for some rearrangement of the Matrix in the next
  //    stage of calculation in order to avoid copying elements.
  //    E.g.: A Transpose view allows one to multiply a transposed Matrix
  //    without first moving all the elements to their tranposed positions.

  // this (i, j) maps to that (j, i)
  template <class T>
  class MatrixTranspose : public MatrixAbstract<T>
  {
  public:
	MatrixTranspose (const MatrixAbstract<T> & that);
	virtual ~MatrixTranspose ();

	virtual T & operator () (const int row, const int column) const;
    virtual T & operator [] (const int row) const;
	virtual int rows () const;
	virtual int columns () const;
	virtual MatrixAbstract<T> * duplicate () const;
	virtual void clear ();
	virtual void resize (const int rows, const int columns);

	// It is the job of the matrix being transposed to make another instance
	// of itself.  It is our responsibility to delete this object when we
	// are destroyed.
	MatrixAbstract<T> * wrapped;
  };

  template <class T>
  class MatrixRegion : public MatrixAbstract<T>
  {
  public:
	MatrixRegion (const MatrixAbstract<T> & that, const int firstRow, const int firstColumn, const int lastRow, const int lastColumn);
	virtual ~MatrixRegion ();

	virtual T & operator () (const int row, const int column) const;
    virtual T & operator [] (const int row) const;
	virtual int rows () const;
	virtual int columns () const;
	virtual MatrixAbstract<T> * duplicate () const;
	virtual void clear ();
	virtual void resize (const int rows, const int columns = 1);

	MatrixAbstract<T> * wrapped;
	int firstRow;
	int firstColumn;
	int rows_;
	int columns_;
  };


  // Small Matrix classes -----------------------------------------------------

  // There are two reasons for making small Matrix classes.
  // 1) Avoid overhead of managing memory.
  // 2) Certain numerical operations (such as computing eigenvalues) have
  //    direct implementations in small matrix sizes (particularly 2x2).

  template <class T>
  class Matrix2x2 : public MatrixAbstract<T>
  {
  public:
	Matrix2x2 ();
	Matrix2x2 (const MatrixAbstract<T> & that);
	Matrix2x2 (std::istream & stream);

	virtual T & operator () (const int row, const int column) const;
    virtual T & operator [] (const int row) const;
	virtual int rows () const;
	virtual int columns () const;
	virtual MatrixAbstract<T> * duplicate () const;
	virtual void resize (const int rows = 2, const int columns = 2);
	// We don't need copyFrom () because all assignments and constructors do
	// deep copy.

	virtual Matrix2x2<T> operator ! () const;
	virtual Matrix2x2<T> operator ~ () const;
	virtual Matrix<T> operator * (const MatrixAbstract<T> & B) const;
	inline Matrix2x2<T> operator * (const Matrix2x2<T> & B) const
	{
	  Matrix2x2<T> result;
	  result.data[0][0] = data[0][0] * B.data[0][0] + data[1][0] * B.data[0][1];
	  result.data[0][1] = data[0][1] * B.data[0][0] + data[1][1] * B.data[0][1];
	  result.data[1][0] = data[0][0] * B.data[1][0] + data[1][0] * B.data[1][1];
	  result.data[1][1] = data[0][1] * B.data[1][0] + data[1][1] * B.data[1][1];
	  return result;
	}
	inline Matrix2x2<T> operator * (const T scalar) const
	{
	  Matrix2x2<T> result;
	  result.data[0][0] = data[0][0] * scalar;
	  result.data[0][1] = data[0][1] * scalar;
	  result.data[1][0] = data[1][0] * scalar;
	  result.data[1][1] = data[1][1] * scalar;
	  return result;
	}
	inline Matrix2x2<T> operator / (const T scalar) const
	{
	  Matrix2x2<T> result;
	  result.data[0][0] = data[0][0] / scalar;
	  result.data[0][1] = data[0][1] / scalar;
	  result.data[1][0] = data[1][0] / scalar;
	  result.data[1][1] = data[1][1] / scalar;
	  return result;
	}
	virtual Matrix2x2<T> & operator *= (const Matrix2x2<T> & B);
	virtual MatrixAbstract<T> & operator *= (const T scalar);

	virtual void read (std::istream & stream);
	virtual void write (std::ostream & stream, bool withName = true) const;

	// Data
	T data[2][2];
  };

  template <class T>
  class Matrix3x3 : public MatrixAbstract<T>
  {
  public:
	Matrix3x3 ();
	Matrix3x3 (const MatrixAbstract<T> & that);
	Matrix3x3 (std::istream & stream);

	virtual T & operator () (const int row, const int column) const;
    virtual T & operator [] (const int row) const;
	virtual int rows () const;
	virtual int columns () const;
	virtual MatrixAbstract<T> * duplicate () const;
	virtual void resize (const int rows = 3, const int columns = 3);

	virtual Matrix<T> operator * (const MatrixAbstract<T> & B) const;

	virtual void read (std::istream & stream);
	virtual void write (std::ostream & stream, bool withName = true) const;

	// Data
	T data[3][3];
  };


  // Matrix operations --------------------------------------------------------

  // Dump human readable matrix.  Intended for printable output only.
  template <class T>
  inline std::ostream &
  operator << (std::ostream & stream, const MatrixAbstract<T> & A)
  {
	for (int r = 0; r < A.rows (); r++)
	{
	  if (r > 0)
	  {
		if (A.columns () > 1)
		{
		  stream << std::endl;
		}
		else  // This is really a vector, so don't break lines.
		{
		  stream << " ";
		}
	  }
	  std::string line;
	  for (int c = 0; c < A.columns (); c++)
	  {
		// Let ostream absord the variability in the type T of the matrix.
		// We may have to specialize this function for complex, since there
		// probably isn't an inserter for it.
		char temp[32];
		std::ostrstream formatted (temp, sizeof (temp));
		formatted.precision (A.displayPrecision);
		formatted << A (r, c) << ends;
		if (c > 0)
		{
		  line += ' ';
		}
		while (line.size () < c * A.displayWidth)
		{
		  line += ' ';
		}
		line += temp;
	  }
	  stream << line;
	}
	return stream;
  }

  // Load matrix from human-readable stream.  Not idempotent with the insertion
  // operator above, because this function expects to encounter number of rows
  // and columns as part of stream.  (However, one can easily output them
  // directly before using the above insertion operator.)
  template <class T>
  inline std::istream &
  operator >> (std::istream & stream, MatrixAbstract<T> & A)
  {
	int rows;
	int columns;
	stream >> rows >> columns;
	A.resize (rows, columns);

	for (int r = 0; r < rows; r++)
	{
	  for (int c = 0; c < columns; c++)
	  {
		stream >> A(r, c);
	  }
	}
	return stream;
  }

  // Convert from one numeric type to another.  Operator <<= acts similar to =.
  template <class T1, class T2>
  inline MatrixAbstract<T1> &
  operator <<= (MatrixAbstract<T1> & A, const MatrixAbstract<T2> & B)
  {
	int rows = B.rows ();
	int columns = B.columns ();
	A.resize (rows, columns);
	for (int c = 0; c < columns; c++)
	{
	  for (int r = 0; r < rows; r++)
	  {
		A(r,c) = B(r,c);
	  }
	}
	return A;
  }

  template <class T>
  inline void
  geev (const Matrix2x2<T> & A, Matrix<T> & eigenvalues)
  {
	// a = 1  :)
	T b = -(A.data[0][0] + A.data[1][1]);  // trace
	T c = A.data[0][0] * A.data[1][1] - A.data[0][1] * A.data[1][0];  // determinant
	T b4c = b * b - 4 * c;
	if (b4c < 0)
	{
	  throw "eigen: no real eigenvalues!";  // Obviously, this function will have to be specialized for complex numbers.
	}
	if (b4c > 0)
	{
	  b4c = sqrt (b4c);
	}
	eigenvalues.resize (2, 1);
	eigenvalues (0, 0) = (-b - b4c) / 2.0;
	eigenvalues (1, 0) = (-b + b4c) / 2.0;
  }
}


#endif
