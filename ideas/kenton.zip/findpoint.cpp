#include "../prompt.h"
#include "Vlib.h"
#include "interest.h"
#include "time.h"
#include "string.h"
#include <fstream>
#include <vector>

using std::vector;
using namespace std;
using namespace my;

double fstartTime;


//KenFix
#define cerr outw
#define endl endw

vector<PointInterest> foundpoints;


struct Picture
{
  string fileName;
  multiset<PointInterest> points;
};


Picture *
findPicture (vector<Picture> & pictures, const string & fileName)
{
  vector<Picture>::iterator i;
  for (i = pictures.begin (); i < pictures.end (); i++)
  {
	if (i->fileName == fileName)
	{
	  return &(*i);
	}
  }
  return NULL;
}

void
readInterest (const string & resumeFileName, vector<Picture> & pictures)
{
  int i = 0;	//KenFix

  ifstream resumeStream (resumeFileName.c_str ());
  if (! resumeStream.good ())
  {
	return;
  }

  int fileCount = 0;
  resumeStream.read ((char *) &fileCount, sizeof (fileCount));
  pictures.resize (fileCount);
  for (i = 0; i < pictures.size (); i++)
  {
	getline (resumeStream, pictures[i].fileName);

	int pointCount = 0;
	resumeStream.read ((char *) &pointCount, sizeof (pointCount));

	for (int j = 0; j < pointCount; j++)
	{
	  PointInterest p (resumeStream);
	  pictures[i].points.insert (p);
	}
  }

  // Clean out partial entries
  for (i = pictures.size () - 1; i >= 0; i--)
  {
	if (pictures[i].fileName.size () == 0  ||  pictures[i].points.size () == 0)
	{
	  pictures.erase (pictures.begin () + i);
	}
  }
}


//KenFix
int findpointmain(int argc, char * argv[])
{
  int i = 0;	//KenFix

  // Parse command line
  string outFileName = "";
  string resumeFileName = "";
  int maxpoints = 300;
  float threshold = 0.02;
  int nms = 1;
  int firstStep = 0;
  int lastStep = 7;
  vector<string> fileNames;
  for (i = 1; i < argc; i++)
  {
	string arg = argv[i];
	string name;
	string value;
	split (arg, "=", name, value);

	if (name.substr (0, 1) == "f")
	{
	  firstStep = atoi (value.c_str ());
	}
	else if (name.substr (0, 1) == "l")
	{
	  lastStep = atoi (value.c_str ());
	}
	else if (name.substr (0, 1) == "m")
	{
	  maxpoints = atoi (value.c_str ());
	}
	else if (name.substr (0, 1) == "n")
	{
	  nms = atoi (value.c_str ());
	}
	else if (name.substr (0, 1) == "o")
	{
	  outFileName = value;
	}
	else if (name.substr (0, 1) == "r")
	{
	  resumeFileName = value;
	}
	else if (name.substr (0, 1) == "t")
	{
	  threshold = atof (value.c_str ());
	}
    else
	{
	  fileNames.push_back (name);
	}
  }
  if (outFileName.size () == 0  ||  fileNames.size () == 0)
  {
	cerr << "Usage: " << argv[0] << " [parameters] {image file names}" << endl;
	cerr << "  out={point file name} (required)" << endl;
	cerr << "  resume={point file name} (default = none)" << endl;
	cerr << "  maxpoints={max number of points allowed} (default = 300)" << endl;
	cerr << "  threshold={threshold factor} (default = 0.02)" << endl;
	cerr << "  nms={size of neighborhood} (default = 1)" << endl;
	cerr << "  firststep={smallest scale level} (default = 0)" << endl;
	cerr << "  laststep={largest scale level} (default = 7)" << endl;
	return 1;
  }

  // Load from resume file, if any
  vector<Picture> pictures;
  if (resumeFileName.size () > 0)
  {
	readInterest (resumeFileName, pictures);
  }

  ofstream outStream(outFileName.c_str(), ios::binary);		//KenFix
  if (! outStream.good ())
  {
	cerr << "Failed to open output file " << outFileName << endl;
	return 1;
  }

  // Select an interest operator
  InterestHarrisLaplacian interest (maxpoints, threshold, nms, firstStep, lastStep);

  int fileCount = fileNames.size ();
  outStream.write ((char *) &fileCount, sizeof (fileCount));

  for (i = 0; i < fileCount; i++)
  {
	fstartTime = getTimestamp ();

	outStream << fileNames[i] << endl;

	cerr << fileNames[i] << " ";

	multiset<PointInterest> points;
	Picture * picture = findPicture (pictures, fileNames[i]);
	if (picture)
	{
	  cerr << "resumed " << endl;
	  points = picture->points;
	}
	else
	{
	  Image image;
	  image.read (fileNames[i]);
	  image *= GrayFloat;		//KenLook
	  interest.run (image, points);
	}

	int pointCount = points.size ();
	outStream.write ((char *) &pointCount, sizeof (pointCount));

	foundpoints.clear();
	multiset<PointInterest>::iterator p;
	for (p = points.begin (); p != points.end (); p++)
	{
	  ((PointInterest &) *p).write(outStream);
	  foundpoints.push_back(*p);	  //KenFix: Save to view
	}

	outStream.close();
	cerr << getTimestamp () - fstartTime << endl;
  }

  return 0;
}
