#ifndef pointer_h
#define pointer_h


#include <stdlib.h>
#include <string.h>
#include <ostream>


namespace my
{
  // Keeps track of a block of memory, which can be shared by multiple objects
  // and multiple threads.  The block can either be managed by Pointer, or
  // it can belong to any other part of the system.  Only managed blocks get
  // reference counting, automatic deletion, and reallocation.
  // This class is intended to be thread-safe, but in its current state it is
  // not.  Need to implement a semaphore
  // of some sort for the reference count.  IE: use an atomic operation such
  // as XADD that includes an exchange.
  class Pointer
  {
  public:
	Pointer ()
	{
	  memory = 0;
	  hasMetaData = false;
	}
	Pointer (const Pointer & that)
	{
	  attach (that);
	}
	Pointer (void * that)
	{
	  memory = that;
	  hasMetaData = false;
	}
	Pointer (int size)
	{
	  allocate (size);
	}
	~Pointer ()
	{
	  release ();
	}

	Pointer & operator = (const Pointer & that)
	{
	  if (that.memory != memory)
	  {
		release ();
		attach (that);
	  }
	  return *this;
	}
	Pointer & operator = (void * that)
	{
	  release ();
	  memory = that;
	  hasMetaData = false;
	  return *this;
	}
	void copyFrom (const Pointer & that)
	{
	  if (that.memory != memory)
	  {
		int size = that.size ();
		if (! that.memory  ||  size == 0)
		{
		  release ();
		}
		else
		{
		  if (size < 0)
		  {
			throw "Don't know size of block to copy";
		  }
		  grow (size);
		  memcpy (memory, that.memory, size);
		}
	  }
	}
	void copyFrom (const void * that, int size)
	{
	  if (size <= 0)
	  {
		release ();
	  }
	  else if (that != memory)
	  {
		grow (size);
		memcpy (memory, that, size);
	  }
	}
	void grow (int size)
	{
	  if (hasMetaData)
	  {
		if (((int *) memory)[-2] >= size)
		{
		  return;
		}
		release ();
	  }
	  allocate (size);
	}
	void clear ()  // Erase block of memory
	{
	  if (hasMetaData)
	  {
		memset (memory, 0, ((int *) memory)[-2]);
	  }
	  else
	  {
		throw "Don't know size of block to clear";
	  }
	}
	int refcount () const
	{
	  if (hasMetaData)
	  {
		return ((int *) memory)[-1];
	  }
	  return -1;
	}
	int size () const
	{
	  if (hasMetaData)
	  {
		return ((int *) memory)[-2];
	  }
	  return -1;
	}
	operator char * () const
	{
	  return (char *) memory;
	}
	operator unsigned char * () const
	{
	  return (unsigned char *) memory;
	}
	operator short * () const
	{
	  return (short *) memory;
	}
	operator unsigned short * () const
	{
	  return (unsigned short *) memory;
	}
	operator int * () const
	{
	  return (int *) memory;
	}
	operator unsigned int * () const
	{
	  return (unsigned int *) memory;
	}
	operator float * () const
	{
	  return (float *) memory;
	}
	operator double * () const
	{
	  return (double *) memory;
	}

	// Functions mainly for internal use

	void release ()
	{
	  if (hasMetaData)
	  {
		if (--((int *) memory)[-1] == 0)
		{
		  free ((int *) memory - 2);
		}
	  }
	  memory = 0;
	  hasMetaData = false;
	}

  protected:
	void attach (const Pointer & that)
	{
	  memory = that.memory;
	  hasMetaData = that.hasMetaData;
	  if (hasMetaData)
	  {
		((int *) memory)[-1]++;
	  }
	}
	void allocate (int size)
	{
	  memory = malloc (size + 2 * sizeof (int));
	  if (memory)
	  {
		memory = (int *)memory + 2;		//KenFix
		((int *) memory)[-1] = 1;
		((int *) memory)[-2] = size;
		hasMetaData = true;
	  }
	  else
	  {
		hasMetaData = false;
		throw "Unable to allocate memory";
	  }
	}

  public:
	void * memory;  // Pointer to block in heap.  Must cast as needed.
	bool hasMetaData;  // Indicates if memory is a special pointer we constructed.  If so, then there is refCount info associated with the pointer.  If not, it can be any block in memory, and we leave it alone.  We cannot even delete it.
  };

  inline std::ostream &
  operator << (std::ostream & stream, const Pointer & pointer)
  {
	stream << "[" << pointer.memory << " " << pointer.size () << " " << pointer.refcount () << "]";
	return stream;
  }
}


#endif
