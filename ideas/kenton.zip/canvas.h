#ifndef canvas_h
#define canvas_h


#include "point.h"
#include "matrix.h"
#include "image.h"
#include "pi.h"

#include <vector>
#include <string>
#include <fstream>


namespace my
{
  // Generic Canvas interface -------------------------------------------------

  // An abstract 2D drawing surface.
  class Canvas
  {
  public:
	virtual ~Canvas ();
	virtual void drawDone ();  // Do any final steps to output the drawing.  After this, the effect of draw commands is undefined.

	// Drawing functions are the primary interface
	virtual void drawPoint (const Point & p, unsigned int color = 0xFFFFFF);
	virtual void drawSegment (const Point & a, const Point & b, unsigned int color = 0xFFFFFF);
	virtual void drawLine (float a, float b, float c, unsigned int color = 0xFFFFFF);  // Draws the set ax + by + c = 0
	virtual void drawRay (const Point & p, float angle, unsigned int color = 0xFFFFFF);
	virtual void drawPolygon (const std::vector<Point> & points, unsigned int color = 0xFFFFFF);
	virtual void drawCircle (const Point & center, float radius, unsigned int color = 0xFFFFFF, float startAngle = 0, float endAngle = 2 * PI);
	virtual void drawEllipse (const Point & center, const Matrix2x2<float> & shape, unsigned int color = 0xFFFFFF, float startAngle = 0, float endAngle = 2 * PI);  // Draws the set ~x * shape * x == 1
	virtual void drawText (const std::string & text, const Point & point, float size = 10, float angle = 0, unsigned int color = 0xFFFFFF);

	// State information
	virtual void setTranslation (float x, float y);  // Location of origin in this Canvas' coordinate system.
	virtual void setScale (float x, float y);  // Multiply all coordinates by a factor.  Scaling is done before translation.
	virtual void setLineWidth (float width);  // Width of pen for stroking lines, in native units.
  };


  // Specific Canvas implementations ------------------------------------------

  class CanvasImage : public Canvas, public Image
  {
  public:
	CanvasImage (const PixelFormat & format = GrayChar);
	CanvasImage (int width, int height, const PixelFormat & format = GrayChar);
	CanvasImage (const Image & that);
	void initialize ();
	virtual ~CanvasImage ();

	virtual void drawPoint (const Point & p, unsigned int color = 0xFFFFFF);
	virtual void drawSegment (const Point & a, const Point & b, unsigned int color = 0xFFFFFF);
	virtual void drawLine (float a, float b, float c, unsigned int color = 0xFFFFFF);
	virtual void drawRay (const Point & p, float angle, unsigned int color = 0xFFFFFF);
	virtual void drawPolygon (const std::vector<Point> & points, unsigned int color = 0xFFFFFF);
	virtual void drawCircle (const Point & center, float radius, unsigned int color = 0xFFFFFF, float startAngle = 0, float endAngle = 2 * PI);
	virtual void drawEllipse (const Point & center, const Matrix2x2<float> & shape, unsigned int color = 0xFFFFFF, float startAngle = 0, float endAngle = 2 * PI);

	virtual void setTranslation (float x, float y);
	virtual void setScale (float x, float y);
	virtual void setLineWidth (float width);

	Point trans (const Point & p);
	void pen (const Point & p, unsigned int color);

	float transX;
	float transY;
	float scaleX;
	float scaleY;
	ImageOf<unsigned char> penTip;
  };

  // Outputs drawing as a Postscript file
  class CanvasPS : public Canvas
  {
  public:
	CanvasPS (const std::string & fileName, float width, float height);  // width and height are in points.  They are used to determine %%BoundingBox.
	virtual ~CanvasPS ();
	virtual void drawDone ();

	virtual void drawPoint (const Point & p, unsigned int color = 0);
	virtual void drawSegment (const Point & a, const Point & b, unsigned int color = 0);
	virtual void drawPolygon (const std::vector<Point> & points, unsigned int color = 0);
	virtual void drawCircle (const Point & center, float radius, unsigned int color = 0, float startAngle = 0, float endAngle = 2 * PI);
	virtual void drawEllipse (const Point & center, const Matrix2x2<float> & shape, unsigned int color = 0, float startAngle = 0, float endAngle = 2 * PI);

	virtual void setTranslation (float x, float y);
	virtual void setScale (float x, float y);

	void expandColor (unsigned int color);

	std::ofstream psf;  // "Postscript file"
	float scale;  // Used to compute line widths.
	float bboxT;  // Top of bounding box in points
	float bboxB;  // Bottom
	float bboxL;  // Left
	float bboxR;  // Right
  };
}


#endif
