#include "../prompt.h"
#include "interest.h"
#include "time.h"
#include "matrix.h"
#include "string.h"
#include "lapack.h"
#include "pi.h"
#include <fstream>

using namespace std;
using namespace my;

double startTime;
bool trace = false;

// For debugging
//#include "slideshow.h"
//SlideShow window;

//KenFix
#define cerr outw
#define endl endw

vector<PointInterestAffine> correctpoints;


vector<Laplacian> laplacians;
int supportPixel = 50;  // Pixel radius of working patch during iteration (size of patch = 2 * supportPixel)
double scaleNeutral;
double scaleQuantum = 1.4;

void
constructScales ()
{
  double maxScale = supportPixel / Gaussian2D::cutoff;
  double stepSize = pow (scaleQuantum, 0.05);
  int maxStep = (int) (log (maxScale) / log (stepSize));
  cerr << "maxScale = " << maxScale << endl;
  cerr << "stepSize = " << stepSize << endl;
  cerr << "maxStep = " << maxStep << endl;
  cerr << "creating scales: ";
  bool gotNeutral = false;
  scaleNeutral = (maxScale - 1.0) / 2.0;
  for (int s = 0; s <= maxStep; s++)
  {
	double scale = pow (stepSize, s);
	cerr << scale << " ";
    Laplacian l (scale, GrayDouble);
    l *= scale * scale;
    laplacians.push_back (l);
	if (! gotNeutral  &&  scale >= scaleNeutral)
	{
	  scaleNeutral = scale;
	  gotNeutral = true;
	}
  }
  cerr << endl;
  cerr << "scaleNeutral = " << scaleNeutral << " " << gotNeutral << endl;
}

inline double
searchIntegrationScale (const Image & image, PointInterestAffine & p)
{
  int width = 2 * supportPixel + 1;
  Point mid (supportPixel, supportPixel);

  Image patch;
  double scaleFactor = scaleNeutral / p.scale;
  if (scaleFactor >= 1.0)  // Zooming up; bilinear interpolation is better
  {
	Transform rectify (p.A, true);
	rectify = Transform (scaleFactor, scaleFactor) * rectify;
	rectify.setPeg (p.x, p.y, width, width);
	patch = image * rectify;
  }
  else  // Zooming down; Gaussian interpolation is better
  {
	TransformGauss rectify (p.A, true);
	rectify = TransformGauss (scaleFactor, scaleFactor) * rectify;
	rectify.setPeg (p.x, p.y, width, width);
	patch = image * rectify;
  }
  //window.clear ();
  //window.show (patch);

  vector<double> responses;
  vector<Laplacian>::iterator l;
  for (l = laplacians.begin (); l < laplacians.end (); l++)
  {
	responses.push_back (fabs (l->response (patch, mid)));
  }

  vector<double> maxima;
  for (int i = 1; i < responses.size () - 1; i++)
  {
	// Determine first and second derivatives of curve by least squares regression
	int start = (i - 5 > 0) ? i - 5 : 0;		//KenFix
	int stop  = (i + 5 < responses.size() - 1) ? i + 5 : responses.size() - 1;	//KenFix
	Matrix<double> X (stop - start + 1, 3);
	Vector<double> Y (stop - start + 1);
	for (int j = start; j <= stop; j++)
	{
	  int row = j - start;
	  double x = laplacians[j].sigma;
	  X(row, 0) = 1;
	  X(row, 1) = x;
	  X(row, 2) = x * x;
	  Y[row] = responses[j];
	}
	Matrix<double> a;
	//Matrix<double> Xt = ~X;
	//a = ! (Xt * X) * Xt * Y;
	gelss (X, a, Y);

	// See if current point is nearest to a local maximum
	if (a[2] < 0)  // We can require a more distinct maximum by making the threshold on a[2] more negative.
	{
	  double x = laplacians[i].sigma;
	  double cx = - a[1] / (2 * a[2]);  // "critical x"
	  double dx  = fabsf (cx - x);
	  double dx0 = fabsf (cx - laplacians[i - 1].sigma);
	  double dx1 = fabsf (cx - laplacians[i + 1].sigma);
	  if (dx <= dx0  &&  dx < dx1)
	  {
		maxima.push_back (cx / scaleFactor);
	  }
	}
  }

  // Find the local maximum closest to neutral scale.
  double result = 0;
  double bestRatio = 200;
cerr << "maxima = " << (int)maxima.size () << endl;		//KenFix
  vector<double>::iterator itr;
  for (itr = maxima.begin (); itr < maxima.end (); itr++)
  {
	if (*itr < 1.0 / scaleQuantum  ||  *itr > 20.0 / scaleQuantum)
	{
	  continue;
	}
	double ratio = *itr / p.scale;
	ratio = ratio >= 1 ? ratio : 1 / ratio;  // ratio becomes a measure of how far we are from neutral scale.
cerr << "  " << *itr << " " << ratio << endl;
	if (ratio < bestRatio)
	{
	  bestRatio = ratio;
	  result = *itr;
	}
  }

  if (result == 0)
  {
	return p.scale;
  }

  return result * scaleQuantum;  // Inflate the value
}

void
searchDerivationScale (const Image & patch, double integrationScale, FilterHarris & bestFilter)
{
  int center = patch.width / 2;

  double bestRatio = 0;
double ss = 0;
  for (double s = 0.5; s < 0.75; s *= 1.1)
  {
	FilterHarris filter (integrationScale, s, GrayDouble);
	filter.preprocess (patch);
	int offsetD = filter.offsetD;
	Point cp (center - offsetD, center - offsetD);
	Matrix2x2<double> mu;
	mu (0, 0) = filter.G_I.response (filter.xx, cp);
	mu (0, 1) = filter.G_I.response (filter.xy, cp);
	mu (1, 0) = mu (0, 1);
	mu (1, 1) = filter.G_I.response (filter.yy, cp);
	Matrix<double> ev;
	geev (mu, ev);
	double ratio = ev[0] / ev[1];
	if (ratio > bestRatio)
	{
	  bestRatio = ratio;
	  bestFilter = filter;
ss = s;
	}
  }
//cerr << "best filter " << ss << endl;
}

bool
affineCorrection (const Image & image, PointInterestAffine & p)
{
cerr << "------------------------------------------" << endl; 
  float lastRatio = 0;
  int lastImprovement = 0;
  Matrix2x2<double> U;
  U <<= p.A;
  while (true)
  {
cerr << p.x << " " << p.y << " " << p.scale << endl;

    // Find scale
    p.scale = searchIntegrationScale (image, p);

	// Find best derivation scale and its associated Harris function
	int half = (int) rint (Gaussian2D::cutoff * 1.8 * ((p.scale > 1.0) ? p.scale : 1.0));  // 1.8 = 1.0 for integration scale + 0.8 for derivation scale (should be larger than max value in searchDerivationScale ())	//KenFix
	int width = 2 * half + 1;
	Transform rectify (p.A, true);
	rectify.setPeg (p.x, p.y, width, width);
	Image patch = image * rectify;
	FilterHarris bestFilter;
	searchDerivationScale (patch, p.scale, bestFilter);

	// Find new center using Harris measure
	ImageOf<double> harris = bestFilter.process ();
	int offset = bestFilter.offset;
	harris *= NonMaxSuppress (1);
	int closestX;
	int closestY;
	float closestDistance = 1e30;
	for (int x = 0; x < harris.width; x++)
	{
	  for (int y = 0; y < harris.height; y++)
	  {
		if (harris (x, y) != 0)
		{
		  float dx = (x + offset) - half;
		  float dy = (y + offset) - half;
		  float d = dx * dx + dy * dy;
		  if (d < closestDistance)
		  {
			closestDistance = d;
			closestX = x;
			closestY = y;
			p.weight = harris (x, y);
		  }
		}
	  }
	}

	// Update location of interest point
	Vector<float> d (2);
	d[0] = (closestX + offset) - half;
	d[1] = (closestY + offset) - half;
	d = p.A * d;
	p.x += d[0];
	p.y += d[1];

	// Update transformation
    Matrix<double> mu (2, 2);
	int offsetI = bestFilter.offsetI;
	Point cp (closestX + offsetI, closestY + offsetI);
	mu (0, 0) = bestFilter.G_I.response (bestFilter.xx, cp);
	mu (0, 1) = bestFilter.G_I.response (bestFilter.xy, cp);
	mu (1, 0) = mu (0, 1);
	mu (1, 1) = bestFilter.G_I.response (bestFilter.yy, cp);

	Matrix<double> dummy;
    Vector<double> S;
	Matrix<double> V;
	gesvd (mu, dummy, S, V);
	Matrix2x2<double> D;
	D.clear ();
	D(0,0) = 1.0 / sqrt (S[0]);
	D(1,1) = 1.0 / sqrt (S[1]);
	D /= sqrt (D(0,0) * D(1,1));
    double ratio = D(0,0) / D(1,1);
	mu = V * D * ~V;
	U = mu * U;
	p.A <<= U;

	// Check for ending conditions
	geev (U, S);
//cerr << "eigenvalues of U: " << S[0] << " " << S[1] << endl;
	if (S[1] / S[0] > 6)
	{
//cerr << "ending because ratio got too high " << S[1] / S[0] << endl;
	  return false;
	}
	//p.A /= S[1];

	// Check ratio of eigenvalues of mu for termination condition
//cerr << "ratio: " << ratio << endl;
    if (isnan (ratio)  ||  isinf (ratio)  ||  ratio <= 0)
	{
	  return false;
	}
	if (ratio > 0.97)
	{
//cerr << "ending because mu is almost isotropic" << endl;
	  break;
	}
	if (ratio > lastRatio)
	{
	  lastRatio = ratio;
	  lastImprovement = 0;
	}
	else
	{
	  lastImprovement++;
	  if (lastImprovement > 20)
	  {
		return false;
	  }
	}
  }
cerr << p.x << " " << p.y << " " << p.scale << endl;

//KenFix
//cerr << p.A << endl;
cerr <<p.A(0,0)<<" "<<p.A(0,1)<<endl;
cerr <<p.A(1,0)<<" "<<p.A(1,1)<<endl;

  return true;
}

//KenFix
int correctpointmain(int argc, char * argv[])
{
  int i, j;

  // Parse command line
  string pointFileName = "";
  string outFileName = "";
  float nmsDistance = 5;
  for (i = 1; i < argc; i++)
  {
	string arg = argv[i];
	string name;
	string value;
	split (arg, "=", name, value);

	if (name.substr (0, 1) == "n")
	{
	  nmsDistance = atof (value.c_str ());
	}
	else if (name.substr (0, 1) == "o")
	{
	  outFileName = value;
	}
	else if (name.substr (0, 1) == "p")
	{
	  pointFileName = value;
	}
    else
	{
	  cerr << "Unrecognized parameter: " << name << endl;
	}
  }
  if (pointFileName.size () == 0  ||  outFileName.size () == 0)
  {
	cerr << "Usage: " << argv[0] << " [parameters]" << endl;
	cerr << "  point={point file name} (required)" << endl;
	cerr << "  out={corrected point file name} (required)" << endl;
	cerr << "  nms={distance for non-max suppression} (default = 5 pixels)" << endl;
	return 1;
  }

  std::ofstream outStream(outFileName.c_str(), ios::binary);		//KenFix
  if (! outStream.good ())
  {
	cerr << "Failed to open output file " << outFileName << endl;
	return 1;
  }

  std::ifstream pointStream(pointFileName.c_str(), ios::binary);	//KenFix
  if (! pointStream.good ())
  {
	cerr << "Failed to open point file " << pointFileName << endl;
	return 1;
  }

  constructScales ();

  int fileCount = 0;
  pointStream.read ((char *) &fileCount, sizeof (fileCount));
  outStream.write ((char *) &fileCount, sizeof (fileCount));

  for (i = 0; i < fileCount; i++)
  {
	startTime = getTimestamp ();

	string fileName;
	getline (pointStream, fileName);
	outStream << fileName << endl;
	cerr << fileName << " ";

	// Read points
	int pointCount = 0;
	pointStream.read ((char *) &pointCount, sizeof (pointCount));
	vector<PointInterest> points;
	for (j = 0; j < pointCount; j++)
	{
	  PointInterest p (pointStream);
	  points.push_back (p);
	}

	//vector<PointInterest>::iterator b = points.begin ();
	//vector<PointInterest>::iterator e = points.end ();
	//points.erase (b, e - 5);

	// Perform affine correction
	Image image;
	image.read (fileName);
	image *= GrayDouble;
	vector<PointInterestAffine> apoints;
	for (j = 0; j < points.size (); j++)
	{
	  PointInterestAffine a (points[j]);
	  try
	  {
		if (affineCorrection (image, a))
		{
		  apoints.push_back (a);
		}
	  }
	  catch (char * message)
	  {
		cerr << message << endl;
	  }
	  catch (...)
	  {
		cerr << "Point lost due to exception" << endl;
	  }
	}

	// Suppress close points
cerr << "suppress close points" << endl;
	for (j = apoints.size () - 1; j >= 0; j--)
	{
	  for (int k = 0; k < apoints.size (); k++)
	  {
		if (k != j)
		{
		  float dx = apoints[j].x - apoints[k].x;
		  float dy = apoints[j].y - apoints[k].y;
		  float d = sqrt (dx * dx + dy * dy);
		  if (d < nmsDistance  &&  apoints[k].weight >= apoints[j].weight)
		  {
			apoints.erase (apoints.begin () + j);
			break;
		  }
		}
	  }
	}

	// Determine characteristic angle of each point
cerr << "compute characteristic angles" << endl;
	int patchSize = 50;
	float supportRadial = 3.0;
	float half = patchSize / 2.0;
	int mid = (int) rint ((patchSize - 1) / 2.0);
	Point middle (mid, mid);
	GaussianDerivativeFirst Gx (0, half / supportRadial);
	GaussianDerivativeFirst Gy (1, half / supportRadial);
	for (int j = 0; j < apoints.size (); j++)
	{
	  PointInterestAffine & p = apoints[j];
	  Transform rectify (p.A * (half / (supportRadial * p.scale)));
	  rectify.setPeg (p.x, p.y, patchSize, patchSize);
	  Image patch = image * rectify;
	  p.angle = atan2 (Gy.response (patch, middle), Gx.response (patch, middle));
	}

	// Write points
	correctpoints.clear();
	pointCount = apoints.size ();
	outStream.write ((char *) &pointCount, sizeof (pointCount));
	for (j = 0; j < pointCount; j++)
	{
	  apoints[j].write(outStream);

	  //KenFix: Save to view
	  correctpoints.push_back(apoints[j]);
	}

	outStream.close();
	cerr << getTimestamp () - startTime << endl;
  }

  return 0;
}
