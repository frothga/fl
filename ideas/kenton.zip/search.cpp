#include "VCFix.h"
#include "search.h"


using namespace my;


// class AnnealingAdaptive ----------------------------------------------------

Vector<double> 
AnnealingAdaptive::search (Searchable & searchable)
{
  // Select a starting point
  int dimension = searchable.dimension ();
  Vector<double> result (dimension);
  for (int i = 0; i < dimension; i++)
  {
	double min = searchable.min (i);
	double max = searchable.max (i);
	result[i] = (min + max) / 2.0;
  }

// STOPPED HERE ------------------------------------------------------------
  // The basic algorithm is:
  // maintain
  //   a current distance d
  //   a current point p
  //   a failure count f
  // loop: generate a vector v of length d in a random direction
  // p' = p + v
  // if p' is better than p, then p = p' and loop
  // otherwise, f++
  // if f > dimension, then d /= 2 and f = 0 and loop

  //KenFix
  Vector<double> tmp;
  return tmp;
}
