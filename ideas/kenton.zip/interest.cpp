#include "VCFix.h"
#include "../prompt.h"
#include "interest.h"

#include <math.h>

// Include for debugging
#include "time.h"

//KenFix
#define cerr outw
#define endl endw

using namespace std;
using namespace my;


// class InterestHarris -------------------------------------------------------

InterestHarris::InterestHarris (int neighborhood, int maxPoints, float thresholdFactor)
: nms (neighborhood)
{
  this->maxPoints       = maxPoints;
  this->thresholdFactor = thresholdFactor;
}

void
InterestHarris::run (const Image & image, multiset<PointInterest> & result)
{
  int offset = filter.offset;

  Image i = image * filter;
  i *= nms;
  float threshold = nms.average * thresholdFactor;

  ImageOf<float> ifloat (image);
  ImageOf<unsigned char> ichar (image);
  result.clear ();

  for (int x = 0; x < i.width; x++)
  {
	for (int y = 0; y < i.height; y++)
	{
	  float pixel;
	  if (*image.format == GrayFloat)
	  {
		pixel = ifloat (x, y);
	  }
	  else
	  {
		pixel = ichar (x, y);
	  }
	  if (pixel > threshold)
	  {
		PointInterest p;
		p.x = x + offset;
		p.y = y + offset;
		p.weight = pixel;
		result.insert (p);
		if (result.size () > maxPoints)
		{
		  result.erase (result.begin ());
		}
	  }
	}
  }
}


// class InterestHarrisLaplacian ----------------------------------------------

InterestHarrisLaplacian::InterestHarrisLaplacian (int maxPoints, float thresholdFactor, int neighborhood, int firstStep, int lastStep, float stepSize)
: nms (neighborhood)
{
  int s = 0;	//KenFix
  this->maxPoints       = maxPoints;
  this->thresholdFactor = thresholdFactor;

  if (stepSize < 0)
  {
	stepSize = sqrt (2.0);
  }
  for (s = firstStep; s <= lastStep; s++)
  {
	float scale = pow (stepSize, s);
	FilterHarris h (scale);
	filters.push_back (h);
  }

  float maxScale = pow (stepSize, lastStep) * 1.5;
  stepSize = pow (stepSize, 1.0 / 3.0);
  lastStep = (int) (log (maxScale) / log (stepSize));
cerr << "lastStep = " << lastStep << endl;
cerr << "maxScale = " << maxScale << endl;
cerr << "creating scales: ";
  for (s = 0; s <= lastStep; s++)
  {
	float scale = pow (stepSize, s);
cerr << scale << " ";
	scales.push_back (scale);
	Laplacian l (scale);
	l *= scale * scale;
	laplacians.push_back (l);
  }
cerr << endl;
}


//KenFix
#define max(a,b)  (a)>(b)? (a) : (b)
#define min(a,b)  (a)<(b)? (a) : (b)

void
InterestHarrisLaplacian::run (const Image & image, std::multiset<PointInterest> & result)
{
  ImageOf<float> work = image * GrayFloat;

  ImageOf<float> maxImage (work.width, work.height, GrayFloat);
  maxImage.clear ();
double startTime;
  for (int i = 0; i < filters.size (); i++)
  {
cerr << "filter " << i << endl;
startTime = getTimestamp ();
    //int offset = max (filters[i].G1.width, filters[i].dG.width) / 2;
    //int offsetX = filters[i].G.width / 2 + offset;
    //int offsetY = filters[i].G.height / 2 + offset;
    int offset = filters[i].offset;

	ImageOf<float> filtered = work * filters[i];
	filtered *= nms;
cerr << "  took " << getTimestamp () - startTime << endl;
startTime = getTimestamp ();

	for (int x = 0; x < filtered.width; x++)
	{
	  for (int y = 0; y < filtered.height; y++)
	  {
		//float & target = maxImage.pixelGrayFloat (x + offsetX, y + offsetY);
		float & target = maxImage (x + offset, y + offset);
		float & source = filtered (x, y);
		target = max (target, source);
	  }
	}
cerr << "  max " << getTimestamp () - startTime << endl;
  }

startTime = getTimestamp ();
  maxImage *= nms;
cerr << "nms " << getTimestamp () - startTime << endl;
  float threshold = nms.average * thresholdFactor;

  result.clear ();

startTime = getTimestamp ();
  for (int x = 0; x < maxImage.width; x++)
  {
	for (int y = 0; y < maxImage.height; y++)
	{
	  float pixel = maxImage (x, y);
	  if (pixel > threshold)
	  {
		PointInterest p;
		p.weight = pixel;
		p.x = x;
		p.y = y;
		result.insert (p);
		if (result.size () > maxPoints)
		{
		  result.erase (result.begin ());
		}
	  }
	}
  }
cerr << "thresholding " << getTimestamp () - startTime << endl;

  // Calculate natural scale for each selected interest point using Laplacian
  multiset<PointInterest>::iterator p;
  for (p = result.begin (); p != result.end (); p++)
  {
	float maxResponse = 0;
	int maxScale = 1;
	for (int j = 0; j < laplacians.size (); j++)
	{
	  float response = fabs (laplacians[j].response (image, *p));

	  if (response > maxResponse)
	  {
		maxResponse = response;
		maxScale = j;
	  }
	}
	((PointInterest &) *p).scale = scales[maxScale];
  }
}
