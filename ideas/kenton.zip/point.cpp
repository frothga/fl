#include "VCFix.h"
#include "point.h"


using namespace std;
using namespace my;


// class Point ----------------------------------------------------------------

Point::Point ()
{
  x = 0;
  y = 0;
}

Point::Point (float x, float y)
{
  this->x = x;
  this->y = y;
}

Point::Point (std::istream & stream)
{
  read (stream);
}

void
Point::read (std::istream & stream)
{
  stream.read ((char *) &x, sizeof (x));
  stream.read ((char *) &y, sizeof (y));
}

void
Point::write (std::ostream & stream)
{
  stream.write ((char *) &x, sizeof (x));
  stream.write ((char *) &y, sizeof (y));
}


// class PointInterest --------------------------------------------------------

PointInterest::PointInterest ()
: Point ()
{
  weight = 0;
  scale = 1;
}

PointInterest::PointInterest (const Point & p)
: Point (p)
{
  weight = 0;
  scale = 1;
}

PointInterest::PointInterest (std::istream & stream)
{
  read (stream);
}

void
PointInterest::read (std::istream & stream)
{
  Point::read (stream);
  stream.read ((char *) &weight, sizeof (weight));
  stream.read ((char *) &scale,  sizeof (scale));
}

void
PointInterest::write (std::ostream & stream)
{
  Point::write (stream);
  stream.write ((char *) &weight, sizeof (weight));
  stream.write ((char *) &scale,  sizeof (scale));
}


// class PointInterestAffine -------------------------------------------------

PointInterestAffine::PointInterestAffine ()
: PointInterest ()
{
  A.identity ();
  angle = 0;
}

PointInterestAffine::PointInterestAffine (const PointInterest & p)
: PointInterest (p)
{
  A.identity ();
  angle = 0;
}

PointInterestAffine::PointInterestAffine (std::istream & stream)
{
  read (stream);
}

void
PointInterestAffine::read (std::istream & stream)
{
  PointInterest::read (stream);
  A.read (stream);
  stream.read ((char *) &angle, sizeof (angle));
}

void
PointInterestAffine::write (std::ostream & stream)
{
  PointInterest::write (stream);
  A.write (stream, false);
  stream.write ((char *) &angle, sizeof (angle));
}
