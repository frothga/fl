#ifndef matrix_tcc
#define matrix_tcc

#include<string>

using std::string;

#pragma warning(disable : 4541)


namespace my
{
  // class MatrixAbstract<T> --------------------------------------------------

  template <class T>
  int MatrixAbstract<T>::displayWidth = 10;

  template <class T>
  int MatrixAbstract<T>::displayPrecision = 6;

  template <class T>
  MatrixAbstract<T>::~MatrixAbstract ()
  {
  }

  template <class T>
  T &
  MatrixAbstract<T>::operator [] (const int row) const
  {
	return (*this) (row / rows (), row % rows ());
  }

  template <class T>
  int
  MatrixAbstract<T>::rows () const
  {
	return 0;
  }

  template <class T>
  int
  MatrixAbstract<T>::columns () const
  {
	return 0;
  }

  template <class T>
  void
  MatrixAbstract<T>::clear ()
  {
	int h = rows ();
	int w = columns ();
	for (int c = 0; c < w; c++)
	{
	  for (int r = 0; r < h; r++)
	  {
		(*this) (r, c) = 0;
	  }
	}
  }

  template <class T>
  T
  MatrixAbstract<T>::norm (int n) const
  {
	// Some of this code may have to be modified for complex numbers.
	int h = rows ();
	int w = columns ();
	switch (n)
	{
	  case 0:  // Use zero as stand-in for infinity
	  {
		T result = (*this) (0, 0);
		for (int c = 0; c < w; c++)
		{
		  for (int r = 0; r < h; r++)
		  {
			result = ((*this) (r, c) > result) ? (*this) (r, c) : result;	//KenFix
		  }
		}
		return result;
	  }
	  case 1:
	  {
		T result = 0;
		for (int c = 0; c < w; c++)
		{
		  for (int r = 0; r < h; r++)
		  {
			result += (*this) (r, c);
		  }
		}
		return result;
	  }
	  case 2:
	  {
		T result = 0;
		for (int c = 0; c < w; c++)
		{
		  for (int r = 0; r < h; r++)
		  {
			T t = (*this) (r, c);
			result += t * t;
		  }
		}
		return sqrt (result);
	  }
	  default:
	  {
		T result = 0;
		for (int c = 0; c < w; c++)
		{
		  for (int r = 0; r < h; r++)
		  {
			result += pow ((*this) (r, c), n);
		  }
		}
		return pow (result, 1.0 / n);
	  }
	}
  }

  template <class T>
  void
  MatrixAbstract<T>::normalize (const T scalar)
  {
	T length = norm (2);
	if (length != 0)
	{
	  (*this) /= length;
	  // It is less efficient to separate these operations, but more
	  // numerically stable.
	  if (scalar != 1.0)
	  {
		(*this) *= scalar;
	  }
	}
  }

  template <class T>
  T
  MatrixAbstract<T>::dot (const MatrixAbstract<T> & B) const
  {
	int h = rows ();
	int w = columns ();
	T result = 0;
	for (int c = 0; c < w; c++)
	{
	  for (int r = 0; r < h; r++)
	  {
		result += (*this) (r, c) * B (r, c);
	  }
	}
	return result;
  }

  template <class T>
  void
  MatrixAbstract<T>::identity (const T scalar)
  {
	clear ();
	int last = (rows () < columns ()) ? rows () : columns ();		//KenFix
	for (int i = 0; i < last; i++)
	{
	  (*this) (i, i) = scalar;
	}
  }

  template <class T>
  Matrix<T>
  MatrixAbstract<T>::operator * (const MatrixAbstract<T> & B) const
  {
	int w = columns ();
	int h = rows ();
	int bw = B.columns ();
	Matrix<T> result (h, bw);
	for (int c = 0; c < bw; c++)
	{
	  for (int r = 0; r < h; r++)
	  {
		register T element = 0;
		for (int i = 0; i < w; i++)
		{
		  element += (*this) (r, i) * B (i, c);
		}
		result (r, c) = element;
	  }
	}
	return result;
  }

  template <class T>
  Matrix<T>
  MatrixAbstract<T>::operator + (const MatrixAbstract<T> & B) const
  {
	int h = rows ();
	int w = columns ();
	Matrix<T> result (h, w);
	for (int c = 0; c < w; c++)
	{
	  for (int r = 0; r < h; r++)
	  {
		result (r, c) = (*this) (r, c) + B (r, c);
	  }
	}
	return result;
  }

  template <class T>
  Matrix<T>
  MatrixAbstract<T>::operator - (const MatrixAbstract<T> & B) const
  {
	int h = rows ();
	int w = columns ();
	Matrix<T> result (h, w);
	for (int c = 0; c < w; c++)
	{
	  for (int r = 0; r < h; r++)
	  {
		result (r, c) = (*this) (r, c) - B (r, c);
	  }
	}
	return result;
  }

  template <class T>
  MatrixAbstract<T> &
  MatrixAbstract<T>::operator *= (const T scalar)
  {
	int h = rows ();
	int w = columns ();
	for (int c = 0; c < w; c++)
	{
	  for (int r = 0; r < h; r++)
	  {
		(*this) (r, c) *= scalar;
	  }
	}
	return *this;
  }

  template <class T>
  MatrixAbstract<T> &
  MatrixAbstract<T>::operator /= (const T scalar)
  {
	int h = rows ();
	int w = columns ();
	for (int c = 0; c < w; c++)
	{
	  for (int r = 0; r < h; r++)
	  {
		(*this) (r, c) /= scalar;
	  }
	}
	return *this;
  }

  template <class T>
  MatrixAbstract<T> *
  MatrixAbstract<T>::factory (std::istream & stream)
  {
	char buff[255];		//KenFix
	std::string name;
	stream.getline (buff, 255);
	name = buff;

	if (name == typeid (Matrix<T>).name ())
	{
	  return new Matrix<T> (stream);
	}
	else if (name == typeid (Vector<T>).name ())
	{
	  return new Vector<T> (stream);
	}
	else if (name == typeid (MatrixPacked<T>).name ())
	{
	  return new MatrixPacked<T> (stream);
	}
	else
	{
	  std::cerr << "Unknown Matrix: " << name << endl;
	  throw "Unknown matrix";
	}
  }

  template <class T>
  void
  MatrixAbstract<T>::read (std::istream & stream)
  {
  }

  template <class T>
  void
  MatrixAbstract<T>::write (std::ostream & stream, bool withName) const
  {
	if (withName)
	{
	  stream << typeid (*this).name () << endl;
	}
  }


  // class Matrix<T> ----------------------------------------------------------

  template <class T>
  Matrix<T>::Matrix ()
  {
	rows_ = 0;
	columns_ = 0;
  };

  template <class T>
  Matrix<T>::Matrix (const int rows, const int columns)
  {
	resize (rows, columns);
  }

  template <class T>
  Matrix<T>::Matrix (const MatrixAbstract<T> & that)
  {
	if (typeid (that) == typeid (Matrix<T>))
	{
	  *this = (const Matrix<T> &) that;
	}
	else
	{
	  copyFrom (that);
	}
  }

  template <class T>
  Matrix<T>::Matrix (std::istream & stream)
  {
	read (stream);
  }

  template <class T>
  Matrix<T>::~Matrix ()
  {
	// data automatically destructs its memory.  Cool, eh?
  }

  template <class T>
  T &
  Matrix<T>::operator () (const int row, const int column) const
  {
	return ((T *) data.memory)[column * rows_ + row];
  }

  template <class T>
  T &
  Matrix<T>::operator [] (const int row) const
  {
	return ((T *) data.memory)[row];
  }

  template <class T>
  int
  Matrix<T>::rows () const
  {
	return rows_;
  }

  template <class T>
  int
  Matrix<T>::columns () const
  {
	return columns_;
  }

  template <class T>
  MatrixAbstract<T> *
  Matrix<T>::duplicate () const
  {
	return new Matrix<T> (*this);
  }

  template <class T>
  void
  Matrix<T>::clear ()
  {
	data.clear ();
  }

  template <class T>
  void
  Matrix<T>::resize (const int rows, const int columns)
  {
	data.grow (rows * columns * sizeof (T));
	rows_ = rows;
	columns_ = columns;
  }

  template <class T>
  void
  Matrix<T>::copyFrom (const MatrixAbstract<T> & that)
  {
	resize (that.rows (), that.columns ());
	T * i = (T *) data.memory;
	for (int c = 0; c < columns_; c++)
	{
	  for (int r = 0; r < rows_; r++)
	  {
		*i++ = that (r, c);
	  }
	}
  }

  template <class T>
  void
  Matrix<T>::copyFrom (const Matrix<T> & that)
  {
	resize (that.rows_, that.columns_);
	memcpy (data.memory, that.data.memory, rows_ * columns_ * sizeof (T));
  }

  template <class T>
  T
  Matrix<T>::norm (int n) const
  {
	// Some of this code may have to be modified for complex numbers.
	T * i = (T *) data.memory;
	T * end = i + rows_ * columns_;
	switch (n)
	{
	  case 0:  // Use zero as stand-in for infinity
	  {
		T result = *i++;  // result is undefined for empty Matrix
		while (i < end);
		{
		  T tmp = *i++;		//KenFix
		  result = (tmp > result) ? tmp : result;
		}
		return result;
	  }
	  case 1:
	  {
		T result = 0;
		while (i < end)
		{
		  result += *i++;
		}
		return result;
	  }
	  case 2:
	  {
		T result = 0;
		while (i < end)
		{
		  result += (*i) * (*i++);
		}
		return sqrt (result);
	  }
	  default:
	  {
		T result = 0;
		while (i < end)
		{
		  result += pow (*i++, n);
		}
		return pow (result, 1.0 / n);
	  }
	}
  }

  template <class T>
  T
  Matrix<T>::dot (const Matrix<T> & B)
  {
	T result = 0;
	T * i = (T *) data.memory;
	T * end = i + rows_ * columns_;
	T * j = (T *) B.data.memory;
	while (i < end)
	{
	  result += (*i++) * (*j++);
	}
	return result;
  }

  template <class T>
  MatrixTranspose<T>
  Matrix<T>::operator ~ () const
  {
	return MatrixTranspose<T> (*this);
  }

  template <class T>
  Matrix<T>
  Matrix<T>::operator * (const MatrixAbstract<T> & B) const
  {
	int w = B.columns ();
	Matrix<T> result (rows_, w);
	T * ri = (T *) result.data.memory;
	for (int c = 0; c < w; c++)
	{
	  for (int r = 0; r < rows_; r++)
	  {
		T * i = ((T *) data.memory) + r;
		register T element = 0;
		for (int j = 0; j < columns_; j++)
		{
		  element += (*i) * B (j, c);
		  i += rows_;
		}
		*ri++ = element;
	  }
	}
	return result;
  }

  template <class T>
  Matrix<T>
  Matrix<T>::operator * (const Matrix<T> & B) const
  {
	Matrix<T> result (rows_, B.columns_);
	for (int c = 0; c < B.columns_; c++)
	{
	  for (int r = 0; r < rows_; r++)
	  {
		T * i = ((T *) data.memory) + r;
		T * j = ((T *) B.data.memory) + c * B.rows_;
		T * end = j + B.rows_;
		register T element = 0;
		while (j < end)
		{
		  element += (*i) * (*j++);
		  i += rows_;
		}
		result (r, c) = element;
	  }
	}
	return result;
  }

  template <class T>
  Matrix<T>
  Matrix<T>::operator * (const T scalar) const
  {
	Matrix<T> result (rows_, columns_);
	T * i = (T *) result.data.memory;
	T * end = i + rows_ * columns_;
	T * j = (T *) data.memory;
	while (i < end)
	{
	  *i++ = *j++ * scalar;
	}
	return result;
  }

  template <class T>
  Matrix<T>
  Matrix<T>::operator / (const T scalar) const
  {
	Matrix<T> result (rows_, columns_);
	T * i = (T *) result.data.memory;
	T * end = i + rows_ * columns_;
	T * j = (T *) data.memory;
	while (i < end)
	{
	  *i++ = *j++ / scalar;
	}
	return result;
  }

  template <class T>
  Matrix<T>
  Matrix<T>::operator + (const Matrix<T> & B) const
  {
	Matrix<T> result (rows_, columns_);
	int i = rows_ * columns_;
	while (i--)
	{
	  ((T *) result.data.memory)[i] = ((T *) data.memory)[i] + ((T *) B.data.memory)[i];
	}
	return result;
  }

  template <class T>
  Matrix<T>
  Matrix<T>::operator - (const Matrix<T> & B) const
  {
	Matrix<T> result (rows_, columns_);
	int i = rows_ * columns_;
	while (i--)
	{
	  ((T *) result.data.memory)[i] = ((T *) data.memory)[i] - ((T *) B.data.memory)[i];
	}
	return result;
  }

  template <class T>
  Matrix<T> &
  Matrix<T>::operator *= (const Matrix<T> & B)
  {
	return *this = ((MatrixAbstract<T> &) *this) * B;
  }

  template <class T>
  MatrixAbstract<T> &
  Matrix<T>::operator *= (const T scalar)
  {
	T * i = (T *) data.memory;
	T * end = i + rows_ * columns_;
	while (i < end)
	{
	  *i++ *= scalar;
	}
	return *this;
  }

  template <class T>
  MatrixAbstract<T> &
  Matrix<T>::operator /= (const T scalar)
  {
	T * i = (T *) data.memory;
	T * end = i + rows_ * columns_;
	while (i < end)
	{
	  *i++ /= scalar;
	}
	return *this;
  }

  template <class T>
  void
  Matrix<T>::read (std::istream & stream)
  {
	stream.read ((char *) rows_, sizeof (rows_));
	stream.read ((char *) columns_, sizeof (columns_));
	int bytes = rows_ * columns_ * sizeof (T);
	data.grow (bytes);
	stream.read ((char *) data.memory, bytes);
  }

  template <class T>
  void
  Matrix<T>::write (std::ostream & stream, bool withName) const
  {
	if (withName)
	{
	  stream << typeid (*this).name () << endl;
	}
	stream.write ((char *) rows_, sizeof (rows_));
	stream.write ((char *) columns_, sizeof (columns_));
	stream.write ((char *) data.memory, rows_ * columns_ * sizeof (T));
  }


  // class Vector<T> ----------------------------------------------------------

  template <class T>
  Vector<T>::Vector ()
  {
	rows_ = 0;
	columns_ = 0;
  }

  template <class T>
  Vector<T>::Vector (const int rows)
  {
	resize (rows);
  }

  template <class T>
  Vector<T>::Vector (const MatrixAbstract<T> & that)
  {
	if (   typeid (that) == typeid (*this)
	    || typeid (that) == typeid (Matrix<T>))
	{
	  *this = (Matrix<T> &) that;
	}
	else
	{
	  copyFrom (that);
	}
	// Implicitly, a MatrixPacked will convert into a Vector with rows * rows
	// elements.  If that is the wrong behaviour, add another case here.
  }

  template <class T>
  Vector<T>::Vector (const Matrix<T> & that)
  {
	data = that.data;
	rows_ = that.rows_ * that.columns_;
	columns_ = 1;
  }

  template <class T>
  Vector<T>::Vector (std::istream & stream)
  {
	read (stream);
  }

  template <class T>
  MatrixAbstract<T> *
  Vector<T>::duplicate () const
  {
	return new Vector<T> (*this);
  }

  template <class T>
  void
  Vector<T>::resize (const int rows, const int columns)
  {
	Matrix<T>::resize (rows * columns, 1);
  }

  template <class T>
  Vector<T> &
  Vector<T>::operator = (const Matrix<T> & that)
  {
	data = that.data;
	rows_ = that.rows_ * that.columns_;
	columns_ = 1;
	return *this;
  }


  // class MatrixPacked<T> ----------------------------------------------------

  template <class T>
  MatrixPacked<T>::MatrixPacked ()
  {
	rows_ = 0;
  }

  template <class T>
  MatrixPacked<T>::MatrixPacked (const int rows)
  {
	resize (rows, rows);
  }

  template <class T>
  MatrixPacked<T>::MatrixPacked (const MatrixAbstract<T> & that)
  {
	if (typeid (that) == typeid (*this))
	{
	  *this = (MatrixPacked<T> &) (that);
	}
	else
	{
	  copyFrom (that);
	}
  }

  template <class T>
  MatrixPacked<T>::MatrixPacked (std::istream & stream)
  {
	read (stream);
  }

  template <class T>
  T &
  MatrixPacked<T>::operator () (const int row, const int column) const
  {
	if (row <= column)
	{
	  return ((T *) data.memory)[row + (column + 1) * (column) / 2];
	}
	else
	{
	  return ((T *) data.memory)[column + (row + 1) * (row) / 2];
	}
  }

  template <class T>
  T &
  MatrixPacked<T>::operator [] (const int row) const
  {
	return ((T *) data.memory)[row];
  }

  template <class T>
  int
  MatrixPacked<T>::rows () const
  {
	return rows_;
  }

  template <class T>
  int
  MatrixPacked<T>::columns () const
  {
	return rows_;
  }

  template <class T>
  MatrixAbstract<T> *
  MatrixPacked<T>::duplicate () const
  {
	return new MatrixPacked<T> (*this);
  }

  template <class T>
  void
  MatrixPacked<T>::clear ()
  {
	data.clear ();
  }

  template <class T>
  void
  MatrixPacked<T>::resize (const int rows, const int columns)
  {
	rows_ = columns > 0 ? ((rows < columns) ? rows : columns) : rows;	//KenFix
	data.grow (sizeof (T) * (rows_ + 1) * rows_ / 2);
  }

  template <class T>
  void
  MatrixPacked<T>::copyFrom (const MatrixAbstract<T> & that)
  {
	// We only copy the upper triangle
	resize (that.rows (), that.columns ());
	T * i = (T *) data.memory;
	for (int c = 0; c < rows_; c++)
	{
	  for (int r = 0; r <= c; r++)
	  {
		*i++ = that (r, c);
	  }
	}
  }

  template <class T>
  MatrixPacked<T>
  MatrixPacked<T>::operator ~ () const
  {
	return (MatrixPacked<T>) *this;
  }


  // class MatrixTranspose<T> -------------------------------------------------

  template <class T>
  MatrixTranspose<T>::MatrixTranspose (const MatrixAbstract<T> & that)
  {
	wrapped = that.duplicate ();
  }

  template <class T>
  MatrixTranspose<T>::~MatrixTranspose ()
  {
	delete wrapped;  // We can assume that wrapped != NULL.
  }

  template <class T>
  T &
  MatrixTranspose<T>::operator () (const int row, const int column) const
  {
	return (*wrapped) (column, row);
  }

  template <class T>
  T &
  MatrixTranspose<T>::operator [] (const int row) const
  {
	return (*wrapped)[row];
  }

  template <class T>
  int
  MatrixTranspose<T>::rows () const
  {
	return wrapped->columns ();
  }

  template <class T>
  int
  MatrixTranspose<T>::columns () const
  {
	return wrapped->rows ();
  }

  template <class T>
  MatrixAbstract<T> *
  MatrixTranspose<T>::duplicate () const
  {
    return new MatrixTranspose<T> (*wrapped);
  }

  template <class T>
  void
  MatrixTranspose<T>::clear ()
  {
	wrapped->clear ();
  }

  template<class T>
  void
  MatrixTranspose<T>::resize (const int rows, const int columns)
  {
	wrapped->resize (columns, rows);
  }


  // class MatrixRegion -------------------------------------------------------

  template <class T>
  MatrixRegion<T>::MatrixRegion (const MatrixAbstract<T> & that, const int firstRow, const int firstColumn, const int lastRow, const int lastColumn)
  {
	wrapped = that.duplicate ();
	this->firstRow = firstRow;
	this->firstColumn = firstColumn;
	rows_ = lastRow - firstRow + 1;
	columns_ = lastColumn - firstColumn + 1;
  }

  template <class T>
  MatrixRegion<T>::~MatrixRegion ()
  {
	delete wrapped;  // We can assume that wrapped != NULL.
  }

  template <class T>
  T &
  MatrixRegion<T>::operator () (const int row, const int column) const
  {
	return (*wrapped)(row + firstRow, column + firstColumn);
  }

  template <class T>
  T &
  MatrixRegion<T>::operator [] (const int row) const
  {
	int r = row % rows_;
	int c = row / rows_;
	return (*wrapped)(r, c);
  }

  template <class T>
  int
  MatrixRegion<T>::rows () const
  {
	return rows_;
  }

  template <class T>
  int
  MatrixRegion<T>::columns () const
  {
	return columns_;
  }

  template <class T>
  MatrixAbstract<T> *
  MatrixRegion<T>::duplicate () const
  {
    return new MatrixRegion<T> (*wrapped, firstRow, firstColumn, firstRow + rows_ - 1, firstColumn + columns_ - 1);
  }

  template <class T>
  void
  MatrixRegion<T>::clear ()
  {
	for (int r = firstRow + rows_ - 1; r >= firstRow; r--)
	{
	  for (int c = firstColumn + columns_ - 1; c >= firstColumn; c--)
	  {
		(*wrapped) (r, c) = 0;
	  }
	}
  }

  template<class T>
  void
  MatrixRegion<T>::resize (const int rows, const int columns)
  {
	// We can't resize a region of the wrapped object, but we can change
	// the number of rows or columns in the view.
	rows_ = rows;
	columns_ = columns;
  }


  // class Matrix2x2<T> -------------------------------------------------------

  template <class T>
  Matrix2x2<T>::Matrix2x2 ()
  {
  }

  template <class T>
  Matrix2x2<T>::Matrix2x2 (const MatrixAbstract<T> & that)
  {
	// We assume that we wouldn't assign to an explicit Matrix2x2 unless
	// we knew that the source is in fact at least 2 by 2.
	data[0][0] = that (0, 0);
	data[0][1] = that (1, 0);
	data[1][0] = that (0, 1);
	data[1][1] = that (1, 1);
  }

  template <class T>
  Matrix2x2<T>::Matrix2x2 (std::istream & stream)
  {
	read (stream);
  }

  template <class T>
  T &
  Matrix2x2<T>::operator () (const int row, const int column) const
  {
	return (T &) data[column][row];
  }

  template <class T>
  T &
  Matrix2x2<T>::operator [] (const int row) const
  {
	return ((T *) data)[row];
  }

  template <class T>
  int
  Matrix2x2<T>::rows () const
  {
	return 2;
  }

  template <class T>
  int
  Matrix2x2<T>::columns () const
  {
	return 2;
  }

  template <class T>
  MatrixAbstract<T> *
  Matrix2x2<T>::duplicate () const
  {
	return new Matrix2x2<T> (*this);
  }

  template<class T>
  void
  Matrix2x2<T>::resize (const int rows, const int columns)
  {
	if (rows != 2  ||  columns != 2)
	{
	  throw "Can't resize: matrix size is fixed at 2x2";
	}
  }

  template <class T>
  Matrix2x2<T>
  Matrix2x2<T>::operator ! () const
  {
	Matrix2x2<T> result;
	T q = data[0][0] * data[1][1] - data[0][1] * data[1][0];
	if (q == 0)
	{
	  throw "invert: Matrix is singular!";
	}
	result.data[0][0] = data[1][1] / q;
	result.data[0][1] = data[0][1] / -q;
	result.data[1][0] = data[1][0] / -q;
	result.data[1][1] = data[0][0] / q;
	return result;
  }

  template <class T>
  Matrix2x2<T>
  Matrix2x2<T>::operator ~ () const
  {
	Matrix2x2<T> result;
	result.data[0][0] = data[0][0];
	result.data[0][1] = data[1][0];
	result.data[1][0] = data[0][1];
	result.data[1][1] = data[1][1];
	return result;
  }

  template <class T>
  Matrix<T>
  Matrix2x2<T>::operator * (const MatrixAbstract<T> & B) const
  {
	int h = B.rows ();
	int w = B.columns ();
	Matrix<T> result (2, w);
	T * i = (T *) result.data.memory;
	for (int c = 0; c < w; c++)
	{
	  T & row0 = B (0, c);
	  T & row1 = B (1, c);
	  *i++ = data[0][0] * row0 + data[1][0] * row1;
	  *i++ = data[0][1] * row0 + data[1][1] * row1;
	}
	return result;
  }

  template <class T>
  Matrix2x2<T> &
  Matrix2x2<T>::operator *= (const Matrix2x2<T> & B)
  {
	T temp00   = data[0][0] * B.data[0][0] + data[1][0] * B.data[0][1];
	T temp01   = data[0][1] * B.data[0][0] + data[1][1] * B.data[0][1];
	data[1][0] = data[0][0] * B.data[1][0] + data[1][0] * B.data[1][1];
	data[1][1] = data[0][1] * B.data[1][0] + data[1][1] * B.data[1][1];
	data[0][0] = temp00;
	data[0][1] = temp01;
	return *this;
  }

  template <class T>
  MatrixAbstract<T> &
  Matrix2x2<T>::operator *= (const T scalar)
  {
	data[0][0] *= scalar;
	data[0][1] *= scalar;
	data[1][0] *= scalar;
	data[1][1] *= scalar;
	return *this;
  }

  template <class T>
  void
  Matrix2x2<T>::read (std::istream & stream)
  {
	stream.read ((char *) data, 4 * sizeof (T));
  }

  template <class T>
  void
  Matrix2x2<T>::write (std::ostream & stream, bool withName) const
  {
	if (withName)
	{
	  stream << typeid (*this).name () << endl;
	}
	stream.write ((char *) data, 4 * sizeof (T));
  }


  // class Matrix3x3<T> -------------------------------------------------------

  template <class T>
  Matrix3x3<T>::Matrix3x3 ()
  {
  }

  template <class T>
  Matrix3x3<T>::Matrix3x3 (const MatrixAbstract<T> & that)
  {
	// We assume that we wouldn't assign to an explicit Matrix3x3 unless
	// we knew that the source is in fact 3 by 3.
	data[0][0] = that (0, 0);
	data[0][1] = that (1, 0);
	data[0][2] = that (2, 0);
	data[1][0] = that (0, 1);
	data[1][1] = that (1, 1);
	data[1][2] = that (2, 1);
	data[2][0] = that (0, 2);
	data[2][1] = that (1, 2);
	data[2][2] = that (2, 2);
  }

  template <class T>
  Matrix3x3<T>::Matrix3x3 (std::istream & stream)
  {
	read (stream);
  }

  template <class T>
  T &
  Matrix3x3<T>::operator () (const int row, const int column) const
  {
	return (T &) data[column][row];
  }

  template <class T>
  T &
  Matrix3x3<T>::operator [] (const int row) const
  {
	return ((T *) data)[row];
  }

  template <class T>
  int
  Matrix3x3<T>::rows () const
  {
	return 3;
  }

  template <class T>
  int
  Matrix3x3<T>::columns () const
  {
	return 3;
  }

  template <class T>
  MatrixAbstract<T> *
  Matrix3x3<T>::duplicate () const
  {
	return new Matrix3x3<T> (*this);
  }

  template<class T>
  void
  Matrix3x3<T>::resize (const int rows, const int columns)
  {
	if (rows != 3  ||  columns != 3)
	{
	  throw "Can't resize: matrix size is fixed at 3x3";
	}
  }

  template <class T>
  Matrix<T>
  Matrix3x3<T>::operator * (const MatrixAbstract<T> & B) const
  {
	int h = B.rows ();
	int w = B.columns ();
	Matrix<T> result (3, w);
	T * i = (T *) result.data.memory;
	for (int c = 0; c < w; c++)
	{
	  T & row0 = B (0, c);
	  T & row1 = B (1, c);
	  T & row2 = B (2, c);
	  *i++ = data[0][0] * row0 + data[1][0] * row1 + data[2][0] * row2;
	  *i++ = data[0][1] * row0 + data[1][1] * row1 + data[2][1] * row2;
	  *i++ = data[0][2] * row0 + data[1][2] * row1 + data[2][2] * row2;
	}
	return result;
  }

  template <class T>
  void
  Matrix3x3<T>::read (std::istream & stream)
  {
	stream.read ((char *) data, 9 * sizeof (T));
  }

  template <class T>
  void
  Matrix3x3<T>::write (std::ostream & stream, bool withName) const
  {
	if (withName)
	{
	  stream << typeid (*this).name () << endl;
	}
	stream.write ((char *) data, 9 * sizeof (T));
  }


  // Matrix operations --------------------------------------------------------

}


#endif
