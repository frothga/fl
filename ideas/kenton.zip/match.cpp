#include "../prompt.h"
#include "interest.h"
#include "descriptor.h"
#include "random.h"
#include "string.h"
#include "lapack.h"
#include "canvas.h"
#include "pi.h"

#include <fstream>

using namespace std;
using namespace my;

int patchSize = 50;
int binsPatch = 10;
float supportRadial = 3;
int binsRadial = 6;
int binsIntensity = 6;
float scaleFactor = 480;  // Reduce pixel coordintes to be near the range 0..1

//KenFix
#define cerr outw
#define endl endw


struct PictureM{
  string fileName;
  vector<PointInterestAffine> points;
  vector< Vector<float> > spins;
};


struct Match{
  PointInterestAffine * p0;
  PointInterestAffine * p1;
  int k0;  // Index of interest point in picture 0
  int k1;  // ditto for 1
  Matrix<float> A;  // Affine transformation between two planes associated with interes points
  float weight;

  bool operator < (const Match & that) const
  {
	return weight < that.weight;
  }
};


PictureM & findPicture(vector<PictureM> & pictures, const string & fileName)
{
  vector<PictureM>::iterator i;
  for (i = pictures.begin (); i < pictures.end (); i++)
  {
	if (i->fileName == fileName)
	{
	  break;
	}
  }
  return *i;
}


inline float
similarityNormalizedCorrelation(const Vector<float> & value1, const Vector<float> & value2)
{
  int r;
  Vector<float> vi;
  Vector<float> vj;
  vi.copyFrom (value1);
  vj.copyFrom (value2);

  float mi = 0;
  float mj = 0;
  int N = 0;
  for (r = 0; r < vi.rows (); r++)
  {
	N++;
	mi += vi[r];
	mj += vj[r];
  }
  mi /= N;
  mj /= N;

  float ni = 0;
  float nj = 0;
  for (r = 0; r < vi.rows (); r++)
  {
	vi[r] -= mi;
	vj[r] -= mj;
	ni += pow (vi[r], 2);
	nj += pow (vj[r], 2);
  }
  ni = sqrt (ni);
  nj = sqrt (nj);

  return vi.dot (vj) / (ni * nj);
}


inline Matrix<float>
compositeTransform(const Image & image0, const Image & image1, PointInterestAffine & p0, PointInterestAffine & p1)
{
  float angle = p0.angle - p1.angle;  // The sign of the angle and the order of the matrix multiplication are closely related.
  Matrix<float> R (3, 3);
  R.clear ();
  R (0, 0) = cos (angle);
  R (1, 0) = sin (angle);
  R (0, 1) = - R (1, 0);
  R (1, 1) = R (0, 0);
  R (2, 2) = 1;

  Matrix<float> A0 (3, 3);
  A0.clear ();
  A0 (0, 0) = p0.A (0, 0) / p0.scale;
  A0 (0, 1) = p0.A (0, 1) / p0.scale;
  A0 (1, 0) = p0.A (1, 0) / p0.scale;
  A0 (1, 1) = p0.A (1, 1) / p0.scale;
  A0 (0, 2) = - (A0 (0, 0) * p0.x + A0 (0, 1) * p0.y) / scaleFactor;
  A0 (1, 2) = - (A0 (1, 0) * p0.x + A0 (1, 1) * p0.y) / scaleFactor;
  A0 (2, 2) = 1;

  Matrix<float> A1 (3, 3);
  A1.clear ();
  A1 (0, 0) = p1.A (0, 0) / p1.scale;
  A1 (0, 1) = p1.A (0, 1) / p1.scale;
  A1 (1, 0) = p1.A (1, 0) / p1.scale;
  A1 (1, 1) = p1.A (1, 1) / p1.scale;
  A1 (0, 2) = - (A1 (0, 0) * p1.x + A1 (0, 1) * p1.y) / scaleFactor;
  A1 (1, 2) = - (A1 (1, 0) * p1.x + A1 (1, 1) * p1.y) / scaleFactor;
  A1 (2, 2) = 1;

  return (! A0) * R * A1;
}


// Eliminate bad matches using affine constraint
void constraintRank(Image & image0, Image & image1, vector<Match> & matches)
{
  int i;

  for (i = 0; i < matches.size (); i++)
  {
	PointInterestAffine & p0 = *(matches[i].p0);
	PointInterestAffine & p1 = *(matches[i].p1);
	matches[i].A = compositeTransform (image0, image1, p0, p1);
  }
  float largestWeight = 0;
  for (i = 0; i < matches.size (); i++)
  {
	matches[i].weight = 0;
	for (int j = 0; j < matches.size (); j++)
	{
	  if (i != j)
	  {
		float dx = matches[i].p0->x - matches[j].p0->x;
		float dy = matches[i].p0->y - matches[j].p0->y;
		float d = sqrt (dx * dx + dy * dy);
		if (d < 100)
		{
		  dx = matches[i].p1->x - matches[j].p1->x;
		  dy = matches[i].p1->y - matches[j].p1->y;
		  d = sqrt (dx * dx + dy * dy);
		  if (d < 100)
		  {
			Matrix<float> A = matches[i].A - matches[j].A;
			MatrixRegion<float> row0 (A, 0, 0, 0, 2);
			MatrixRegion<float> row1 (A, 1, 0, 1, 2);
			row0.normalize ();
			row1.normalize ();
			float cosine = row0.dot (row1);
			float angle = acos (fabs (cosine));
			if (angle < 0.1)  // Tuneable parameter
			{
			  matches[i].weight++;
			}
		  }
		}
	  }
	}
	largestWeight = (largestWeight > matches[i].weight) ? largestWeight : matches[i].weight;	//KenFix
  }
  for (i = matches.size () - 1; i >= 0; i--)
  {
	cerr << matches[i].weight << endl;
	if (matches[i].weight / largestWeight < 0.5)
	//if (matches[i].weight < 1)
	{
	  matches.erase (matches.begin () + i);
	}
  }
}


// Read an automatically generated points file
void readInterest(const string & pointFileName, vector<PictureM> & pictures)
{
  std::ifstream pointStream(pointFileName.c_str (), ios::binary);
  int fileCount = 0;
  pointStream.read ((char *) &fileCount, sizeof (fileCount));
  pictures.resize (fileCount);
  for (int i = 0; i < fileCount; i++)
  {
	getline (pointStream, pictures[i].fileName);

	int pointCount = 0;
	pointStream.read ((char *) &pointCount, sizeof (pointCount));

	for (int j = 0; j < pointCount; j++)
	{
	  PointInterestAffine p (pointStream);
	  pictures[i].points.push_back (p);
	}
  }

  pointStream.close();
}


void describeSpin(Image & image, PictureM & picture)
{
  static float half = patchSize / 2.0;

  static DescriptorSpin descriptor (binsRadial, binsIntensity, supportRadial);
  static PointInterestAffine center;
  center.x = (patchSize - 1) / 2.0;
  center.y = (patchSize - 1) / 2.0;
  center.scale = half / descriptor.supportRadial;

  for (int i = 0; i < picture.points.size (); i++)
  {
	PointInterestAffine & p = picture.points[i];
	TransformGauss rectify (p.A * (half / (supportRadial * p.scale)));
	rectify.setPeg (p.x, p.y, patchSize, patchSize);
	Image patch = image * rectify;
	picture.spins.push_back (descriptor.value (patch, center));
  }
}


void describePatch(Image & image, PictureM & picture)
{
  float half = binsPatch / 2.0;

  for (int i = 0; i < picture.points.size (); i++)
  {
	cerr << picture.fileName << " " << i << endl;
	PointInterestAffine & p = picture.points[i];

	Matrix<float> R (2, 2);
	R.clear ();
	R (0, 0) = cos (- p.angle);
	R (1, 0) = sin (- p.angle);
	R (0, 1) = - R (1, 0);
	R (1, 1) = R (0, 0);

	TransformGauss reduce (R * p.A * (half / (supportRadial * p.scale)));
	reduce.setPeg (p.x, p.y, binsPatch, binsPatch);
	ImageOf<float> patch = image * reduce;

	Vector<float> value (binsPatch * binsPatch);
	for (int x = 0; x < binsPatch; x++)
	{
	  for (int y = 0; y < binsPatch; y++)
	  {
		value[x * binsPatch + y] = patch (x, y);
	  }
	}

	picture.spins.push_back (value);
  }
}


void match(PictureM & picture0, PictureM & picture1, Image & image0, Image & image1, vector<Match> & matches)
{
  int i, j;

  // For gathering statistics about matching
  ImageOf<float> matchTable (picture0.points.size (), picture1.points.size (), GrayFloat);
  int rankCount = (picture0.points.size() > picture1.points.size()) ? picture0.points.size() : picture1.points.size();	//KenFix
  vector<float> ranks (rankCount);
  for (i = 0; i < rankCount; i++)
  {
	ranks[i] = 0;
  }
  float rankSum = 0;

  // Do the actual matching
  for (i = 0; i < picture0.points.size (); i++)
  {
	Vector<float> value0 = picture0.spins[i];

	multiset<Match> candidates;
	for (j = 0; j < picture1.points.size (); j++)
	{
	  Vector<float> value1 = picture1.spins[j];
	  Match m;
	  m.k0 = i;
	  m.k1 = j;
	  m.p0 = & picture0.points[i];
	  m.p1 = & picture1.points[j];
	  m.weight = similarityNormalizedCorrelation (value0, value1);
	  candidates.insert (m);
	  matchTable (i, j) = m.weight;


	  cerr << i << " " << j << " " << m.weight << endl;
	}

	multiset<Match>::reverse_iterator ri = candidates.rbegin ();
	for (j = 0; j < 1; j++)
	{
	  matches.push_back (*ri++);
	}

	ri = candidates.rbegin ();
	for (j = 0; j < candidates.size (); j++)
	{
	  if (ri->k0 == ri->k1)  // Correct match for Krystian data
	  {
		ranks[j]++;
		rankSum++;
		break;
	  }
	  ri++;
	}
  }
}


int matchmain(int argc, char * argv[])
{
  // Parse command line
  string pointFileName = "";
  vector<string> fileNames;

  for (int i = 1; i < argc; i++){
	string arg = argv[i];
	string name;
	string value;
	split(arg, "=", name, value);

	if (name.size () == arg.size ()){
	  fileNames.push_back (name);
	}else if (name.substr (0, 1) == "i"){
	  pointFileName = value;
	}else if (name.substr (0, 5) == "binsi"){
	  binsIntensity = atoi (value.c_str ());
	}else if (name.substr (0, 5) == "binsp"){
	  binsPatch = atoi (value.c_str ());
	}else if (name.substr (0, 5) == "binsr"){
	  binsRadial = atoi (value.c_str ());
	}else if (name.substr (0, 1) == "p"){
	  patchSize = atoi (value.c_str ());
	}else if (name.substr (0, 1) == "s"){
	  supportRadial = atof (value.c_str ());
	}else{
	  cerr << "Unrecognized parameter: " << name << endl;
	}
  }

  if(pointFileName.size() == 0 || fileNames.size() < 1){
	cerr << "Usage: " << argv[0] << " [parameters] {first image file} {other image files}" << endl;
	cerr << "  input={point file name} (required)" << endl;
	cerr << "  patchsize={number of pixels in displayed patch} (default = 50)" << endl;
	cerr << "  binspatch={number of pixels in patch feature vector} (default = 10)" << endl;
	cerr << "  binsintensity={number of intensity levels in spin-image} (default = 6)" << endl;
	cerr << "  binsradial={number of radial levels in spin-image} (default = 6)" << endl;
	cerr << "  supportradial={number of deviations away from center} (default = 3)" << endl;
	cerr << "The first image file will be compared against all the other image files." << endl;
	return 1;
  }

  try{
	vector<PictureM> pictures;
	readInterest(pointFileName, pictures);

	PictureM & picture0 = findPicture(pictures, fileNames[0]);
	Image image0;
	image0.read(picture0.fileName);
	image0 *= GrayFloat;

	//describeSpin(image0, picture0);
	describePatch(image0, picture0);

	for(int h = 1; h < fileNames.size(); h++){
	  PictureM & picture1 = findPicture(pictures, fileNames[h]);
	  Image image1;
	  image1.read(picture1.fileName);
	  image1 *= GrayFloat;

	  //describeSpin(image1, picture1);
	  describePatch(image1, picture1);

	  vector<Match> matches;
	  match(picture0, picture1, image0, image1, matches);
	  //constraintRank(image0, image1, matches);
	}
  }catch(char * error){
	cerr << "Exception: " << error << endl;
	return 1;
  }

  return 0;
}
