#include "../prompt.h"
#include "interest.h"
#include "string.h"
#include "lapacks.h"
#include "Vlib.h"
#include <fstream>

using namespace std;
using namespace my;


void putElipse(unsigned char * image, int w, int h, PointInterestAffine &p, 
			   int red, int green, int blue)
{
  Matrix<float> A;
  Matrix<float> U;
  Matrix<float> D;
  Matrix<float> rot;

  //KenFix
  A.resize(p.A.columns(), p.A.rows());	
  A.data = p.A.data;

  gesvd(A, U, D, rot);

  float a = 3.0 * p.scale * D[0];
  float b = 3.0 * p.scale * D[1];

  float a2    = a * a;
  float b2    = b * b;
  float a2_b2 = a2 / b2;
  float b2_a2 = b2 / a2;

  float px, py;

  for(float i = 0; i < a; i++){
    float yt = sqrt (b2 - b2_a2 * i * i);

    px = p.x + rot (0, 0) * i + rot (0, 1) * yt;
    py = p.y + rot (1, 0) * i + rot (1, 1) * yt;
	if((px >= 0) && (px < w) && (py >= 0) && (py < h)){
		image[pat(w, px, py, RED)]   = red;
		image[pat(w, px, py, GREEN)] = green;
		image[pat(w, px, py, BLUE)]  = blue;
	}

    px = p.x + rot (0, 0) * i - rot (0, 1) * yt;
    py = p.y + rot (1, 0) * i - rot (1, 1) * yt;
	if((px >= 0) && (px < w) && (py >= 0) && (py < h)){
		image[pat(w, px, py, RED)]   = red;
		image[pat(w, px, py, GREEN)] = green;
		image[pat(w, px, py, BLUE)]  = blue;
	}

    px = p.x - rot (0, 0) * i + rot (0, 1) * yt;
    py = p.y - rot (1, 0) * i + rot (1, 1) * yt;
	if((px >= 0) && (px < w) && (py >= 0) && (py < h)){
		image[pat(w, px, py, RED)]   = red;
		image[pat(w, px, py, GREEN)] = green;
		image[pat(w, px, py, BLUE)]  = blue;
	}

    px = p.x - rot (0, 0) * i - rot (0, 1) * yt;
    py = p.y - rot (1, 0) * i - rot (1, 1) * yt;
	if((px >= 0) && (px < w) && (py >= 0) && (py < h)){
		image[pat(w, px, py, RED)]   = red;
		image[pat(w, px, py, GREEN)] = green;
		image[pat(w, px, py, BLUE)]  = blue;
	}
  }

  for (float j = 1; j < b; j++){
    float xt = sqrt (a2 - a2_b2 * j * j);

    px = p.x + rot (0, 0) * xt + rot (0, 1) * j;
    py = p.y + rot (1, 0) * xt + rot (1, 1) * j;
	if((px >= 0) && (px < w) && (py >= 0) && (py < h)){
		image[pat(w, px, py, RED)]   = red;
		image[pat(w, px, py, GREEN)] = green;
		image[pat(w, px, py, BLUE)]  = blue;
	}

    px = p.x + rot (0, 0) * xt - rot (0, 1) * j;
    py = p.y + rot (1, 0) * xt - rot (1, 1) * j;
	if((px >= 0) && (px < w) && (py >= 0) && (py < h)){
		image[pat(w, px, py, RED)]   = red;
		image[pat(w, px, py, GREEN)] = green;
		image[pat(w, px, py, BLUE)]  = blue;
	}

    px = p.x - rot (0, 0) * xt + rot (0, 1) * j;
    py = p.y - rot (1, 0) * xt + rot (1, 1) * j;
	if((px >= 0) && (px < w) && (py >= 0) && (py < h)){
		image[pat(w, px, py, RED)]   = red;
		image[pat(w, px, py, GREEN)] = green;
		image[pat(w, px, py, BLUE)]  = blue;
	}

    px = p.x - rot (0, 0) * xt - rot (0, 1) * j;
    py = p.y - rot (1, 0) * xt - rot (1, 1) * j;
	if((px >= 0) && (px < w) && (py >= 0) && (py < h)){
		image[pat(w, px, py, RED)]   = red;
		image[pat(w, px, py, GREEN)] = green;
		image[pat(w, px, py, BLUE)]  = blue;
	}
  }
}


struct PictureDisp
{
  string fileName;
  vector<PointInterestAffine> points;
  vector< Vector<float> > spins;
};


void readInterest(string pointFileName, vector<PointInterest> &points)
{
  vector<PictureDisp> pictures;
  std::ifstream pointStream(pointFileName.c_str(), ios::binary);
  int fileCount = 0;
  
  pointStream.read((char *) &fileCount, sizeof(fileCount));
  pictures.resize(fileCount);

  for(int i = 0; i < fileCount; i++){
	getline(pointStream, pictures[i].fileName);

	int pointCount = 0;
	pointStream.read((char *) &pointCount, sizeof(pointCount));

	for(int j = 0; j < pointCount; j++){
	  PointInterest p(pointStream);
	  pictures[i].points.push_back(p);

	  if(i==0){		//View first images points only
		  points.push_back(p);
	  }
	}
  }
}


void readInterestAff(string pointFileName, vector<PointInterestAffine> &points)
{
  vector<PictureDisp> pictures;
  std::ifstream pointStream(pointFileName.c_str(), ios::binary);
  int fileCount = 0;
  
  pointStream.read((char *) &fileCount, sizeof(fileCount));
  pictures.resize(fileCount);

  for(int i = 0; i < fileCount; i++){
	getline(pointStream, pictures[i].fileName);

	int pointCount = 0;
	pointStream.read((char *) &pointCount, sizeof(pointCount));

	for(int j = 0; j < pointCount; j++){
	  PointInterestAffine p(pointStream);
	  pictures[i].points.push_back(p);

	  if(i==0){		//View first images points only
		  points.push_back(p);
	  }
	}
  }
}