#ifndef string_h
#define string_h


#include <string>


namespace my
{
  inline void
  split (std::string & source, char * delimiter, std::string & first, std::string & second)
  {
	int index = source.find (delimiter);
	if (index == std::string::npos)
	{
	  first = source;
	  second.erase ();
	}
	else
	{
	  std::string temp = source;
	  first = temp.substr (0, index);
	  second = temp.substr (index + strlen (delimiter));
	}
  }

  inline void
  trim (std::string & target)
  {
	int begin = target.find_first_not_of (' ');
	int end = target.find_last_not_of (' ');
	if (begin == std::string::npos)
	{
	  // all spaces
	  target.erase ();
	  return;
	}
	target = target.substr (begin, end - begin + 1);
  }
}


#endif
