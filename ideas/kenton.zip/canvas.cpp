#include "VCFix.h"
#include "canvas.h"
#include "lapack.h"

#include <algorithm>


using namespace my;
using namespace std;


// Utiltiy functions ----------------------------------------------------------

static inline void
flipX (float & angle)
{
  // Act as if circle has been flipped along vertical axis
  if (angle < PI)
  {
	angle = PI - angle;
  }
  else
  {
	angle = 3 * PI - angle;
  }
}

static inline void
flipY (float & angle)
{
  // Act as if circle has been flipped along horizontal axis
  angle = 2 * PI - angle;
}

static inline bool
inRange (float angle, const float & startAngle, const float & endAngle)
{
  while (angle < startAngle)
  {
	angle += 2 * PI;
  }
  return angle <= endAngle;
}


// class Canvas ---------------------------------------------------------------

Canvas::~Canvas ()
{
}

void
Canvas::drawDone ()
{
  // Do nothing
}

void
Canvas::drawPoint (const Point & p, unsigned int color)
{
  throw "drawPoint not implemented for this type of Canvas";
}

void
Canvas::drawSegment (const Point & a, const Point & b, unsigned int color)
{
  throw "drawSegment not implemented for this type of Canvas";
}

void
Canvas::drawLine (float a, float b, float c, unsigned int color)
{
  throw "drawLine not implemented for this type of Canvas";
}

void
Canvas::drawRay (const Point & p, float angle, unsigned int color)
{
  throw "drawRay not implemented for this type of Canvas";
}

void
Canvas::drawPolygon (const std::vector<Point> & points, unsigned int color)
{
  throw "drawPolygon not implemented for this type of Canvas";
}

void
Canvas::drawCircle (const Point & center, float radius, unsigned int color, float startAngle, float endAngle)
{
  throw "drawCircle not implemented for this type of Canvas";
}

void
Canvas::drawEllipse (const Point & center, const Matrix2x2<float> & shape, unsigned int color, float startAngle, float endAngle)
{
  throw "drawEllipse not implemented for this type of Canvas";
}

//KenFix
void
Canvas::drawText (const std::string & text, const Point & point, float size, float angle, unsigned int color)
{
  throw "drawText not implemented for this type of Canvas";
}

void
Canvas::setTranslation (float x, float y)
{
  // Do nothing
}

void
Canvas::setScale (float x, float y)
{
  // Do nothing
}

void
Canvas::setLineWidth (float width)
{
  // Do nothing
}


// class CanvasImage ----------------------------------------------------------

// Most of the implementations here are hacks based on float.  They could be
// made more efficient for changing to Bresenhem-like approaches.

CanvasImage::CanvasImage (const PixelFormat & format)
: Image (format)
{
  initialize ();
}

//KenFix
CanvasImage::CanvasImage (int width, int height, const PixelFormat & format)
: Image (width, height, format)
{
  initialize ();
}

CanvasImage::CanvasImage (const Image & that)
: Image (that)
{
  initialize ();
}

void
CanvasImage::initialize ()
{
  transX = 0;
  transY = 0;
  scaleX = 1;
  scaleY = 1;

  setLineWidth (1);
}

CanvasImage::~CanvasImage ()
{
}

inline Point
CanvasImage::trans (const Point & p)
{
  Point result;
  result.x = p.x * scaleX + transX;
  result.y = p.y * scaleY + transY;
  return result;
}

inline void
CanvasImage::pen (const Point & p, unsigned int color)
{
  int h = penTip.width / 2;
  int px = (int) rint (p.x) - h;
  int py = (int) rint (p.y) - h;
  for (int x = 0; x < penTip.width; x++)
  {
	for (int y = 0; y < penTip.height; y++)
	{
	  if (penTip (x, y))
	  {
		setRGB (px + x, py + y, color);
	  }
	}
  }
}

void
CanvasImage::drawPoint (const Point & p, unsigned int color)
{
  Point step (2 / scaleX, 2 / scaleY);
  Point p1 (p.x - step.x, p.y - step.y);
  Point p2 (p.x - step.x, p.y + step.y);
  Point p3 (p.x + step.x, p.y - step.y);
  Point p4 (p.x + step.x, p.y + step.y);
  drawSegment (p1, p4, color);
  drawSegment (p2, p3, color);
}

void
CanvasImage::drawSegment (const Point & a, const Point & b, unsigned int color)
{
  Point ta = trans (a);
  Point tb = trans (b);

  float dx = tb.x - ta.x;
  float dy = tb.y - ta.y;

  if (dx == 0  &&  dy == 0)
  {
	pen (ta, color);
	return;
  }

  Point p;
  if (fabs (dx) > fabs (dy))
  {
	if (dx < 0)
	{
	  for (p.x = tb.x; p.x <= ta.x; p.x++)
	  {
		p.y = (p.x - tb.x) * dy / dx + tb.y;
		pen (p, color);
	  }
	}
	else
	{
	  for (p.x = ta.x; p.x <= tb.x; p.x++)
	  {
		p.y = (p.x - ta.x) * dy / dx + ta.y;
		pen (p, color);
	  }
	}
  }
  else
  {
	if (dy < 0)
	{
	  for (p.y = tb.y; p.y <= ta.y; p.y++)
	  {
		p.x = (p.y - tb.y) * dx / dy + tb.x;
		pen (p, color);
	  }
	}
	else
	{
	  for (p.y = ta.y; p.y <= tb.y; p.y++)
	  {
		p.x = (p.y - ta.y) * dx / dy + ta.x;
		pen (p, color);
	  }
	}
  }
}

void
CanvasImage::drawLine (float a, float b, float c, unsigned int color)
{
  a /= scaleX;
  b /= scaleY;
  c -= a * transX + b * transY;

  Point p;
  if (fabs (a) < fabs (b))
  {
	a /= -b;
	c /= -b;
	for (p.x = 0; p.x < width; p.x++)
	{
	  p.y = a * p.x + c;
	  pen (p, color);
	}
  }
  else
  {
	b /= -a;
	c /= -a;
	for (p.y = 0; p.y < height; p.y++)
	{
	  p.x = b * p.y + c;
	  pen (p, color);
	}
  }
}

void
CanvasImage::drawRay (const Point & p, float angle, unsigned int color)
{
  Point center = trans (p);

  angle = mod2pi (angle);
  float c = cosf (angle) * scaleX;
  float s = sinf (angle) * scaleY;

  if (fabsf (c) > fabsf (s))
  {
	float step = s / c;
	if (c < 0)
	{
	  do
	  {
		pen (center, color);
		center.x--;
		center.y -= step;
	  }
	  while (center.x >= 0);
	}
	else
	{
	  do
	  {
		pen (center, color);
		center.x++;
		center.y += step;
	  }
	  while (center.x < width);
	}
  }
  else
  {
	float step = c / s;
	if (s < 0)
	{
	  do
	  {
		pen (center, color);
		center.x -= step;
		center.y--;
	  }
	  while (center.y >= 0);
	}
	else
	{
	  do
	  {
		pen (center, color);
		center.x += step;
		center.y++;
	  }
	  while (center.y < height);
	}
  }
}

void
CanvasImage::drawPolygon (const std::vector<Point> & points, unsigned int color)
{
  for (int i = 0; i < points.size () - 1; i++)
  {
	drawSegment (points[i], points[i + 1], color);
  }
  if (points.size () >= 3)
  {
	drawSegment (points.front (), points.back (), color);
  }
}

void
CanvasImage::drawCircle (const Point & center, float radius, unsigned int color, float startAngle, float endAngle)
{
  Matrix2x2<float> A;
  A.identity (1.0 / (radius * radius));
  drawEllipse (center, A, color, startAngle, endAngle);
}

void
CanvasImage::drawEllipse (const Point & center, const Matrix2x2<float> & shape, unsigned int color, float startAngle, float endAngle)
{
  // Adjust for scaling and translation
  Point tcenter = trans (center);
  Matrix2x2<float> tshape;
  tshape(0,0) = shape(0,0) / (scaleX * scaleX);
  tshape(0,1) = shape(0,1) / (scaleX * scaleY);
  tshape(1,0) = shape(1,0) / (scaleY * scaleX);
  tshape(1,1) = shape(1,1) / (scaleY * scaleY);

  // Prepare ellipse parameters

  /*
  Matrix<float> U;
  Matrix<float> D;
  Matrix<float> rot;
  gesvd (tshape, U, D, rot);

  float a = 1.0 / sqrt (D[0]);
  float b = 1.0 / sqrt (D[1]);
  float a2    = a * a;
  float b2    = b * b;
  */

  Matrix<float> D;
  Matrix<float> rot;
  geev (tshape, D, rot);

  float a2 = 1.0 / D[0];
  float b2 = 1.0 / D[1];
  float a  = sqrt (a2);
  float b  = sqrt (b2);
  float a2_b2 = a2 / b2;
  float b2_a2 = b2 / a2;
  float ratio = a / b;

  // Prepare angle ranges
  startAngle = mod2pi (startAngle);
  endAngle   = mod2pi (endAngle);
  if (scaleX < 0)
  {
	flipX (startAngle);
	flipX (endAngle);
	swap (startAngle, endAngle);
  }
  if (scaleY < 0)
  {
	flipY (startAngle);
	flipY (endAngle);
	swap (startAngle, endAngle);
  }
  startAngle = mod2pi (startAngle);
  endAngle   = mod2pi (endAngle);
  if (endAngle <= startAngle)
  {
	endAngle += 2 * PI;
  }

  // Determine where to switch from tracking x-axis to tracking y-axis
  float maxA = a / sqrt (b2_a2 + 1);
  float maxB = b / sqrt (a2_b2 + 1);

  // Do the actual drawing
  Point p;
  for (float i = 0; i <= maxA; i++)  // i < a
  {
    float yt = sqrt (b2 - b2_a2 * i * i);
	float angle = atan ((yt / i) * ratio);

	if (inRange (angle, startAngle, endAngle))
	{
	  p.x = tcenter.x + rot(0,0) * i + rot(0,1) * yt;
	  p.y = tcenter.y + rot(1,0) * i + rot(1,1) * yt;
	  pen (p, color);
	}
	if (inRange (PI - angle, startAngle, endAngle))
	{
	  p.x = tcenter.x - rot(0,0) * i + rot(0,1) * yt;
	  p.y = tcenter.y - rot(1,0) * i + rot(1,1) * yt;
	  pen (p, color);
	}
	if (inRange (PI + angle, startAngle, endAngle))
	{
	  p.x = tcenter.x - rot(0,0) * i - rot(0,1) * yt;
	  p.y = tcenter.y - rot(1,0) * i - rot(1,1) * yt;
	  pen (p, color);
	}
	if (inRange (2 * PI - angle, startAngle, endAngle))
	{
	  p.x = tcenter.x + rot(0,0) * i - rot(0,1) * yt;
	  p.y = tcenter.y + rot(1,0) * i - rot(1,1) * yt;
	  pen (p, color);
	}
  }
  for (float j = 0; j <= maxB; j++)  // j < b
  {
    float xt = sqrt (a2 - a2_b2 * j * j);
	float angle = atan ((j / xt) * ratio);

	if (inRange (angle, startAngle, endAngle))
	{
	  p.x = tcenter.x + rot(0,0) * xt + rot(0,1) * j;
	  p.y = tcenter.y + rot(1,0) * xt + rot(1,1) * j;
	  pen (p, color);
	}
	if (inRange (PI - angle, startAngle, endAngle))
	{
	  p.x = tcenter.x - rot(0,0) * xt + rot(0,1) * j;
	  p.y = tcenter.y - rot(1,0) * xt + rot(1,1) * j;
	  pen (p, color);
	}
	if (inRange (PI + angle, startAngle, endAngle))
	{
	  p.x = tcenter.x - rot(0,0) * xt - rot(0,1) * j;
	  p.y = tcenter.y - rot(1,0) * xt - rot(1,1) * j;
	  pen (p, color);
	}
	if (inRange (2 * PI - angle, startAngle, endAngle))
	{
	  p.x = tcenter.x + rot(0,0) * xt - rot(0,1) * j;
	  p.y = tcenter.y + rot(1,0) * xt - rot(1,1) * j;
	  pen (p, color);
	}
  }
}

void
CanvasImage::setTranslation (float x, float y)
{
  transX = x;
  transY = y;
}

void
CanvasImage::setScale (float x, float y)
{
  scaleX = x;
  scaleY = y;
}

void
CanvasImage::setLineWidth (float width)
{
  // Consider adding anti-aliasing

  float l = pow (width / 2.0, 2.0);
  int half = (int) rint (width / 2);
  int w = 2 * half + 1;
  penTip.resize (w, w);

  for (int x = 0; x < w; x++)
  {
	for (int y = 0; y < w; y++)
	{
	  float dx = x - half;
	  float dy = y - half;
	  penTip (x, y) = dx * dx + dy * dy <= l;
	}
  }
}


// class CanvasPS -------------------------------------------------------------

CanvasPS::CanvasPS (const std::string & fileName, float width, float height)
: psf (fileName.c_str ())
{
  scale = 1.0;
  bboxL = 72;
  bboxB = 72;
  bboxR = bboxL + width;
  bboxT = bboxB + height;

  // Write Postscript header
  psf << "%!PS-Adobe-2.0" << endl;
  psf << "%%BoundingBox: " << bboxL << " " << bboxB << " " << bboxR << " " << bboxT << endl;
  psf << "%%EndComments" << endl;
  psf << endl;
  psf << "% Abbreviations" << endl;
  psf << "/cm {matrix currentmatrix} def" << endl;
  psf << "/cpst {setrgbcolor closepath stroke} def" << endl;
  psf << "/gr {grestore} def" << endl;
  psf << "/gs {gsave} def" << endl;
  psf << "/lt {lineto} def" << endl;
  psf << "/mt {moveto} def" << endl;
  psf << "/np {newpath} def" << endl;
  psf << "/rot {rotate} def" << endl;
  psf << "/sc {scale} def" << endl;
  psf << "/seg {setrgbcolor newpath moveto lineto stroke} def" << endl;
  psf << "/slw {setlinewidth} def" << endl;
  psf << "/sm {setmatrix} def" << endl;
  psf << "/st {setrgbcolor stroke} def" << endl;
  psf << "/tr {translate} def" << endl;
  psf << endl;
}

CanvasPS::~CanvasPS ()
{
  if (psf.is_open ())
  {
	drawDone ();
  }
}

void
CanvasPS::drawDone ()
{
  // Write Postscript trailer
  psf << "%%Trailer" << endl;
  psf << "%%EOF" << endl;

  psf.close ();
}

inline void
CanvasPS::expandColor (unsigned int color)
{
  int r = (color >> 16) & 0xFF;
  int g = (color >> 8)  & 0xFF;
  int b =  color        & 0xFF;
  psf << (float) r / 255 << " " << (float) g / 255 << " " << (float) b / 255;
}

void
CanvasPS::drawPoint (const Point & p, unsigned int color)
{
  float step = 2.0 / scale;

  // "X" style
  /* "X" style
  Point p1 (p.x - step, p.y - step);
  Point p2 (p.x - step, p.y + step);
  Point p3 (p.x + step, p.y - step);
  Point p4 (p.x + step, p.y + step);
  drawSegment (p1, p4, color);
  drawSegment (p2, p3, color);
  */

  // "Dot" style
  psf << "np" << endl;
  psf << p.x << " " << p.y << " " << step << " 0 360 arc" << endl;
  expandColor (color);
  psf << " setrgbcolor" << endl;
  psf << "fill" << endl;
  psf << endl;
}

void
CanvasPS::drawSegment (const Point & a, const Point & b, unsigned int color)
{
  psf << a.x << " " << a.y << " " << b.x << " " << b.y << " ";
  expandColor (color);
  psf << " seg" << endl;
  psf << endl;
}

void
CanvasPS::drawPolygon (const std::vector<Point> & points, unsigned int color)
{
  if (points.size ())
  {
	psf << "np" << endl;
	psf << points[0].x << " " << points[0].y << " mt" << endl;
	for (int i = 1; i < points.size (); i++)
	{
	  psf << points[i].x << " " << points[i].y << " lt" << endl;
	}
	expandColor (color);
	psf << " cpst" << endl;
	psf << endl;
  }
}

void
CanvasPS::drawCircle (const Point & center, float radius, unsigned int color, float startAngle, float endAngle)
{
  startAngle *= 180 / PI;
  endAngle   *= 180 / PI;

  psf << "np" << endl;
  psf << center.x << " " << center.y << " " << radius << " " << startAngle << " " << endAngle << " arc" << endl;
  expandColor (color);
  psf << " st" << endl;
  psf << endl;
}

void
CanvasPS::drawEllipse (const Point & center, const Matrix2x2<float> & shape, unsigned int color, float startAngle, float endAngle)
{
  Matrix<float> D;
  Matrix<float> rot;
  geev (shape, D, rot);

  float a = sqrt (1.0 / D[0]);
  float b = sqrt (1.0 / D[1]);
  float angle = atan2 (rot(1,0), rot(0,0));

  startAngle *= 180 / PI;
  endAngle   *= 180 / PI;

  psf << "np" << endl;
  psf << "cm" << endl;
  psf << center.x << " " << center.y << " tr" << endl;
  psf << angle << " rot" << endl;
  psf << a << " " << b << " sc" << endl;
  psf << "0 0 1 " << startAngle << " " << endAngle << " arc" << endl;
  psf << "sm" << endl;
  expandColor (color);
  psf << " st" << endl;
  psf << endl;
}

void
CanvasPS::setTranslation (float x, float y)
{
  psf << x << " " << y << " translate" << endl;
  psf << endl;
}

void
CanvasPS::setScale (float x, float y)
{
  scale = (x > y) ? x : y;		//KenFix

  psf << x << " " << y << " sc" << endl;
  psf << 1.0 / scale << " slw" << endl;
  psf << endl;
}
