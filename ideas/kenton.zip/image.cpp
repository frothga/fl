#include "../prompt.h"
#include "VCFix.h"
#include "image.h"
#include "time.h"
#include <assert.h>		//KenFix
#include <stdio.h>

// Include for tracing
//#include <iostream>

using namespace std;
using namespace my;


// class Image ----------------------------------------------------------------

Image::Image ()
{
  timestamp = getTimestamp ();
  this->format = &GrayChar;
  width = 0;
  height = 0;
}

Image::Image (const PixelFormat & format)
{
  timestamp = getTimestamp ();
  this->format = &format;
  width = 0;
  height = 0;
}

Image::Image (int width, int height)
: buffer (width * height * GrayChar.depth)
{
  timestamp = getTimestamp ();
  this->format = &GrayChar;
  this->width  = width;
  this->height = height;
}

Image::Image (int width, int height, const PixelFormat & format)
: buffer (width * height * format.depth)
{
  timestamp = getTimestamp ();
  this->format = &format;
  this->width  = width;
  this->height = height;
}

Image::Image (const Image & that)
: buffer (that.buffer)
{
  format    = that.format;
  width     = that.width;
  height    = that.height;
  timestamp = that.timestamp;
}

void
Image::read (const std::string & fileName)
{
  // OK, so we're not autodetecting image format just yet...  :)
  readPGM (fileName);

// Use stat () to determine timestamp.
}

void
Image::readPGM (const std::string & fileName)
{
  FILE * in = fopen (fileName.c_str (), "r");
  if (in == NULL)
  {
    return;
  }

  int gotParm = 0;
  bool commentMode = false;
  while (true)
  {
	char line[256];
	fgets (line, sizeof (line), in);
	if (line[0] == '#'  ||  commentMode)
	{
	  commentMode = ! strchr (line, '\n');
	}
	else if (strcmp (line, "P5\n") == 0)
	{
	  // Should add code to verify that correct magic string appears at start of file.
	}
	else
	{
	  char * token = strtok (line, " \t\n");
	  while (token)
	  {
		switch (gotParm++)
		{
		  case 0:
			sscanf (token, "%d", &width);
			break;
		  case 1:
			sscanf (token, "%d", &height);
			break;
		  default:
			break;
		}
		token = strtok (NULL, " \t\n");
	  }
	  if (gotParm >= 3)
	  {
		break;
	  }
	}
  }

  format = &GrayChar;  // We assume below that GrayChar.depth == 1
  buffer.grow (width * height);
  fread (buffer.memory, height * width, 1, in);
  fclose (in);
}

void
Image::writePGM (const std::string & fileName) const
{
  if (*format != GrayChar  &&  *format != RGBChar)
  {
	Image temp = *this * GrayChar;
	temp.writePGM (fileName);
	return;
  }

  FILE * out = fopen (fileName.c_str (), "w");
  if (out == NULL)
  {
    return;
  }

  if (*format == GrayChar)
  {
	fprintf (out, "P5\n");
	fprintf (out, "%d %d %d\n", width, height, 255);
	fwrite (buffer.memory, height * width, 1, out);
  }
  else  // format == RGBChar
  {
	fprintf (out, "P6\n");
	fprintf (out, "%d %d %d\n", width, height, 255);
	for (int y = 0; y < height; y++)
	{
	  for (int x = 0; x < width; x++)
	  {
		unsigned int rgb = getRGB (x, y);
		unsigned char r = (rgb & 0xFF0000) >> 16;
		unsigned char g = (rgb & 0xFF00) >> 8;
		unsigned char b =  rgb & 0xFF;
		fputc (r, out);
		fputc (g, out);
		fputc (b, out);
	  }
	}
  }

  fclose (out);
}

void
Image::copyFrom (const Image & that)
{
  buffer.copyFrom (that.buffer);
  format    = that.format;
  width     = that.width;
  height    = that.height;
  timestamp = that.timestamp;
}

void
Image::copyFrom (unsigned char * buffer, int width, int height, const PixelFormat & format)
{
  if (this->buffer.memory != buffer)
  {
	timestamp = getTimestamp ();  // Actually, we don't know the timestamp on a bare buffer, but this guess is as good as any.

	this->format = &format;
	this->width  = width;
	this->height = height;

	this->buffer.copyFrom (buffer, width * height * format.depth);
  }
}

//KenFix
#undef min
#undef max
#define max(a,b)  (a)>(b)? (a) : (b)
#define min(a,b)  (a)<(b)? (a) : (b)

void
Image::resize (const int width, const int height)
{
  int needWidth = min (this->width, width);
  int needHeight = min (this->height, height);

  if (width == this->width)
  {
	if (height > this->height)
	{
	  Pointer temp (buffer);
	  buffer.release ();
	  buffer.grow (width * height * format->depth);
	  int count = width * needHeight * format->depth;
	  memcpy (buffer.memory, temp.memory, count);
	  assert (count >= 0  &&  count < buffer.size ());
	  bzero ((char *) buffer + count, buffer.size () - count);
	}
	this->height = height;
  }
  else
  {
    int oldwidth = this->width;
	this->width = width;
	this->height = height;
	Pointer temp (buffer);
	buffer.release ();
	buffer.grow (width * height * format->depth);
	buffer.clear ();

    #define reshuffle(size) \
    { \
	  for (int x = 0; x < needWidth; x++) \
	  { \
	    for (int y = 0; y < needHeight; y++) \
	    { \
		  ((size *) buffer)[y * width + x] = ((size *) temp)[y * oldwidth + x]; \
	    } \
	  } \
	}

	switch (format->depth)
	{
      case 2:
		reshuffle (unsigned short);
		break;
      case 4:
		reshuffle (unsigned int);
		break;
      case 8:
		reshuffle (double);
		break;
      case 1:
      default:
		reshuffle (unsigned char);
	}
  }
}

void
Image::bitblt (const Image & that, int toX, int toY, int fromX, int fromY, int width, int height)
{
  // Adjust parameters
  if (fromX >= that.width  ||  fromY >= that.height)
  {
	return;
  }
  if (width < 0)
  {
	width = that.width;
  }
  if (height < 0)
  {
	height = that.height;
  }
  if (toX < 0)
  {
	width += toX;
	fromX -= toX;
	toX   -= toX;  // same as toX = 0, but this makes it clear what we are doing.
  }
  if (toY < 0)
  {
	height += toY;
	fromY  -= toY;
	toY    -= toY;
  }
  if (fromX < 0)
  {
	width += fromX;
	toX   -= fromX;
	fromX -= fromX;
  }
  if (fromY < 0)
  {
	height += fromY;
	toY    -= fromY;
	fromY  -= fromY;
  }
  width = min (fromX + width, that.width) - fromX;
  height = min (fromY + height, that.height) - fromY;
  if (width <= 0  ||  height <= 0)
  {
	return;
  }

  // Get source image in same format we are.
  Image source = that * (*(this->format));

  // Adjust size of target Image (ie: this)
  int needWidth = toX + width;
  int needHeight = toY + height;
  if (needWidth > this->width  ||  needHeight > this->height)
  {
	resize (max (this->width, needWidth), max (this->height, needHeight));
  }

  // Transfer the block
  int offsetX = fromX - toX;
  int offsetY = fromY - toY;
  #define transfer(size) \
  { \
    if (offsetX < 0) \
    { \
      if (offsetY < 0) \
	  { \
        for (int x = needWidth - 1; x >= toX; x--) \
        { \
	      for (int y = needHeight - 1; y >= toY; y--) \
	      { \
            ((size *) buffer)[y * this->width + x] = ((size *) source.buffer)[(y + offsetY) * source.width + (x + offsetX)]; \
	      } \
	    } \
      } \
      else \
      { \
        for (int x = needWidth - 1; x >= toX; x--) \
        { \
	      for (int y = toY; y < needHeight; y++) \
	      { \
            ((size *) buffer)[y * this->width + x] = ((size *) source.buffer)[(y + offsetY) * source.width + (x + offsetX)]; \
	      } \
	    } \
      } \
	} \
    else \
    { \
	  if (offsetY < 0) \
	  { \
        for (int x = toX; x < needWidth; x++) \
        { \
	      for (int y = needHeight - 1; y >= toY; y--) \
	      { \
            ((size *) buffer)[y * this->width + x] = ((size *) source.buffer)[(y + offsetY) * source.width + (x + offsetX)]; \
	      } \
	    } \
	  } \
      else \
      { \
        for (int x = toX; x < needWidth; x++) \
        { \
	      for (int y = toY; y < needHeight; y++) \
	      { \
            ((size *) buffer)[y * this->width + x] = ((size *) source.buffer)[(y + offsetY) * source.width + (x + offsetX)]; \
	      } \
	    } \
      } \
    } \
  }
  switch (format->depth)
  {
    case 2:
	  transfer (unsigned short);
	  break;
    case 4:
	  transfer (unsigned int);
	  break;
    case 8:
	  transfer (double);
	  break;
    case 1:
    default:
	  transfer (unsigned char);
  }
}

Image
Image::operator + (const Image & that)
{
  if (*format != *that.format)
  {
	if (format->precedence >= that.format->precedence)
	{
	  Image temp = that * (*format);
	  return *this + temp;
	}
	else
	{
	  Image temp = (*this) * (*that.format);
	  return temp + that;
	}
  }

  Image result (max (width, that.width), max (height, that.height), *format);

  int offsetX1 = 0;
  int offsetX2 = 0;
  if (width > that.width)
  {
	offsetX2 = (width - that.width) / 2;
  }
  else
  {
	offsetX1 = (that.width - width) / 2;
  }
  int offsetY1 = 0;
  int offsetY2 = 0;
  if (height > that.height)
  {
	offsetY2 = (height - that.height) / 2;
  }
  else
  {
	offsetY1 = (that.height - height) / 2;
  }

  if (*format == GrayFloat)
  {
	ImageOf<float> image1 (*this);
	ImageOf<float> image2 (that);
	ImageOf<float> imageR (result);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		float pixel1 = 0;
		if (x - offsetX1 >= 0  &&  x - offsetX1 < width  &&  y - offsetY1 >= 0  &&  y - offsetY1 < height)
		{
		  pixel1 = image1 (x - offsetX1, y - offsetY1);
		}
		float pixel2 = 0;
		if (x - offsetX2 >= 0  &&  x - offsetX2 < that.width  &&  y - offsetY2 >= 0  &&  y - offsetY2 < that.height)
		{
		  pixel2 = image2 (x - offsetX2, y - offsetY2);
		}
		imageR (x, y) = pixel1 + pixel2;
	  }
	}
  }
  else if (*format == GrayDouble)
  {
	ImageOf<double> image1 (*this);
	ImageOf<double> image2 (that);
	ImageOf<double> imageR (result);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		double pixel1 = 0;
		if (x - offsetX1 >= 0  &&  x - offsetX1 < width  &&  y - offsetY1 >= 0  &&  y - offsetY1 < height)
		{
		  pixel1 = image1 (x - offsetX1, y - offsetY1);
		}
		double pixel2 = 0;
		if (x - offsetX2 >= 0  &&  x - offsetX2 < that.width  &&  y - offsetY2 >= 0  &&  y - offsetY2 < that.height)
		{
		  pixel2 = image2 (x - offsetX2, y - offsetY2);
		}
		imageR (x, y) = pixel1 + pixel2;
	  }
	}
  }
  else
  {
	for (int x = 0; x < that.width; x++)
	{
	  for (int y = 0; y < that.height; y++)
	  {
		unsigned int pixel = getRGB (x - offsetX1, y - offsetY1);
		int r = (pixel & 0xFF0000) >> 16;
		int g = (pixel &   0xFF00) >> 8;
		int b =  pixel &     0xFF;
		pixel = that.getRGB (x - offsetX2, y - offsetY2);
		r += (pixel & 0xFF0000) >> 16;
		g += (pixel &   0xFF00) >> 8;
		b +=  pixel &     0xFF;
		r = (r < 255) ? r : 255;	//KenFix
		g = (g < 255) ? g : 255;	//KenFix
		b = (b < 255) ? b : 255;	//KenFix
		result.setRGB (x, y, (r << 16) | (g << 8) | b);
	  }
	}
  }

  return result;
}

Image
Image::operator - (const Image & that)
{
  if (*format != *that.format)
  {
	if (format->precedence >= that.format->precedence)
	{
	  Image temp = that * (*format);
	  return *this - temp;
	}
	else
	{
	  Image temp = (*this) * (*that.format);
	  return temp - that;
	}
  }

  Image result (max (width, that.width), max (height, that.height), *format);

  int offsetX1 = 0;
  int offsetX2 = 0;
  if (width > that.width)
  {
	offsetX2 = (width - that.width) / 2;
  }
  else
  {
	offsetX1 = (that.width - width) / 2;
  }
  int offsetY1 = 0;
  int offsetY2 = 0;
  if (height > that.height)
  {
	offsetY2 = (height - that.height) / 2;
  }
  else
  {
	offsetY1 = (that.height - height) / 2;
  }

  if (*format == GrayFloat)
  {
	ImageOf<float> image1 (*this);
	ImageOf<float> image2 (that);
	ImageOf<float> imageR (result);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		float pixel1 = 0;
		if (x - offsetX1 >= 0  &&  x - offsetX1 < width  &&  y - offsetY1 >= 0  &&  y - offsetY1 < height)
		{
		  pixel1 = image1 (x - offsetX1, y - offsetY1);
		}
		float pixel2 = 0;
		if (x - offsetX2 >= 0  &&  x - offsetX2 < that.width  &&  y - offsetY2 >= 0  &&  y - offsetY2 < that.height)
		{
		  pixel2 = image2 (x - offsetX2, y - offsetY2);
		}
		imageR (x, y) = pixel1 - pixel2;
	  }
	}
  }
  else if (*format == GrayDouble)
  {
	ImageOf<double> image1 (*this);
	ImageOf<double> image2 (that);
	ImageOf<double> imageR (result);
	for (int x = 0; x < result.width; x++)
	{
	  for (int y = 0; y < result.height; y++)
	  {
		double pixel1 = 0;
		if (x - offsetX1 >= 0  &&  x - offsetX1 < width  &&  y - offsetY1 >= 0  &&  y - offsetY1 < height)
		{
		  pixel1 = image1 (x - offsetX1, y - offsetY1);
		}
		double pixel2 = 0;
		if (x - offsetX2 >= 0  &&  x - offsetX2 < that.width  &&  y - offsetY2 >= 0  &&  y - offsetY2 < that.height)
		{
		  pixel2 = image2 (x - offsetX2, y - offsetY2);
		}
		imageR (x, y) = pixel1 - pixel2;
	  }
	}
  }
  else
  {
	for (int x = 0; x < that.width; x++)
	{
	  for (int y = 0; y < that.height; y++)
	  {
		unsigned int pixel = getRGB (x - offsetX1, y - offsetY1);
		int r = (pixel & 0xFF0000) >> 16;
		int g = (pixel &   0xFF00) >> 8;
		int b =  pixel &     0xFF;
		pixel = that.getRGB (x - offsetX2, y - offsetY2);
		r -= (pixel & 0xFF0000) >> 16;
		g -= (pixel &   0xFF00) >> 8;
		b -=  pixel &     0xFF;
		r = (r > 0) ? r : 0;	//KenFix
		g = (g > 0) ? g : 0;	//KenFix
		b = (b > 0) ? b : 0;	//KenFix
		result.setRGB (x, y, (r << 16) | (g << 8) | b);
	  }
	}
  }

  return result;
}

Image &
Image::operator *= (double factor)
{
  if (*format == GrayFloat)
  {
	float * pixel = (float *) buffer;
	float * end   = pixel + width * height;
	while (pixel < end)
	{
	  *pixel++ *= factor;
	}
  }
  else if (*format == GrayDouble)
  {
	double * pixel = (double *) buffer;
	double * end   = pixel + width * height;
	while (pixel < end)
	{
	  *pixel++ *= factor;
	}
  }
  else if (*format == GrayChar)
  {
	// This does not explicitly handle negative factors.
	int ifactor = (int) (factor * (1 << 16));
	unsigned char * pixel = (unsigned char *) buffer;
	unsigned char * end   = pixel + width * height;
	while (pixel < end)
	{
	  *pixel++ = (*pixel * ifactor) >> 16;
	}
  }
  else
  {
	throw "Image::operator *: unimplemented format";
  }

  return *this;
}

unsigned int
Image::getRGB (const int x, const int y) const
{
  if (x < 0  ||  x >= width  ||  y < 0  ||  y >= height)
  {
	// We could throw an exception, which may help expose errors of logic in the caller.
	// However, by being tolerant, we enable more flexible programming.  The caller can
	// view the image as existing but being zero outside its bounds.
	return 0;
  }

  return format->getRGB (((char *) buffer) + (y * width + x) * format->depth);
}

void
Image::setRGB (const int x, const int y, const unsigned int rgb)
{
  if (x < 0  ||  x >= width  ||  y < 0  ||  y >= height)
  {
	// Silently ignore out of bounds pixels.
	return;
  }

  //KenFix
  //return format->setRGB (((char *) buffer)+ (y * width + x) * format->depth, rgb);
}

