#ifndef time_h
#define time_h

//KenFix
#include <time.h>

namespace my
{
  inline double
  getTimestamp ()
  {
	time_t secs;
	secs = time(NULL);

	struct tm * t;
	t = localtime(&secs);
	return (t->tm_hour * 3600) + (t->tm_min * 60) + t->tm_sec;
  }
}

#endif
