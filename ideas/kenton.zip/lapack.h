#ifndef my_lapack_h
#define my_lapack_h


// Interface to LAPACK ------------------------------------------------------

// For efficiency's sake, the LAPACK bridge routines will not check if the
// storage scheme of the Matrix parameters is compatible with the LAPACK
// routine.  IE: you can't in general pass a sparse Matrix for an out
// parameter, because the routine will fill the memory block as if it is
// dense.  In the same way, transposes and row views need to be realized
// in a new chunk of memory before being passed.  This is the programmer's
// responsibility.

// It is OK to pass empty Matrix objects for out parameters.  The LAPACK
// bridge routines will expand them as necessary for the size of the output.


#include "lapacks.h"
#include "lapackd.h"


namespace my
{
  // Returns the inverse of the dense square matrix A.
  template <class T>
  inline Matrix<T>
  operator ! (const Matrix<T> & A)
  {
	int size = (A.rows() > A.columns()) ? A.rows() : A.columns();	//KenFix
	Matrix<T> b (size, size);
	b.identity ();

	Matrix<T> tempA;
	tempA.copyFrom (A);

	Matrix<T> result;

	gelss (tempA, result, b);

	return result;
  }
}


#endif
