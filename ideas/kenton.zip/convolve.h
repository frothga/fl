#ifndef convolve_h
#define convolve_h


#include "image.h"
#include "matrix.h"
#include "search.h"
#include "point.h"


// Coordinate system convention: For efficiency's sake, we follow the standard
// coordinate system for pixel rasters.  The origin is in the upper left.
// Positive x axis goes toward the right, and positive y axis goes downward.
// This implies two slightly non-intuitive things:
// 1) y-derivatives will be the negative of what one would expect from looking
//    at a picture.  IE: if the image is darker at the bottom and ligher at
//    the top, y-derivative will be negative, not positive.
// 2) Transformation matrices will rotate things clockwise when one would
//    expect them to rotate counterclockwise.
// Also, all float-valued pixel coordinates follow the convention for
// Point.  Integer-valued pixel coordinates refer to either the entire
// pixel or to its center, depending on context.

// TO DO:
//   Work LaplacianSearchable back into the convolution hierarchy.


namespace my
{
  // 2D Convolutions ----------------------------------------------------------

  class Convolution2D : public Filter, public Image
  {
	// Stores the kernel as a discrete set of points (a raster).

  public:
	Convolution2D (const PixelFormat & format = GrayFloat);
	Convolution2D (const Image & image);

	virtual Image filter (const Image & image);
	virtual double response (const Image & image, const Point & p) const;  // Strength of response of filter to image at pixel (x, y).
  };

  class Gaussian2D : public Convolution2D
  {
  public:
	Gaussian2D (double sigma = 1.0, const PixelFormat & format = GrayFloat);

	//virtual Image filter (const Image & image);
	virtual double response (const Image & image, const Point & p) const;

	static double cutoff;  // Minimum number of standard deviations to include in a Gaussian kernel
  };

  class DifferenceOfGaussians : public Convolution2D
  {
  public:
	DifferenceOfGaussians (double sigmaPlus, double sigmaMinus, const PixelFormat & format = GrayFloat);
  };

  class GaussianDerivativeFirst : public Convolution2D
  {
  public:
	GaussianDerivativeFirst (int xy = 0, double sigmaX = 1.0, double sigmaY = -1.0, double angle = 0, const PixelFormat & format = GrayFloat);  // xy == 0 means x-derivative; xy != 0 means y-derivative
  };

  class GaussianDerivativeSecond : public Convolution2D
  {
  public:
	GaussianDerivativeSecond (int xy1 = 0, int xy2 = 0, double sigmaX = 1.0, double sigmaY = -1.0, double angle = 0, const PixelFormat & format = GrayFloat);
  };

  class GaussianDerivativeThird : public Convolution2D
  {
  public:
	GaussianDerivativeThird (int xy1 = 0, int xy2 = 0, int xy3 = 0, double sigmaX = 1.0, double sigmaY = -1.0, double angle = 0, const PixelFormat & format = GrayFloat);
  };

  class Laplacian : public Convolution2D
  {
  public:
	Laplacian (double sigma = 1.0, const PixelFormat & format = GrayFloat);

	double sigma;
  };

  // This Laplacian computes directly every time, rather than storing the
  // convolution as an Image.  (It is listed here with the Convolution2Ds, but
  // it isn't really one.)  This makes it more efficient in the case where you
  // need to construct a Laplacian of arbitrary size and use it only once,
  // and you need to do this repeatedly.
  class LaplacianSearchable : public Searchable
  {
  public:
	LaplacianSearchable (const Image & image, const Point & center, double min = 1, double max = 1000);

	virtual double value (Vector<double> point);
	virtual int dimension () const;
	virtual double min (int dimension) const;
	virtual double max (int dimension) const;

	Image image;
	float centerX;
	float centerY;
	double min_;
	double max_;
  };


  // 1D Convolutions ----------------------------------------------------------

  class Convolution1D : public Filter, public Image
  {
  public:
	enum Direction
	{
	  vertical,
	  horizontal
	};

	Convolution1D (Direction direction = horizontal, const PixelFormat & format = GrayFloat);
	Convolution1D (const Image & image);

	virtual Image filter (const Image & image);
	virtual double response (const Image & image, const Point & p) const;  // Strength of response of filter to image at pixel (x, y).

	Direction direction;
  };

  class Gaussian1D : public Convolution1D
  {
  public:
	Gaussian1D (double sigma, Direction direction = horizontal, const PixelFormat & format = GrayFloat);

	//virtual Image filter (const Image & image);
  };

  class GaussianDerivative1D : public Convolution1D
  {
  public:
	GaussianDerivative1D (double sigma, Direction direction = horizontal, const PixelFormat & format = GrayFloat);
  };


  // Interest operators -------------------------------------------------------

  class FilterHarris : public Filter
  {
  public:
	FilterHarris (double sigmaI = 1.0, double s = 0.66, const PixelFormat & format = GrayFloat);  // s = sigmaD / sigmaI

	Image filter (const Image & image);  // Relies on preprocess, process, and response to do all the work.
	void preprocess (const Image & image);  // Extracts the autocorrelation matrix from the image.  Stores in xx, xy, and yy.
	Image process ();  // Collects values of response () into an Image.
	double response (const int x, const int y) const  // For one pixel: sums autocorrelation matrix using G and then determines Harris response.
	{
	  // (x, y) is in terms of the resulting image, ie: the output of this
	  // filter.  The meanings of x and y are shifted by "offset" (see below)
	  // relative to the coordinates of the input image.
	  Point p (x + offsetI, y + offsetI);
	  double txx = G_I.response (xx, p);
	  double txy = G_I.response (xy, p);
	  double tyy = G_I.response (yy, p);
	  return (txx * tyy - txy * txy) - alpha * (txx + tyy) * (txx + tyy);
	}

	Gaussian2D           G_I;   // Gaussian for integration
	Gaussian1D           G1_I;  // seperated Gaussian for integration
	Gaussian1D           G1_D;  // seperated Gaussian for derivation (blurring pass)
	GaussianDerivative1D dG_D;  // seperated Gaussian for derivation
	Image xx;  // Components of the autocorrelation matrix.
	Image xy;  // These are built by preprocess ().
	Image yy;
	int offset;   // Total amount of one image border removed
	int offsetI;  // Border removed by integration
	int offsetD;  // Border removed by differentiation

	static const double alpha;

  protected:
	// If the blurring part of the separable Gaussian derivative kernel has
	// a larger radius, then the difference in pixels is stored in offset1.
	// If the derivative part has a larger radius, then the difference is kept
	// in offset2.  These help align the x and y derivative images correctly.
	int offset1;
	int offset2;
  };


  // Misc -----------------------------------------------------------------------

  class NonMaxSuppress : public Filter
  {
  public:
	NonMaxSuppress (int half = 1);

	Image filter (const Image & image);

	int half;  // Number of pixels away from center to check for local maxima.
	float maximum;  // Largest value found during last run of filter.
	float average;  // Average value found during last run of filter.
  };

  // Treating the image as a vector in high-dimensional space, normalize to given Euclidean length.
  class Normalize : public Filter
  {
  public:
	Normalize (double length = 1);

	Image filter (const Image & image);

	double length;
  };

  extern Normalize UnitNorm;  // Normalize with length = 1.

  class Transform : public Filter
  {
  public:
	Transform (const MatrixAbstract<float> & A, bool inverse = false);  // A should be at least 2x2
	Transform (const MatrixAbstract<double> & A, bool inverse = false);
	Transform (float angle);
	Transform (float scaleX, float scaleY);

	virtual Image filter (const Image & image);

	void setPeg (float originX = -1, float originY = -1, int width = -1, int height = -1);  // Turns on pegging.  originX == -1 means use center of original image.  originY == -1 is similar.  width == -1 means use width of original image.  height == -1 is similar.
	void setWindow (float originX, float originY, int width, int height);
	void prepareResult (const Image & image, Image & result, Vector<float> & cs, Vector<float> & cd) const;  // Subroutine of filter ().  Finalizes parameters that control fit between source and destination images.
	Transform operator * (const Transform & that) const;

	Matrix2x2<float> A;  // Transformation matrix (from input image to output image)
	float translateX;  // The translation components of the transformation.  IE: the third column of a 3x3 homogenous tranformatin matrix.
	float translateY;
	Matrix2x2<float> IA;  // Inverse of A.  Maps coordinates from output image back to input image.
	bool needInverse;  // Flag for lazy computation of IA

	// Translation modes:
	// peg default
	// F   F       Transformation is centered around (0, 0) in both images.  Result is a viewport that starts at (originX, originY) and extends for width x height.
	// F   T       Transformation is centered around (O, 0) in both images.  Viewport starts at (0, 0) and has same dimensions as source image.
	// T   F       Result is sized width x height, with transformation centered at (originX, originY) in original image and at actual center in resulting image.
	// T   T       Entire image is fit inside result
	bool peg;  // Indicates that transformation is relative to a "peg" rather than (0, 0).
	bool defaultViewport;  // Indicates that viewport parameters are calculated rather than provided by user.
	float originX;
	float originY;
	int width;
	int height;
  };

  class TransformGauss : public Transform
  {
  public:
	TransformGauss (const MatrixAbstract<float> & A, bool inverse = false) : Transform (A, inverse), G (GrayFloat) {needG = true;}
	TransformGauss (const MatrixAbstract<double> & A, bool inverse = false) : Transform (A, inverse), G (GrayFloat) {needG = true;}
	TransformGauss (float angle) : Transform (angle), G (GrayFloat) {needG = true;}
	TransformGauss (float scaleX, float scaleY) : Transform (scaleX, scaleY), G (GrayFloat) {needG = true;}
	TransformGauss (const Transform & that) : Transform (that), G (GrayFloat) {needInverse = true; needG = true;}
	void prepareG ();

	virtual Image filter (const Image & image);

	ImageOf<float> G;  // Gaussian used to calculate pixel values
	int Gshw;  // Width of half of Gaussian in source pixels
	int Gshh;  // Ditto for height
	int GstepX;  // Number of cells in Gaussian per one source pixel
	int GstepY;
	float sigmaX;  // Scale of Gaussian in source pixels
	float sigmaY;
	bool needG;  // Flag for lazy generation of G
  };

  class Rotate180 : public Filter
  {
  public:
	Image filter (const Image & image);
  };
}


#endif
