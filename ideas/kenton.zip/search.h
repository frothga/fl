#ifndef search_h
#define search_h


#include "matrix.h"
#include "VCFix.h"

#include <math.h>

//KenFix
#undef min
#undef max

namespace my
{
  // General search interface -------------------------------------------------

  class Searchable
  {
  public:
	// The mins and maxes specified below just delimit a cube around the
	// searchable space.  It is permissable for the searchable space to have
	// a much more complicated shape.  If a point passed to value () falls
	// outside that shape, value must throw an exception.
	virtual double value (Vector<double> point) {return point[0];}  // Return result of "value function" at the given point.
	virtual int dimension () const {return 1;}  // Number of dimensions in the search space.
	virtual double min (int dimension) const {return -INFINITY;}  // Minimum value along the given dimension.  Dimensions are numbered from zero.
	virtual double max (int dimension) const {return INFINITY;}  // ditto for maximum
  };

  class Search
  {
  public:
	virtual Vector<double> search (Searchable & searchable) = 0;
  };


  // Specific Searches --------------------------------------------------------

  class AnnealingAdaptive : public Search
  {
	virtual Vector<double> search (Searchable & searchable);
  };
}


#endif
