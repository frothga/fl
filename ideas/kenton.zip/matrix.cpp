#include "VCFix.h"
#include "matrix.h"
#include "matrixtcc.cpp"


using namespace my;
using namespace std;


// float ----------------------------------------------------------------------

//KenFix
template class my::MatrixAbstract<float>;
template class my::Matrix<float>;
template class my::Vector<float>;
template class my::MatrixPacked<float>;
template class my::MatrixTranspose<float>;
template class my::MatrixRegion<float>;
template class my::Matrix2x2<float>;
template class my::Matrix3x3<float>;

// Function template instantiation seems to be broken in gcc 3.x
//template ostream & operator << (ostream & stream, const Matrix<float> & A);


// double ---------------------------------------------------------------------

//KenFix
template class my::MatrixAbstract<double>;
template class my::Matrix<double>;
template class my::Vector<double>;
template class my::MatrixPacked<double>;
template class my::MatrixTranspose<double>;
template class my::MatrixRegion<double>;
template class my::Matrix2x2<double>;
template class my::Matrix3x3<double>;

//template ostream & operator << (ostream & stream, const Matrix<double> & A);
