#ifndef my_lapack_single_h
#define my_lapack_single_h

#include "matrix.h"
#include "lapackprotos.h"


namespace my
{
  // Compute eigenvalues and eigenvectors for symmetric matrix
  inline void
  syev (const Matrix<float> & A, Matrix<float> & eigenvalues, Matrix<float> & eigenvectors)
  {
	int n = A.rows ();
	eigenvectors.copyFrom (A);
	eigenvalues.resize (n);

	char jobz = 'V';
	char uplo = 'U';

	int lwork = n * n;
	lwork = (lwork > 10) ? lwork : 10;  // Special case for n == 1 and n == 2;	//KenFix
	float * work = new float [lwork];
	int info = 0;

	ssyev_ (jobz,
			uplo,
			n,
			& eigenvectors[0],
			n,
			& eigenvalues[0],
			work,
			lwork,
			info);

	delete work;

	if (info)
	{
	  throw info;
	}
  }

  // Compute eigenvalues (only) for symmetric matrix.
  inline void
  syev (const Matrix<float> & A, Matrix<float> & eigenvalues)
  {
	int n = A.rows ();

	Matrix<float> eigenvectors;
	eigenvectors.copyFrom (A);
	eigenvalues.resize (n);

	char jobz = 'N';
	char uplo = 'U';

	int lwork = n * n;
	lwork = (lwork > 10) ? lwork : 10;  // Special case for n == 1 and n == 2;	//KenFix
	float * work = new float [lwork];
	int info = 0;

	ssyev_ (jobz,
			uplo,
			n,
			& eigenvectors[0],
			n,
			& eigenvalues[0],
			work,
			lwork,
			info);

	delete work;

	if (info)
	{
	  throw info;
	}
  }

  // Compute eigenvalues and eigenvectors for general (non-symmetric) matrix
  // eigenvalues should really be Matrix< complex<float> >.  Fix this some time.
  inline void
  geev (const Matrix<float> & A, Matrix<float> & eigenvalues, Matrix<float> & eigenvectors)
  {
	char jobvl = 'N';
	char jobvr = 'V';

	int lda = A.rows ();
	int n = (lda < A.columns ()) ? lda : A.columns ();	//KenFix
	Matrix<float> tempA;
	tempA.copyFrom (A);

	eigenvalues.resize (n);
	Matrix<float> wi (n);

	eigenvectors.resize (n, n);

	int lwork = 5 * n;
	float * work = new float [lwork];
	int info = 0;

	sgeev_ (jobvl,
			jobvr,
			n,
			& tempA[0],
			lda,
			& eigenvalues[0],
			& wi[0],
			0,
			1,  // ldvl >= 1.  A lie to make lapack happy.
			& eigenvectors[0],
			n,
			work,
			lwork,
			info);

	delete work;

	if (info)
	{
	  throw info;
	}
  }

  // Solve least squares problem using SVD via QR
  inline void
  gelss (Matrix<float> & A, Matrix<float> & x, const Matrix<float> & b)
  {
	// A is not preserved because it returns info (right singular values)
	// which may be useful.
	int m = A.rows ();
	int n = A.columns ();
	int ldb = (m > n) ? m : n;	//KenFix
	int bn = b.columns ();
	x.resize (ldb, bn);
	x.copyFrom (b);
	x.rows_ = ldb;  // Size of answer x, not necessarily size of b.

	float rcond = -1;
	int rank;
    int ldwork = 5 * ((ldb > bn) ? ldb : bn);	//KenFix
    float * work = new float[ldwork];
    float * s = new float[((m < n) ? m : n)];	//KenFix
	int info = 0;

    sgelss_ (m,
			 n,
			 bn,
			 & A[0],
			 m,
			 & x[0],
			 ldb,
			 s,
			 rcond,
			 rank,
			 work,
			 ldwork,
			 info);

    delete work;
    delete s;

	if (info)
	{
	  throw info;
	}
  }

  inline void
  gesvd (const Matrix<float> & A, Matrix<float> & U, Matrix<float> & S, Matrix<float> & VT)
  {
	char jobu = 'A';
	char jobvt = 'A';
	int m = A.rows ();
	int n = A.columns ();

	Matrix<float> tempA;
	tempA.copyFrom (A);

	U.resize (m, m);
	S.resize ((m < n) ? m : n);				//KenFix
	VT.resize (n, n);

    int lwork = 5 * ((m > n) ? m : n);		//KenFix
    float * work = new float[lwork];
	int info = 0;

	sgesvd_ (jobu,
			 jobvt,
			 m,
			 n,
			 & tempA[0],
			 m,
			 & S[0],
			 & U[0],
			 m,
			 & VT[0],
			 n,
			 work,
			 lwork,
			 info);

    delete work;

	if (info)
	{
	  throw info;
	}
  }
}


#endif
