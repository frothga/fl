#include "VCFix.h"
#include "descriptor.h"
#include "random.h"
#include "lapack.h"
#include "pi.h"

// For debugging
#include "time.h"
//#include "slideshow.h"	//KenFix
#include "canvas.h"


using namespace std;
using namespace my;


// class Descriptor -----------------------------------------------------------

Descriptor *
Descriptor::factory (istream & stream)
{
  string name;
  getline (stream, name);

  if (name == typeid (DescriptorFilters).name ())
  {
	return new DescriptorFilters (stream);
  }
  else if (name == typeid (DescriptorPatch).name ())
  {
	return new DescriptorPatch (stream);
  }
  else if (name == typeid (DescriptorSchmidScale).name ())
  {
	return new DescriptorSchmidScale (stream);
  }
  else if (name == typeid (DescriptorSchmid).name ())
  {
	return new DescriptorSchmid (stream);
  }
  else if (name == typeid (DescriptorSpin).name ())
  {
	return new DescriptorSpin (stream);
  }
  else
  {
	cerr << "Unknown Descriptor: " << name << endl;
	return NULL;
  }
}

Descriptor::~Descriptor ()
{
}


// class DescriptorFilters ----------------------------------------------------

DescriptorFilters::DescriptorFilters ()
{
}

DescriptorFilters::DescriptorFilters (istream & stream)
{
  read (stream);
  prepareFilterMatrix ();
}

DescriptorFilters::~DescriptorFilters ()
{
}


//KenFix
#define max(a,b)  (a)>(b)? (a) : (b)
#define min(a,b)  (a)<(b)? (a) : (b)

void
DescriptorFilters::prepareFilterMatrix ()
{
  // Determine size of patch
  patchWidth = 0;
  patchHeight = 0;
  vector<Convolution2D>::iterator i;
  for (i = filters.begin (); i < filters.end (); i++)
  {
	patchWidth = max (patchWidth, i->width);
	patchHeight = max (patchHeight, i->height);
  }
  filterMatrix.resize (filters.size (), patchWidth * patchHeight);

  // Populate matrix
  Rotate180 rotation;
  for (int j = 0; j < filters.size (); j++)
  {
	Image temp (patchWidth, patchHeight, GrayFloat);
	temp.clear ();
	int ox = (patchWidth - filters[j].width) / 2;
	int oy = (patchHeight - filters[j].height) / 2;
	temp.bitblt (filters[j], ox, oy);
	temp *= rotation;
	for (int k = 0; k < patchWidth * patchHeight; k++)
	{
	  filterMatrix (j, k) = ((float *) temp.buffer)[k];
	}
  }
}

Vector<float>
DescriptorFilters::value (const Image & image, const PointInterest & point)
{
  Vector<float> result (filters.size ());
  for (int i = 0; i < filters.size (); i++)
  {
	result[i] = filters[i].response (image, point);
  }
  return result;
}

Image
DescriptorFilters::patch (const Vector<float> & value)
{
  Vector<float> b = value / value.norm (2);
  Vector<float> x;
  Matrix<float> A;
  A.copyFrom (filterMatrix);
  gelss (A, x, b);
  Image result;
  result.copyFrom ((unsigned char *) x.data, patchWidth, patchHeight, GrayFloat);
  return result;
}

void
DescriptorFilters::read (istream & stream)
{
  // Don't read the class name.  Instead, assume it has already been read by
  // factory ().
  int count = 0;
  stream.read ((char *) &count, sizeof (count));
  for (int i = 0; i < count; i++)
  {
	int width = 0;
	int height = 0;
	stream.read ((char *) &width, sizeof (width));
	stream.read ((char *) &height, sizeof (height));
	Image image (width, height, GrayFloat);
	stream.read ((char *) image.buffer, image.buffer.size ());
	filters.push_back (Convolution2D (image));
  }
}

void
DescriptorFilters::write (ostream & stream)
{
  stream << typeid (*this).name () << endl;
  int count = filters.size ();
  stream.write ((char *) &count, sizeof (count));
  for (int i = 0; i < count; i++)
  {
	stream.write ((char *) &filters[i].width, sizeof (filters[i].width));
	stream.write ((char *) &filters[i].height, sizeof (filters[i].height));
	stream.write ((char *) filters[i].buffer, filters[i].buffer.size ());
  }
}


// class DescriptorFiltersTexton ----------------------------------------------

DescriptorFiltersTexton::DescriptorFiltersTexton (int angles, int scales, float firstScale, float scaleStep)
{
  if (firstScale < 0)
  {
	firstScale = 1.0 / sqrt (2.0);
  }
  if (scaleStep < 0)
  {
	scaleStep = sqrt (2.0);
  }

  for (int i = 0; i < scales; i++)
  {
	float sigma = firstScale * pow (scaleStep, i);
	DifferenceOfGaussians d (sigma * scaleStep, sigma / scaleStep);
	d *= UnitNorm;
	filters.push_back (d);
	for (int j = 0; j < angles; j++)
	{
	  float angle = (PI / angles) * j;
	  GaussianDerivativeSecond e (1, 1, 3 * sigma, sigma, angle);
	  e *= UnitNorm;
	  filters.push_back (e);
	  GaussianDerivativeFirst o (1, 3 * sigma, sigma, angle);
	  o *= UnitNorm;
	  filters.push_back (o);
	}
  }

  prepareFilterMatrix ();
}


// class DescriptorPatch ------------------------------------------------------

DescriptorPatch::DescriptorPatch (int width, int height)
{
  this->width = width;
  this->height = height;
}

DescriptorPatch::DescriptorPatch (std::istream & stream)
{
  read (stream);
}

DescriptorPatch::~DescriptorPatch ()
{
}

Vector<float>
DescriptorPatch::value (const Image & image, const PointInterest & point)
{
  ImageOf<float> temp;
  temp.bitblt (image, 0, 0, (int) rint (point.x - width / 2), (int) rint (point.y - height / 2), width, height);
  Vector<float> result (height * width);
  for (int row = 0; row < height; row++)
  {
	for (int column = 0; column < width; column++)
	{
	  result[column * height + row] = temp (column, row);
	}
  }
  return result;
}

Image
DescriptorPatch::patch (const Vector<float> & value)
{
  ImageOf<float> result (width, height, GrayFloat);
  for (int row = 0; row < height; row++)
  {
	for (int column = 0; column < width; column++)
	{
	  result (column, row) = value[column * height + row];
	}
  }
  return result;
}

void
DescriptorPatch::read (std::istream & stream)
{
  stream.read ((char *) &width, sizeof (width));
  stream.read ((char *) &height, sizeof (height));
}

void
DescriptorPatch::write (std::ostream & stream)
{
  stream << typeid (*this).name () << endl;
  stream.write ((char *) &width, sizeof (width));
  stream.write ((char *) &height, sizeof (height));
}


// class DescriptorSchmidScale ------------------------------------------------
//KenFix
DescriptorSchmidScale::DescriptorSchmidScale (float sigma)
{
  this->sigma = sigma;
  initialize ();
}

DescriptorSchmidScale::DescriptorSchmidScale (std::istream & stream)
{
  read (stream);
}

void
DescriptorSchmidScale::initialize ()
{
  G = Gaussian2D (sigma);

  Gx = GaussianDerivativeFirst (0, sigma);
  Gy = GaussianDerivativeFirst (1, sigma);

  Gxx = GaussianDerivativeSecond (0, 0, sigma);
  Gxy = GaussianDerivativeSecond (0, 1, sigma);
  Gyy = GaussianDerivativeSecond (1, 1, sigma);

  Gxxx = GaussianDerivativeThird (0, 0, 0, sigma);
  Gxxy = GaussianDerivativeThird (0, 0, 1, sigma);
  Gxyy = GaussianDerivativeThird (0, 1, 1, sigma);
  Gyyy = GaussianDerivativeThird (1, 1, 1, sigma);

  // Normalize scales: one sigma per level of derivation
  Gx *= sigma;
  Gy *= sigma;

  float sigma2 = sigma * sigma;
  Gxx *= sigma2;
  Gxy *= sigma2;
  Gyy *= sigma2;

  float sigma3 = sigma2 * sigma;
  Gxxx *= sigma3;
  Gxxy *= sigma3;
  Gxyy *= sigma3;
  Gyyy *= sigma3;
}

DescriptorSchmidScale::~DescriptorSchmidScale ()
{
}

Vector<float>
DescriptorSchmidScale::value (const Image & image, const PointInterest & point)
{
  Vector<float> result (9);

  float L = G.response (image, point);
  float Ld[2];
  Ld[0] = Gx.response (image, point);
  Ld[1] = Gy.response (image, point);
  float Ldd[2][2];
  Ldd[0][0] = Gxx.response (image, point);
  Ldd[0][1] = Gxy.response (image, point);
  Ldd[1][0] = Ldd[0][1];
  Ldd[1][1] = Gyy.response (image, point);
  float Lddd[2][2][2];
  Lddd[0][0][0] = Gxxx.response (image, point);
  Lddd[0][0][1] = Gxxy.response (image, point);
  Lddd[0][1][0] = Lddd[0][0][1];
  Lddd[0][1][1] = Gxyy.response (image, point);
  Lddd[1][0][0] = Lddd[0][0][1];
  Lddd[1][0][1] = Lddd[0][1][1];
  Lddd[1][1][0] = Lddd[0][1][1];
  Lddd[1][1][1] = Gyyy.response (image, point);

  float e[2][2];
  e[0][0] = 0;
  e[0][1] = 1;
  e[1][0] = -1;
  e[1][1] = 0;

  result[0] = L;
  for (int i = 0; i < 2; i++)
  {
	result[1] += Ld[i] * Ld[i];
	result[3] += Ldd[i][i];
	for (int j = 0; j < 2; j++)
	{
	  result[2] += Ld[i] * Ldd[i][j] * Ld[j];
	  result[4] += Ldd[i][j] * Ldd[j][i];
	  for (int k = 0; k < 2; k++)
	  {
		result[6] += Lddd[i][i][j] * Ld[j] * Ld[k] * Ld[k] - Lddd[i][j][k] * Ld[i] * Ld[j] * Ld[k];
		result[8] += Lddd[i][j][k] * Ld[i] * Ld[j] * Ld[k];
		for (int l = 0; l < 2; l++)
		{
		  result[5] += e[i][j] * (Lddd[j][k][l] * Ld[i] * Ld[k] * Ld[l] - Lddd[j][k][k] * Ld[i] * Ld[l] * Ld[l]);
		  result[7] -= e[i][j] * Lddd[j][k][l] * Ld[i] * Ld[k] * Ld[l];
		}
	  }
	}
  }

  return result;
}

Image
DescriptorSchmidScale::patch (const Vector<float> & value)
{
  // This code is untested!

  Image result (G.width, G.height, GrayFloat);

  PointInterest center;
  center.x = result.width / 2;
  center.y = result.height / 2;

  int dimension = result.width * result.height;
  int levels = 10;
  float freezing =  1.0 / pow (2.0, levels);
  float temperature = 1.0;
  int patience = dimension / levels;
  int gotBetter = 0;
  int gotWorse = 0;
  float lastDistance = 1e30;
  while (temperature > freezing)
  {
	// Generate a guess
	ImageOf<float> guess (result.width, result.height, GrayFloat);
	for (int x = 0; x < guess.width; x++)
	{
	  for (int y = 0; y < guess.height; y++)
	  {
		guess (x, y) = randGaussian ();
	  }
	}
	guess *= UnitNorm;
	guess *= temperature;
	guess = result + guess;

	// Evaluate distance from guess to value
	Vector<float> guessValue = this->value (guess, center);
	guessValue = guessValue - value;
	float distance = guessValue.norm (1);  // should this be norm (2) instead?

	// If improved, keep guess
	if (distance <= lastDistance)
	{
	  gotBetter++;
	  gotWorse = 0;
	  result = guess;
	  lastDistance = distance;
	}
	else
	{
	  gotWorse++;
	  gotBetter = 0;
	}

	// Adjust temperature
	if (gotWorse > patience)
	{
	  temperature /= 2.0;
	  gotWorse = 0;
	}
	if (gotBetter > patience)
	{
	  temperature *= 2.0;
	  gotBetter = 0;
	}
  }

  return result;
}

void
DescriptorSchmidScale::read (std::istream & stream)
{
  stream.read ((char *) &sigma, sizeof (sigma));
  initialize ();
}

void
DescriptorSchmidScale::write (std::ostream & stream)
{
  stream << typeid (*this).name () << endl;
  stream.write ((char *) &sigma, sizeof (sigma));
}


// class DescriptorSchmid -----------------------------------------------------

DescriptorSchmid::DescriptorSchmid (int scaleCount, float scaleStep)
{
  if (scaleStep < 1)
  {
	scaleStep = sqrt (2.0);
  }

  this->scaleStep = scaleStep;

  initialize (scaleCount);
}

DescriptorSchmid::DescriptorSchmid (std::istream & stream)
{
  read (stream);
}

void
DescriptorSchmid::initialize (int scaleCount)
{
  for (int i = 0; i < descriptors.size (); i++)
  {
	delete descriptors[i];
  }
  descriptors.clear ();

  for (int s = 0; s < scaleCount; s++)
  {
    float scale = pow (scaleStep, s);
    DescriptorSchmidScale * d = new DescriptorSchmidScale (scale);
    descriptors.push_back (d);
  }
}

DescriptorSchmid::~DescriptorSchmid ()
{
  for (int i = 0; i < descriptors.size (); i++)
  {
	delete descriptors[i];
  }
}

Vector<float>
DescriptorSchmid::value (const Image & image, const PointInterest & point)
{
  // Use appropriate scaled descriptor
  return findScale (point.scale)->value (image, point);
}

Image
DescriptorSchmid::patch (const Vector<float> & value)
{
  // Pick an entry with nice scale and use it to reconstruct the patch
  return findScale (2.0)->patch (value);
}

DescriptorSchmidScale *
DescriptorSchmid::findScale (float sigma)
{
  // Just a linear search.  Could be a binary search, but for a list this small
  // it doesn't make much difference
  DescriptorSchmidScale * result = NULL;
  float smallestDistance = 1e30;
  for (int i = 0; i < descriptors.size (); i++)
  {
	float distance = fabs (descriptors[i]->sigma - sigma);
	if (distance < smallestDistance)
	{
	  result = descriptors[i];
	  smallestDistance = distance;
	}
  }

  return result;
}

void
DescriptorSchmid::read (std::istream & stream)
{
  int scaleCount;
  stream.read ((char *) &scaleCount, sizeof (scaleCount));
  stream.read ((char *) &scaleStep, sizeof (scaleStep));

  initialize (scaleCount);
}

void
DescriptorSchmid::write (std::ostream & stream)
{
  stream << typeid (*this).name () << endl;

  int scaleCount = descriptors.size ();
  stream.write ((char *) &scaleCount, sizeof (scaleCount));
  stream.write ((char *) &scaleStep, sizeof (scaleStep));
}


// class DescriptorSpin -------------------------------------------------------

static const float hsqrt2 = sqrt (2.0) / 2.0;  // "half square root of 2".  Used by several InterestSpin... classes

DescriptorSpin::DescriptorSpin (int binsRadial, int binsIntensity, float supportRadial, float supportIntensity)
{
  this->binsRadial       = binsRadial;
  this->binsIntensity    = binsIntensity;
  this->supportRadial    = supportRadial;
  this->supportIntensity = supportIntensity;
}

DescriptorSpin::DescriptorSpin (std::istream & stream)
{
  read (stream);
}

Vector<float>
DescriptorSpin::value (const Image & image, const PointInterest & point)
{
double startTime = getTimestamp ();

  // Determine various sizes
  float width = supportRadial * point.scale;
  float binRadius = width / binsRadial;
  int x1 = (int) rint (point.x - width);
  int x2 = (int) rint (point.x + width);
  int y1 = (int) rint (point.y - width);
  int y2 = (int) rint (point.y + width);
  x1 = max (x1, 0);
  x2 = min (x2, image.width - 1);
  y1 = max (y1, 0);
  y2 = min (y2, image.height - 1);

  // Determine intensity bin values
  width += hsqrt2;
  float minIntensity;
  float quantum;
  rangeMeanDeviation (image, point, x1, y1, x2, y2, width, minIntensity, quantum);

  // Bin up all the pixels
  Vector<float> result;
  doBinning (image, point, x1, y1, x2, y2, width, minIntensity, quantum, binRadius, result);

  // Convert to probabilities
cerr << "time = " << getTimestamp () - startTime << endl;
cerr << binRadius << endl;
float sum = 0;
  for (int r = 0; r < binsRadial; r++)
  {
	float total = 0;
	for (int d = 0; d < binsIntensity; d++)
	{
	  total += result[r * binsIntensity + d];
	}
sum += total;
cerr << r << "\t" << pow ((r + 1) * binRadius, 2) * PI << "\t" << total << "\t" << sum << endl;
	if (total > 0)
	{
	  for (int d = 0; d < binsIntensity; d++)
	  {
		result[r * binsIntensity + d] /= total;
	  }
	}
  }
cerr << endl;

  return result;
}

Image
DescriptorSpin::patch (const Vector<float> & value)
{
  ImageOf<float> result (binsRadial, binsIntensity, GrayFloat);

  for (int r = 0; r < binsRadial; r++)
  {
	for (int d = 0; d < binsIntensity; d++)
	{
	  result (r, d) = 1.0 - value[(r * binsIntensity) + (binsIntensity - d - 1)];
	}
  }

  return result;
}

void
DescriptorSpin::read (std::istream & stream)
{
  stream.read ((char *) &binsRadial,       sizeof (binsRadial));
  stream.read ((char *) &binsIntensity,    sizeof (binsIntensity));
  stream.read ((char *) &supportRadial,    sizeof (supportRadial));
  stream.read ((char *) &supportIntensity, sizeof (supportIntensity));
}

void
DescriptorSpin::write (std::ostream & stream)
{
  stream << typeid (*this).name () << endl;

  stream.write ((char *) &binsRadial,       sizeof (binsRadial));
  stream.write ((char *) &binsIntensity,    sizeof (binsIntensity));
  stream.write ((char *) &supportRadial,    sizeof (supportRadial));
  stream.write ((char *) &supportIntensity, sizeof (supportIntensity));
}

void
DescriptorSpin::rangeMinMax (const Image & image, const PointInterest & point, int x1, int y1, int x2, int y2, float width, float & minIntensity, float & quantum)
{
  ImageOf<float> that (image);
  minIntensity = 1;
  float maxIntensity = -1;
  for (int x = x1; x <= x2; x++)
  {
	float dx = x - point.x;
	for (int y = y1; y <= y2; y++)
	{
	  float dy = y - point.y;
	  float radius = sqrt (dx * dx + dy * dy);
	  if (radius < width)
	  {
		minIntensity = (minIntensity < that (x, y)) ? minIntensity : that (x, y);	//KenFix
		maxIntensity = (maxIntensity > that (x, y)) ? maxIntensity : that (x, y);	//KenFix
	  }
	}
  }
  float range = maxIntensity - minIntensity;
  if (range == 0)  // In case the image is completely flat
  {
	range = 1;
  }
  quantum = range / binsIntensity;
cerr << "Using min-max: " << minIntensity << " " << quantum << endl;
}

void
DescriptorSpin::rangeMeanDeviation (const Image & image, const PointInterest & point, int x1, int y1, int x2, int y2, float width, float & minIntensity, float & quantum)
{
  int x = 0;	//KenFix

  ImageOf<float> that (image);
  float average = 0;
  float count = 0;
  for (x = x1; x <= x2; x++)
  {
	float dx = x - point.x;
	for (int y = y1; y <= y2; y++)
	{
	  float dy = y - point.y;
	  float radius = sqrt (dx * dx + dy * dy);
	  if (radius < width)
	  {
		float weight = 1.0 - radius / width;
		average += that (x, y) * weight;
		count += weight;
	  }
	}
  }
  average /= count;
  float deviation = 0;
  for (x = x1; x <= x2; x++)
  {
	float dx = x - point.x;
	for (int y = y1; y <= y2; y++)
	{
	  float dy = y - point.y;
	  float radius = sqrt (dx * dx + dy * dy);
	  if (radius < width)
	  {
		float d = that (x, y) - average;
		float weight = 1.0 - radius / width;
		deviation += d * d * weight;
	  }
	}
  }
  deviation = sqrt (deviation / count);
  float range = 2.0 * supportIntensity * deviation;
  if (range == 0)  // In case the image is completely flat
  {
	range = 1.0;
  }

  quantum = range / binsIntensity;
  minIntensity = average - range / 2;
cerr << "Using average: " << minIntensity << " " << quantum << endl;
}

// WARNING!!! -- This function does not work right under any level of
// optimization unless "-ffloat-store" is also specified.  It seems that
// superfluous precision causes some ratios a / b == 1 to actually be
// slightly larger than 1, causing asin () to return a nan.
void
DescriptorSpin::doBinning (const Image & image, const PointInterest & point, int x1, int y1, int x2, int y2, float width, float minIntensity, float quantum, float binRadius, Vector<float> & result)
{
  ImageOf<float> that (image);
  result.resize (binsRadial * binsIntensity);
  result.clear ();

  for (int x = x1; x <= x2; x++)
  {
	float dx = x - point.x;
	float left  = dx - 0.5;  // Positions of edges of current pixel
	float right = dx + 0.5;
	float signLeft = left >= 0 ? 1.0 : -1.0;
	float signRight = right > 0 ? 1.0 : -1.0;
	float left2 = left * left;
	float right2 = right * right;

	for (int y = y1; y <= y2; y++)
	{
	  float dy = y - point.y;
	  float radius = sqrt (dx * dx + dy * dy);
	  if (radius < width)
	  {
		int d = (int) ((that (x, y) - minIntensity) / quantum);
		d = (d > 0) ? d : 0;	//KenFix
		d = (d < binsIntensity - 1) ? d : binsIntensity - 1;	//KenFix

		float modRadius = fmod (radius, binRadius);
		if (modRadius > hsqrt2  &&  modRadius < binRadius - hsqrt2)
		{
		  int r = (int) (radius / binRadius);
		  result[r * binsIntensity + d] += 1.0;
		  continue;
		}

		float top    = dy - 0.5;
		float bottom = dy + 0.5;
		int r = (int) ((radius - hsqrt2) / binRadius);
		r = (r > 0) ? r : 0;	//KenFix
		float remaining = 1.0;  // Amount of current pixel not yet allocated
		for (; r < binsRadial  &&  remaining > 1e-6; r++)
		{
		  float area = 0;
		  float r1 = (r + 1) * binRadius;
		  float r2 = r1 * r1;

		  // Subtract area between curve and left edge of pixel
		  float w = r2 - left2;
		  if (w > 0)
		  {
			w = sqrt (w);
			float a = (top > -w) ? top : -w;		//KenFix
			float b = (bottom < w) ? bottom : w;	//KenFix
			if (a < b)
			{
				//KenFix
				area +=   (  ((b / 2) * sqrt (r2 - b * ((b > 0) ? b : 0)) + (r2 / 2) * asin (b / r1))
					     - ((a / 2) * sqrt (r2 - a * ((a > 0) ? a : 0)) + (r2 / 2) * asin (a / r1)))
				      * signLeft
				      - left * (b - a);
			}
		  }

		  // Add area between curve and right edge of pixel
		  w = r2 - right2;
		  if (w > 0)
		  {
			w = sqrt (w);
			float a = (top > -w) ? top : -w;		//KenFix
			float b = (bottom < w) ? bottom : w;	//KenFix
			if (a < b)
			{
			  //KenFix
			  area -=   (  ((b / 2) * sqrt (r2 - b * ((b > 0) ? b : 0)) + (r2 / 2) * asin (b / r1))
						 - ((a / 2) * sqrt (r2 - a * ((a > 0) ? a : 0)) + (r2 / 2) * asin (a / r1)))
				      * signRight
				      - right * (b - a);
			}
		  }

		  // If necessary, add area between curve and center line
		  if (left < 0  &&  right > 0)
		  {
			float a = (top > -r1) ? top : -r1;		//KenFix
			float b = (bottom < r1) ? bottom : r1;	//KenFix
			if (a < b)
			{
			  //KenFix
			  area +=   (  ((b / 2) * sqrt (r2 - b * ((b > 0) ? b : 0)) + (r2 / 2) * asin (b / r1))
					     - ((a / 2) * sqrt (r2 - a * ((a > 0) ? a : 0)) + (r2 / 2) * asin (a / r1)))
				      * 2.0;
			}
		  }

		  result[r * binsIntensity + d] += area - (1.0 - remaining);
		  remaining = 1.0 - area;
		}
	  }
	}
  }
}


// class DescriptorSpinSimple -------------------------------------------------

DescriptorSpinSimple::DescriptorSpinSimple (int binsRadial, int binsIntensity, float supportRadial, float supportIntensity)
{
  this->binsRadial       = binsRadial;
  this->binsIntensity    = binsIntensity;
  this->supportRadial    = supportRadial;
  this->supportIntensity = supportIntensity;
}

void
DescriptorSpinSimple::rangeMinMax (const Image & image, const PointInterest & point, int x1, int y1, int x2, int y2, float width, float & minIntensity, float & quantum)
{
  DescriptorSpin::rangeMinMax (image, point, x1, y1, x2, y2, width - hsqrt2, minIntensity, quantum);
}

void
DescriptorSpinSimple::rangeMeanDeviation (const Image & image, const PointInterest & point, int x1, int y1, int x2, int y2, float width, float & minIntensity, float & quantum)
{
  DescriptorSpin::rangeMeanDeviation (image, point, x1, y1, x2, y2, width - hsqrt2, minIntensity, quantum);
}

void
DescriptorSpinSimple::doBinning (const Image & image, const PointInterest & point, int x1, int y1, int x2, int y2, float width, float minIntensity, float quantum, float binRadius, Vector<float> & result)
{
  width -= hsqrt2;

  ImageOf<float> that (image);
  result.resize (binsRadial * binsIntensity);
  result.clear ();

  for (int x = x1; x <= x2; x++)
  {
	float dx = x - point.x;
	for (int y = y1; y <= y2; y++)
	{
	  float dy = y - point.y;
	  float radius = sqrt (dx * dx + dy * dy);
	  if (radius < width)
	  {
		int d = (int) ((that (x, y) - minIntensity) / quantum);
		d = (d > 0) ? d : 0;	//KenFix
		d = (d < binsIntensity - 1) ? d : binsIntensity - 1;	//KenFix

		int r = (int) (radius / binRadius);

		result[r * binsIntensity + d] += 1.0;
	  }
	}
  }
}


// class DescriptorSpinExact --------------------------------------------------
//KenFix
DescriptorSpinExact::DescriptorSpinExact (int binsRadial, int binsIntensity, float supportRadial, float supportIntensity)
{
  this->binsRadial       = binsRadial;
  this->binsIntensity    = binsIntensity;
  this->supportRadial    = supportRadial;
  this->supportIntensity = supportIntensity;
}

class PointZ : public Point
{
public:
  PointZ () {}
  PointZ (float x, float y, float z) : Point (x, y) {this->z = z;}
  float z;
};

typedef vector<PointZ> Polygon;

inline ostream &
operator << (ostream & stream, const PointZ & p)
{
  stream << "(" << p.x << " " << p.y << " " << p.z << ")";
  return stream;
}

inline ostream &
operator << (ostream & stream, const Polygon & p)
{
  for (int i = 0; i < p.size (); i++)
  {
	cerr << p[i];
  }
  return stream;
}

inline void
chopIntensity (Polygon & p, vector<Polygon> & polygons, const float minIntensity, const float quantum, const int lastBin)
{
  // Sort points by intensity
  bool clockwise = false;
  if (p[0].z > p[1].z)
  {
	clockwise = ! clockwise;
	PointZ temp = p[0];
	p[0] = p[1];
	p[1] = temp;
  }
  if (p[1].z > p[2].z)
  {
	clockwise = ! clockwise;
	PointZ temp = p[1];
	p[1] = p[2];
	p[2] = temp;
  }
  if (p[0].z > p[1].z)
  {
	clockwise = ! clockwise;
	PointZ temp = p[0];
	p[0] = p[1];
	p[1] = temp;
  }

  float dx2 = p[2].x - p[0].x;
  float dx1 = p[1].x - p[0].x;

  float dy2 = p[2].y - p[0].y;
  float dy1 = p[1].y - p[0].y;

  float dz2 = p[2].z - p[0].z;
  float dz1 = p[1].z - p[0].z;

  PointZ b = p[0];  // Base along the path with two segments.

  Polygon q;
  q.push_back (p[0]);
  PointZ n1;
  PointZ n2;
  int d = (int) ((p[0].z - minIntensity) / quantum);
  d = (d > 0) ? d : 0;				//KenFix
  d = (d < lastBin) ? d : lastBin;	//KenFix
  float z = d * quantum + minIntensity;
  bool passedMiddle = false;
  while (true)
  {
	z += quantum;
	if (d >= lastBin)
	{
	  z = 1e38;  // Extremely high altitude, to ensure all values fall below it.
	}

	float t1 = dz1 == 0 ? 1.0 : (z - b.z) / dz1;
	if (t1 < 0.9999)  // Read "t1 < 1.0".  Just allowing a little numerical slack here.
	{
	  n1.x = dx1 * t1 + b.x;
	  n1.y = dy1 * t1 + b.y;
	}
	else if (! passedMiddle)
	{
	  passedMiddle = true;
	  dx1 = p[2].x - p[1].x;
	  dy1 = p[2].y - p[1].y;
	  dz1 = p[2].z - p[1].z;
	  b = p[1];
	  t1 = dz1 == 0 ? 1.0 : (z - b.z) / dz1;
	  if (t1 < 0.0001)  // Read "t1 == 0"
	  {
		n1 = p[1];
	  }
	  else
	  {
		if (clockwise)
		{
		  q.insert (q.begin (), p[1]);
		}
		else
		{
		  q.push_back (p[1]);
		}
		n1.x = dx1 * t1 + b.x;
		n1.y = dy1 * t1 + b.y;
	  }
	}

	float t2 = dz2 == 0 ? 1.0 : (z - p[0].z) / dz2;
	if (t2 < 0.9999)
	{
	  n2.x = dx2 * t2 + p[0].x;
	  n2.y = dy2 * t2 + p[0].y;
	}
	else
	{
	  q.push_back (p[2]);
	  q[0].z = d;
	  polygons.push_back (q);
	  return;
	}

	if (clockwise)
	{
	  q.push_back (n2);
	  q.push_back (n1);
	  q[0].z = d;
	  polygons.push_back (q);
	  q.clear ();
	  q.push_back (n1);
	  q.push_back (n2);
	}
	else
	{
	  q.push_back (n1);
	  q.push_back (n2);
	  q[0].z = d;
	  polygons.push_back (q);
	  q.clear ();
	  q.push_back (n2);
	  q.push_back (n1);
	}

	d++;
  }
}

inline float
length (const Point & a, const Point & b)
{
  float dx = a.x - b.x;
  float dy = a.y - b.y;
  return sqrt (dx * dx + dy * dy);
}

inline float
areaTriangle (const Point & p0, const Point & p1, const Point & p2)
{
  float a = length (p0, p1);
  float b = length (p1, p2);
  float c = length (p2, p0);
  float s = (a + b + c) / 2.0;

  //KenFix
  float tmp = s * (s - a) * (s - b) * (s - c);
  if(tmp < 0) tmp = 0;
  return sqrt (tmp);	// Heron's formula
}

inline float
areaArc (const Point & p, const Point & q, const Point & center, float radius)
{
  float a1 = atan2 (p.y - center.y, p.x - center.x);
  float a2 = atan2 (q.y - center.y, q.x - center.x);
  float da = fabs (a1 - a2);
  if (da > PI)
  {
	da = 2 * PI - da;
  }
  return radius * radius * da / 2.0;
}

inline float
areaEdge (const Point & p, const Point & q, const Point & center, float radius)
{
  // Find orientation of (p, q, center)
  float d1 = (p.x - center.x) * (q.y - center.y);
  float d2 = (p.y - center.y) * (q.x - center.x);
  float sign;
  if (d1 == d2)
  {
	sign = 0;
  }
  else
  {
	sign = d1 > d2 ? +1 : -1;
  }

  // Find intersections with circle
  // Solve for roots of t in ||(q - p) t + p - center|| = radius
  float xd = q.x - p.x;
  float yd = q.y - p.y;
  float xe = p.x - center.x;
  float ye = p.y - center.y;
  float a = xd * xd + yd * yd;
  float b = 2 * (xd * xe + yd * ye);
  float c = xe * xe + ye * ye - radius * radius;
  float b4ac = b * b - 4 * a * c;
  if (b4ac <= 0)
  {
	// Line supporting edge either intersects circle at exactly one point,
	// or does not intersect circle at all.  This means the edge is entirely
	// outside circle.
	return sign * areaArc (p, q, center, radius);
  }
  b4ac = sqrt (b4ac);
  float t1 = (-b - b4ac) / (2 * a);
  float t2 = (-b + b4ac) / (2 * a);

  // Determine area under each portion of segment
  if (t1 <= 0)
  {
	if (t2 <= 0)
	{
	  // Edge is entirely outside circle
	  return sign * areaArc (p, q, center, radius);
	}
	else if (t2 >= 1)
	{
	  // Edge is entirely inside circle
	  return sign * areaTriangle (p, q, center);
	}
	else  // t2 in (0, 1)
	{
	  // p is inside and q is outside
	  Point c2 (xd * t2 + p.x, yd * t2 + p.y);
	  return   sign
		     * (  areaTriangle (p, c2, center)
				+ areaArc (c2, q, center, radius));
	}
  }
  else if (t1 >= 1)
  {
	// Edge is entirely outside circle
	return sign * areaArc (p, q, center, radius);
  }
  else  // t1 in (0, 1)
  {
	Point c1 (xd * t1 + p.x, yd * t1 + p.y);
	if (t2 >= 1)
	{
	  // p is outside and q is inside
	  return   sign
		     * (  areaArc (p, c1, center, radius)
				+ areaTriangle (c1, q, center));
	}
	else  // t2 in (t1, 1)
	{
	  // p and q are both outside
	  Point c2 (xd * t2 + p.x, yd * t2 + p.y);
	  return   sign
		     * (  areaArc (p, c1, center, radius)
				+ areaTriangle (c1, c2, center)
				+ areaArc (c2, q, center, radius));
	}
  }
}

void
DescriptorSpinExact::doBinning (const Image & image, const PointInterest & point, int x1, int y1, int x2, int y2, float width, float minIntensity, float quantum, float binRadius, Vector<float> & result)
{
  // Extend area of coverage to ensure all intensity patches are considered.
  x1 = (0 > x1 - 1) ? 0 : x1 - 1;						//KenFix
  y1 = (0 > y1 - 1) ? 0 : y1 - 1;						//KenFix
  x2 = (x2 < image.width - 2) ? x2 : image.width - 2;	//KenFix
  y2 = (y2 < image.height - 2) ? y2 : image.height - 2;	//KenFix

  // Since the upper left pixel center represents the entire group of four
  // pixel centers which define an intensity patch, there is an asymmetry
  // in how pixels should be evaluated for inclusion in the support for the
  // spin image.  The correct compensation for this asymmetry is to shift
  // the center up and left by half a pixel.  This is the same as shifting
  // the upper left pixel position into the center of the intensity patch.
  float scx = point.x - 0.5;  // "shift center x"
  float scy = point.y - 0.5;  // "shift center y"

  ImageOf<float> that (image);
  result.resize (binsRadial * binsIntensity);
  result.clear ();

  for (int x = x1; x <= x2; x++)
  {
	float dx = x - scx;
	for (int y = y1; y <= y2; y++)
	{
	  float dy = y - scy;
	  float radius = sqrt (dx * dx + dy * dy);
	  if (radius < width)
	  {
		// Chop pixel into two triangles, then chop each triangle up
		// according to intensity level.  Each piece must have an associated
		// intensity bin.
		vector<Polygon> polygons;
		//polygons.reserve (2 * binsIntensity);  // Doesn't seem to improve performance.
		Polygon polygon;
		//polygon.reserve (3);
		PointZ p1 (x,     y,     that (x,     y));
		PointZ p2 (x + 1, y,     that (x + 1, y));
		PointZ p3 (x,     y + 1, that (x,     y + 1));
		PointZ p4 (x + 1, y + 1, that (x + 1, y + 1));
		polygon.push_back (p1);
		polygon.push_back (p2);
		polygon.push_back (p3);
		chopIntensity (polygon, polygons, minIntensity, quantum, binsIntensity - 1);
		polygon.clear ();
		polygon.push_back (p3);
		polygon.push_back (p2);
		polygon.push_back (p4);
		chopIntensity (polygon, polygons, minIntensity, quantum, binsIntensity - 1);

		// Chop pieces into triangles.
		vector<Polygon> triangles;
		triangles.reserve (polygons.size () * 2);  // Does in fact improve performance
		for (int i = 0; i < polygons.size (); i++)
		{
		  Polygon & p = polygons[i];
		  for (int j = 2; j < p.size (); j++)
		  {
			Polygon q;
			q.push_back (p[0]);
			q.push_back (p[j - 1]);
			q.push_back (p[j]);
			triangles.push_back (q);
		  }
		}

		// Process each triangular piece, assigning portion of area to
		// appropriate radial bin
		vector<Polygon>::iterator t;
		for (t = triangles.begin (); t < triangles.end (); t++)
		{
		  int r = (int) ((radius - hsqrt2) / binRadius);
		  r = (r > 0) ? r : 0;	//KenFix
		  int d = (int) (*t)[0].z;
		  float total = areaTriangle ((*t)[0], (*t)[1], (*t)[2]);
		  float consumed = 0;
		  for (; r < binsRadial  &&  (total - consumed) > 1e-6; r++)
		  {
			// Find area under each edge
			float radius = (r + 1) * binRadius;  // Changes meaning of radius in this scope
			float area = 0;
			area += areaEdge ((*t)[0], (*t)[1], point, radius);
			area += areaEdge ((*t)[1], (*t)[2], point, radius);
			area += areaEdge ((*t)[2], (*t)[0], point, radius);

			result[r * binsIntensity + d] += area - consumed;
			consumed = area;
		  }
		}
	  }
	}
  }
}
