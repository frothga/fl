#ifndef interest_h
#define interest_h


#include "convolve.h"
#include "matrix.h"
#include <vector>	//KenFix

#include <set>


namespace my
{
  // General interest operator interface ----------------------------------------

  class InterestOperator
  {
  public:
	virtual void run (const Image & image, std::multiset<PointInterest> & result) = 0;
  };


  // Specific interest operators ------------------------------------------------

  class InterestHarris : public InterestOperator
  {
  public:
	InterestHarris (int neighborhood = 5, int maxPoints = 300, float thresholdFactor = 0.02);

	void run (const Image & image, std::multiset<PointInterest> & result);

	NonMaxSuppress nms;
	FilterHarris filter;
	int maxPoints;  // Max number of interest points allowable
	float thresholdFactor;  // Percent of max interest response level at which to cut off interest points.
  };

  class InterestHarrisLaplacian : public InterestOperator
  {
  public:
	InterestHarrisLaplacian (int maxPoints = 300, float thresholdFactor = 0.02, int neighborhood = 5, int firstStep = 0, int lastStep = 7, float stepSize = -1);

	void run (const Image & image, std::multiset<PointInterest> & result);

	NonMaxSuppress nms;
	std::vector<float> scales;
	std::vector<FilterHarris> filters;
	std::vector<Laplacian> laplacians;
	int neighborhood;
	int maxPoints;
	float thresholdFactor;
  };
}


#endif
