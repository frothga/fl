//Note: also look for KenFix comments
#ifndef VCFIX_H_
#define VCFIX_H

#include<float.h>

#define INFINITY FLT_MAX

#define bzero(a,b) memset(a,0,b)
#define rint(a) (int)(a+0.5)
#define isnan(x) ((x) != (x))
#define isinf(x) ((x) == FLT_MAX * 2)

/*
#undef min
#undef max
#define max(a,b)  (a)>(b)? (a) : (b)
#define min(a,b)  (a)<(b)? (a) : (b)
*/

#pragma warning(disable : 4056)
#pragma warning(disable : 4172)
#pragma warning(disable : 4244)
#pragma warning(disable : 4305)
#pragma warning(disable : 4541)
#pragma warning(disable : 4554)
#pragma warning(disable : 4661)
#pragma warning(disable : 4756)
#pragma warning(disable : 4786)
#pragma warning(disable : 4800)


#endif