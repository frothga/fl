#include "../prompt.h"
#include "VCFix.h"
#include "image.h"


#include <math.h>
#include <string>

using std::string;

// Include for tracing
//#include <iostream>


using namespace std;
using namespace my;


PixelFormatGrayChar   my::GrayChar;
PixelFormatGrayFloat  my::GrayFloat;
PixelFormatGrayDouble my::GrayDouble;
PixelFormatRGBChar    my::RGBChar;


// class PixelFormat ----------------------------------------------------------

Image
PixelFormat::filter (const Image & image)
{
  Image result (*this);
  result.width     = image.width;
  result.height    = image.height;
  result.timestamp = image.timestamp;

  /*
  if (typeid (* image.format) == typeid (PixelFormatGrayChar))
  {
	this->fromGrayChar (image, result);
  }
  else if (typeid (* image.format) == typeid (PixelFormatGrayFloat))
  {
	this->fromGrayFloat (image, result);
  }
  else if (typeid (* image.format) == typeid (PixelFormatGrayDouble))
  {
	this->fromGrayDouble (image, result);
  }
  else if (typeid (* image.format) == typeid (PixelFormatRGBChar))
  {
	this->fromRGBChar (image, result);
  }
  else if (typeid (* image.format) == typeid (PixelFormatRGBBits))
  {
	this->fromRGBBits (image, result);
  }
  else
  {
	throw "Unrecognized format";
  }
  */

  //KenFix
  if ((* image.format).typepf == GrayChar.typepf)
  {
	this->fromGrayChar (image, result);
  }
  else if ((* image.format).typepf == GrayFloat.typepf)
  {
	this->fromGrayFloat (image, result);
  }
  else if ((* image.format).typepf == GrayDouble.typepf)
  {
	this->fromGrayDouble (image, result);
  }
  else if ((* image.format).typepf == RGBChar.typepf)
  {
	this->fromRGBChar (image, result);
  }
  else if ((* image.format).typepf == "RGBBits")
  {
	this->fromRGBBits (image, result);
  }
  else
  {
	throw "Unrecognized format";
  }


  return result;
}

bool
PixelFormat::operator == (const PixelFormat & that) const
{
  //return typeid (*this) == typeid (that);	
  return (typepf == that.typepf);		//KenFix
}


// class PixelFormatGrayChar --------------------------------------------------

PixelFormatGrayChar::PixelFormatGrayChar ()
{
  depth = 1;
  precedence = 0;
  typepf = "GrayChar";
}

void
PixelFormatGrayChar::fromGrayChar (const Image & image, Image & result) const
{
  result.buffer = image.buffer;
}

void
PixelFormatGrayChar::fromGrayFloat (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  float scale;
  float bias;
  PixelFormatGrayFloat::range (image, scale, bias);

  float * fromPixel = (float *) image.buffer;
  unsigned char * toPixel = (unsigned char *) result.buffer;
  unsigned char * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	//KenFix
	unsigned char tmp = *fromPixel++ * scale + bias;
	if(tmp < 0) tmp = 0;
	if(tmp > 255) tmp = 255;
	*toPixel++ = tmp;
  }
}

void
PixelFormatGrayChar::fromGrayDouble (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  double scale;
  double bias;
  PixelFormatGrayDouble::range (image, scale, bias);

  double * fromPixel = (double *) image.buffer;
  unsigned char * toPixel = (unsigned char *) result.buffer;
  unsigned char * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	//KenFix
	unsigned char tmp = *fromPixel++ * scale + bias;
	if(tmp < 0) tmp = 0;
	if(tmp > 255) tmp = 255;
	*toPixel++ = tmp;
  }
}

void
PixelFormatGrayChar::fromRGBChar (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  unsigned int * fromPixel = (unsigned int *) image.buffer;
  unsigned char * toPixel  = (unsigned char *) result.buffer;
  unsigned char * end      = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	unsigned int r = *fromPixel & 0xFF0000;
	unsigned int g = *fromPixel & 0xFF00;
	unsigned int b = *fromPixel & 0xFF;
	fromPixel++;
	*toPixel++ = (((r >> 8) + g + (b << 8)) / 3) >> 8;
  }
}

void
PixelFormatGrayChar::fromRGBBits (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  PixelFormatRGBBits * that = (PixelFormatRGBBits *) image.format;

  int redShift;
  int greenShift;
  int blueShift;
  that->shift (0xFFFF, 0xFFFF, 0xFFFF, redShift, greenShift, blueShift);

  #define RGBBits2GrayChar(imageSize) \
  { \
    unsigned imageSize * fromPixel = (unsigned imageSize *) image.buffer; \
    unsigned char * toPixel        = (unsigned char *)      result.buffer; \
    unsigned char * end            = toPixel + result.width * result.height; \
    while (toPixel < end) \
    { \
      unsigned int r = *fromPixel & that->redMask; \
  	  unsigned int g = *fromPixel & that->greenMask; \
	  unsigned int b = *fromPixel & that->blueMask; \
      fromPixel++; \
	  *toPixel++ = ((  (redShift   > 0 ? r << redShift   : r >> -redShift) \
	                 + (greenShift > 0 ? g << greenShift : g >> -greenShift) \
	                 + (blueShift  > 0 ? b << blueShift  : b >> -blueShift) \
	                ) / 3 \
			       ) >> 8; \
    } \
  }

  switch (that->depth)
  {
    case 1:
	  RGBBits2GrayChar (char);
	  break;
    case 2:
	  RGBBits2GrayChar (short);
	  break;
    case 4:
    default:
	  RGBBits2GrayChar (int);
  }
}

unsigned int
PixelFormatGrayChar::getRGB (void * pixel) const
{
  unsigned int t = *((unsigned char *) pixel);
  return (t << 16) | (t << 8) | t;
}

void
PixelFormatGrayChar::setRGB (void * pixel, unsigned int rgb) const
{
  unsigned int r = rgb & 0xFF0000;
  unsigned int g = rgb &   0xFF00;
  unsigned int b = rgb &     0xFF;

  *((unsigned char *) pixel) = (((r >> 8) + g + (b << 8)) / 3) >> 8;
}


// class PixelFormatGrayFloat -------------------------------------------------

PixelFormatGrayFloat::PixelFormatGrayFloat ()
{
  depth = 4;
  precedence = 2;
  typepf = "GrayFloat";
}

void
PixelFormatGrayFloat::fromGrayChar (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  unsigned char * fromPixel = (unsigned char *) image.buffer;
  float * toPixel = (float *) result.buffer;
  float * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	*toPixel++ = (float) *fromPixel++ / 255.0;
  }
}

void
PixelFormatGrayFloat::fromGrayFloat (const Image & image, Image & result) const
{
  result.buffer = image.buffer;
}

void
PixelFormatGrayFloat::fromGrayDouble (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  double * fromPixel = (double *) image.buffer;
  float * toPixel = (float *) result.buffer;
  float * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	*toPixel++ = *fromPixel++;
  }
}

void
PixelFormatGrayFloat::fromRGBChar (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  unsigned int * fromPixel = (unsigned int *) image.buffer;
  float *        toPixel   = (float *)        result.buffer;
  float *        end       = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	unsigned int r = *fromPixel & 0xFF0000;
	unsigned int g = *fromPixel & 0xFF00;
	unsigned int b = *fromPixel & 0xFF;
    fromPixel++;
	*toPixel++ = (float) ((r >> 8) + g + (b << 8)) / ((3 << 8) * 255);
  }
}

void
PixelFormatGrayFloat::fromRGBBits (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  PixelFormatRGBBits * that = (PixelFormatRGBBits *) image.format;

  int redShift;
  int greenShift;
  int blueShift;
  that->shift (0xFFFF, 0xFFFF, 0xFFFF, redShift, greenShift, blueShift);

  #define RGBBits2GrayFloat(imageSize) \
  { \
    unsigned imageSize * fromPixel = (unsigned imageSize *) image.buffer; \
    float *              toPixel   = (float *)              result.buffer; \
    float *              end       = toPixel + result.width * result.height; \
	while (toPixel < end) \
    { \
	  unsigned int r = *fromPixel & that->redMask; \
	  unsigned int g = *fromPixel & that->greenMask; \
	  unsigned int b = *fromPixel & that->blueMask; \
      fromPixel++; \
	  *toPixel++ = (float) (  (redShift   > 0 ? r << redShift   : r >> -redShift) \
	                        + (greenShift > 0 ? g << greenShift : g >> -greenShift) \
	                        + (blueShift  > 0 ? b << blueShift  : b >> -blueShift)) \
                   / ((3 << 8) * 255); \
	} \
  }

  switch (that->depth)
  {
    case 1:
	  RGBBits2GrayFloat (char);
	  break;
    case 2:
	  RGBBits2GrayFloat (short);
	  break;
    case 4:
    default:
	  RGBBits2GrayFloat (int);
  }
}

unsigned int
PixelFormatGrayFloat::getRGB (void * pixel) const
{
  int t = (int) (*((float *) pixel) * 127 + 128);  // Need real bias and scale
  unsigned int r = (t << 16) & 0xFF0000;
  unsigned int g = (t << 8)  & 0xFF00;
  unsigned int b =  t        & 0xFF;
  return r | g | b;
}

void
PixelFormatGrayFloat::setRGB (void * pixel, unsigned int rgb) const
{
  unsigned int r = rgb & 0xFF0000;
  unsigned int g = rgb &   0xFF00;
  unsigned int b = rgb &     0xFF;

  *((float *) pixel) = ((float) (r >> 16 + g >> 8 + b) / 3) / 255;  // Need real bias and scale
}

void
PixelFormatGrayFloat::range (const Image & image, float & scale, float & bias)
{
  float lo = INFINITY;
  float hi = -INFINITY;
  float * pixel = (float *) image.buffer;
  float * end = pixel + (image.width * image.height);
  do
  {
	lo = (lo < *pixel) ? lo : *pixel;	//KenFix
	hi = (hi > *pixel) ? hi : *pixel;	//KenFix
  }
  while (++pixel < end);

  if (hi <= 1.0)
  {
	if (lo >= 0)
	{
	  scale = 255;
	  bias = 0;
	  return;
	}
	else if (lo >= -1.0)
	{
	  scale = 128;
	  bias = 128;
	  return;
	}
  }
  scale = 255 / (hi - lo);
  bias = -lo * scale;
}


// class PixelFormatGrayDouble ------------------------------------------------

PixelFormatGrayDouble::PixelFormatGrayDouble ()
{
  depth = 8;
  precedence = 3;
  typepf = "GrayDouble";
}

void
PixelFormatGrayDouble::fromGrayChar (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  unsigned char * fromPixel = (unsigned char *) image.buffer;
  double * toPixel = (double *) result.buffer;
  double * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	*toPixel++ = (double) *fromPixel++ / 255.0;  // Need real bias and scale
  }
}

void
PixelFormatGrayDouble::fromGrayFloat (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  float * fromPixel = (float *) image.buffer;
  double * toPixel = (double *) result.buffer;
  double * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	*toPixel++ = *fromPixel++;
  }
}

void
PixelFormatGrayDouble::fromGrayDouble (const Image & image, Image & result) const
{
  result.buffer = image.buffer;
}

void
PixelFormatGrayDouble::fromRGBChar (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  unsigned int * fromPixel = (unsigned int *) image.buffer;
  double *       toPixel   = (double *)       result.buffer;
  double *       end       = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	unsigned int r = *fromPixel & 0xFF0000;
	unsigned int g = *fromPixel & 0xFF00;
	unsigned int b = *fromPixel & 0xFF;
    fromPixel++;
	*toPixel++ = (double) ((r >> 8) + g + (b << 8)) / ((3 << 8) * 255);
  }
}

void
PixelFormatGrayDouble::fromRGBBits (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  PixelFormatRGBBits * that = (PixelFormatRGBBits *) image.format;

  int redShift;
  int greenShift;
  int blueShift;
  that->shift (0xFFFF, 0xFFFF, 0xFFFF, redShift, greenShift, blueShift);

  #define RGBBits2GrayDouble(imageSize) \
  { \
    unsigned imageSize * fromPixel = (unsigned imageSize *) image.buffer; \
    double *             toPixel   = (double *)             result.buffer; \
    double *             end       = toPixel + result.width * result.height; \
	while (toPixel < end) \
    { \
	  unsigned int r = *fromPixel & that->redMask; \
	  unsigned int g = *fromPixel & that->greenMask; \
	  unsigned int b = *fromPixel & that->blueMask; \
      fromPixel++; \
	  *toPixel++ = (double) (  (redShift   > 0 ? r << redShift   : r >> -redShift) \
	                         + (greenShift > 0 ? g << greenShift : g >> -greenShift) \
	                         + (blueShift  > 0 ? b << blueShift  : b >> -blueShift)) \
                   / ((3 << 8) * 255); \
	} \
  }

  switch (that->depth)
  {
    case 1:
	  RGBBits2GrayDouble (char);
	  break;
    case 2:
	  RGBBits2GrayDouble (short);
	  break;
    case 4:
    default:
	  RGBBits2GrayDouble (int);
  }
}

void
PixelFormatGrayDouble::range (const Image & image, double & scale, double & bias)
{
  double lo = INFINITY;
  double hi = -INFINITY;
  double * pixel = (double *) image.buffer;
  double * end = pixel + (image.width * image.height);
  do
  {
	lo = (lo < *pixel) ? lo : *pixel;		//KenFix
	hi = (hi > *pixel) ? hi : *pixel;		//KenFix
  }
  while (++pixel < end);

  if (hi <= 1.0)
  {
	if (lo >= 0)
	{
	  scale = 255;
	  bias = 0;
	  return;
	}
	else if (lo >= -1.0)
	{
	  scale = 128;
	  bias = 128;
	  return;
	}
  }
  scale = 255 / (hi - lo);
  bias = -lo * scale;
}

unsigned int
PixelFormatGrayDouble::getRGB (void * pixel) const
{
  int t = (int) (*((double *) pixel) * 127 + 128);  // Need real bias and scale
  unsigned int r = (t << 16) & 0xFF0000;
  unsigned int g = (t << 8)  & 0xFF00;
  unsigned int b =  t        & 0xFF;
  return r | g | b;
}

void
PixelFormatGrayDouble::setRGB (void * pixel, unsigned int rgb) const
{
  unsigned int r = rgb & 0xFF0000;
  unsigned int g = rgb &   0xFF00;
  unsigned int b = rgb &     0xFF;

  *((double *) pixel) = ((double) (r >> 16 + g >> 8 + b) / 3) / 255;  // Need real bias and scale here
}


// class PixelFormatRGBChar ---------------------------------------------------

PixelFormatRGBChar::PixelFormatRGBChar ()
{
  depth = 4;
  precedence = 1;
  typepf = "RGBChar";
}

void
PixelFormatRGBChar::fromGrayChar (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  unsigned char * fromPixel = (unsigned char *) image.buffer;
  unsigned int * toPixel = (unsigned int *) result.buffer;
  unsigned int * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	unsigned int t = *fromPixel++;
	*toPixel++ = (t << 16) | (t << 8) | t;
  }
}

void
PixelFormatRGBChar::fromGrayFloat (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  float scale;
  float bias;
  PixelFormatGrayFloat::range (image, scale, bias);

  float * fromPixel = (float *) image.buffer;
  unsigned int * toPixel = (unsigned int *) result.buffer;
  unsigned int * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	unsigned int t = (unsigned int) (*fromPixel++ * scale + bias);
	*toPixel++ = (t << 16) | (t << 8) | t;
  }
}

void
PixelFormatRGBChar::fromGrayDouble (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  double scale;
  double bias;
  PixelFormatGrayDouble::range (image, scale, bias);

  double * fromPixel = (double *) image.buffer;
  unsigned int * toPixel = (unsigned int *) result.buffer;
  unsigned int * end = toPixel + result.width * result.height;
  while (toPixel < end)
  {
	unsigned int t = (unsigned int) (*fromPixel++ * scale + bias);
	*toPixel++ = (t << 16) | (t << 8) | t;
  }
}

void
PixelFormatRGBChar::fromRGBChar (const Image & image, Image & result) const
{
  result.buffer = image.buffer;
}

#define Bits2Bits(fromSize,toSize,fromRed,fromGreen,fromBlue,toRed,toGreen,toBlue) \
{ \
  unsigned fromSize * fromPixel = (unsigned fromSize *) image.buffer; \
  unsigned toSize *   toPixel   = (unsigned toSize *)   result.buffer; \
  unsigned toSize *   end       = toPixel + result.width * result.height; \
  while (toPixel < end) \
  { \
    unsigned int r = *fromPixel & fromRed; \
	unsigned int g = *fromPixel & fromGreen; \
	unsigned int b = *fromPixel & fromBlue; \
    fromPixel++; \
	*toPixel++ =   ((redShift   > 0 ? r << redShift   : r >> -redShift)   & toRed) \
		         | ((greenShift > 0 ? g << greenShift : g >> -greenShift) & toGreen) \
		         | ((blueShift  > 0 ? b << blueShift  : b >> -blueShift)  & toBlue); \
  } \
}

void
PixelFormatRGBChar::fromRGBBits (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  PixelFormatRGBBits * that = (PixelFormatRGBBits *) image.format;

  int redShift;
  int greenShift;
  int blueShift;
  that->shift (0xFF0000, 0xFF00, 0xFF, redShift, greenShift, blueShift);

  switch (that->depth)
  {
    case 1:
	  Bits2Bits (char, int, that->redMask, that->greenMask, that->blueMask, 0xFF0000, 0xFF00, 0xFF);
	  break;
    case 2:
	  Bits2Bits (short, int, that->redMask, that->greenMask, that->blueMask, 0xFF0000, 0xFF00, 0xFF);
	  break;
    case 4:
    default:
	  Bits2Bits (int, int, that->redMask, that->greenMask, that->blueMask, 0xFF0000, 0xFF00, 0xFF);
  }
}

void
PixelFormatRGBChar::shift (unsigned int redMask, unsigned int greenMask, unsigned int blueMask, int & redShift, int & greenShift, int & blueShift)
{
  redShift = -23;
  while (redMask >>= 1) {redShift++;}

  greenShift = -15;
  while (greenMask >>= 1) {greenShift++;}

  blueShift = -7;
  while (blueMask >>= 1) {blueShift++;}
}

unsigned int
PixelFormatRGBChar::getRGB (void * pixel) const
{
  return *((unsigned int *) pixel);
}

void
PixelFormatRGBChar::setRGB (void * pixel, unsigned int rgb) const
{
  *((unsigned int *) pixel) = rgb;
}


// class PixelFormatRGBBits ---------------------------------------------------

PixelFormatRGBBits::PixelFormatRGBBits (int depth, unsigned int redMask, unsigned int greenMask, unsigned int blueMask)
{
  this->depth     = depth;
  this->redMask   = redMask;
  this->greenMask = greenMask;
  this->blueMask  = blueMask;

  precedence = 1;
  typepf = "RGBBits";
}

void
PixelFormatRGBBits::fromGrayChar (const Image & image, Image & result) const
{
  if (redMask == 0xFF  &&  greenMask == 0xFF  &&  blueMask == 0xFF  &&  depth == 1)
  {
	result.buffer = image.buffer;
	return;
  }

  result.buffer.grow (result.width * result.height * depth);

  int redShift;
  int greenShift;
  int blueShift;
  shift (0xFF, 0xFF, 0xFF, redShift, greenShift, blueShift);
  redShift *= -1;
  greenShift *= -1;
  blueShift *= -1;

  switch (depth)
  {
    case 1:
	  Bits2Bits (char, char, 0xFF, 0xFF, 0xFF, redMask, greenMask, blueMask);
	  break;
    case 2:
	  Bits2Bits (char, short, 0xFF, 0xFF, 0xFF, redMask, greenMask, blueMask);
	  break;
    case 4:
    default:
	  Bits2Bits (char, int, 0xFF, 0xFF, 0xFF, redMask, greenMask, blueMask);
  }
}

void
PixelFormatRGBBits::fromGrayFloat (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  float scale;
  float bias;
  PixelFormatGrayFloat::range (image, scale, bias);
  scale *= 256;
  bias *= 256;

  int redShift;
  int greenShift;
  int blueShift;
  shift (0xFFFF, 0xFFFF, 0xFFFF, redShift, greenShift, blueShift);
  redShift *= -1;
  greenShift *= -1;
  blueShift *= -1;

  #define GrayFloat2Bits(toSize) \
  { \
	float *           fromPixel = (float *)           image.buffer; \
    unsigned toSize * toPixel   = (unsigned toSize *) result.buffer; \
	unsigned toSize * end       = toPixel + result.width * result.height; \
    while (toPixel < end) \
    { \
	  unsigned int t = (unsigned int) (*fromPixel++ * scale + bias); \
	  *toPixel++ =   ((redShift   > 0 ? t << redShift   : t >> -redShift)   & redMask) \
		           | ((greenShift > 0 ? t << greenShift : t >> -greenShift) & greenMask) \
		           | ((blueShift  > 0 ? t << blueShift  : t >> -blueShift)  & blueMask); \
    } \
  }

  switch (depth)
  {
    case 1:
	  GrayFloat2Bits (char);
	  break;
    case 2:
	  GrayFloat2Bits (short);
	  break;
    case 4:
    default:
	  GrayFloat2Bits (int);
  }
}

void
PixelFormatRGBBits::fromGrayDouble (const Image & image, Image & result) const
{
  result.buffer.grow (result.width * result.height * depth);

  double scale;
  double bias;
  PixelFormatGrayDouble::range (image, scale, bias);
  scale *= 256;
  bias *= 256;

  int redShift;
  int greenShift;
  int blueShift;
  shift (0xFFFF, 0xFFFF, 0xFFFF, redShift, greenShift, blueShift);
  redShift *= -1;
  greenShift *= -1;
  blueShift *= -1;

  #define GrayDouble2Bits(toSize) \
  { \
	double *          fromPixel = (double *)          image.buffer; \
    unsigned toSize * toPixel   = (unsigned toSize *) result.buffer; \
	unsigned toSize * end       = toPixel + result.width * result.height; \
    while (toPixel < end) \
    { \
	  unsigned int t = (unsigned int) (*fromPixel++ * scale + bias); \
	  *toPixel++ =   ((redShift   > 0 ? r << redShift   : r >> -redShift)   & redMask) \
		           | ((greenShift > 0 ? g << greenShift : g >> -greenShift) & greenMask) \
		           | ((blueShift  > 0 ? b << blueShift  : b >> -blueShift)  & blueMask); \
    } \
  }

  switch (depth)
  {
    case 1:
	  GrayFloat2Bits (char);
	  break;
    case 2:
	  GrayFloat2Bits (short);
	  break;
    case 4:
    default:
	  GrayFloat2Bits (int);
  }
}

void
PixelFormatRGBBits::fromRGBChar (const Image & image, Image & result) const
{
  if (redMask == 0xFF0000  &&  greenMask == 0xFF00  &&  blueMask == 0xFF  &&  depth == 4)
  {
	result.buffer = image.buffer;
	return;
  }

  result.buffer.grow (result.width * result.height * depth);

  int redShift;
  int greenShift;
  int blueShift;
  PixelFormatRGBChar::shift (redMask, greenMask, blueMask, redShift, greenShift, blueShift);

  switch (depth)
  {
    case 1:
	  Bits2Bits (int, char, 0xFF0000, 0xFF00, 0xFF, redMask, greenMask, blueMask);
	  break;
    case 2:
	  Bits2Bits (int, short, 0xFF0000, 0xFF00, 0xFF, redMask, greenMask, blueMask);
	  break;
    case 4:
    default:
	  Bits2Bits (int, int, 0xFF0000, 0xFF00, 0xFF, redMask, greenMask, blueMask);
  }
}

void
PixelFormatRGBBits::fromRGBBits (const Image & image, Image & result) const
{
  if (*image.format == *this)
  {
	result.buffer = image.buffer;
	return;
  }

  result.buffer.grow (result.width * result.height * depth);

  PixelFormatRGBBits * that = (PixelFormatRGBBits *) image.format;

  int redShift;
  int greenShift;
  int blueShift;
  that->shift (redMask, greenMask, blueMask, redShift, greenShift, blueShift);

  switch (depth)
  {
    case 1:
	  switch (that->depth)
	  {
	    case 1:
		  Bits2Bits (char, char, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
		  break;
	    case 2:
		  Bits2Bits (short, char, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
		  break;
	    case 4:
	    default:
		  Bits2Bits (int, char, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
	  }
	  break;
    case 2:
	  switch (that->depth)
	  {
	    case 1:
		  Bits2Bits (char, short, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
		  break;
	    case 2:
		  Bits2Bits (short, short, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
		  break;
	    case 4:
	    default:
		  Bits2Bits (int, short, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
	  }
	  break;
    case 4:
    default:
	  switch (that->depth)
	  {
	    case 1:
		  Bits2Bits (char, int, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
		  break;
	    case 2:
		  Bits2Bits (short, int, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
		  break;
	    case 4:
	    default:
		  Bits2Bits (int, int, that->redMask, that->greenMask, that->blueMask, redMask, greenMask, blueMask);
	  }
	  break;
  }
}

bool
PixelFormatRGBBits::operator == (const PixelFormat & that) const
{
  if (const PixelFormatRGBBits * other = dynamic_cast<const PixelFormatRGBBits *> (& that))
  {
	return    redMask   == other->redMask
	       && greenMask == other->greenMask
	       && blueMask  == other->blueMask;
  }
  else
  {
	return false;
  }
}

void
PixelFormatRGBBits::shift (unsigned int redMask, unsigned int greenMask, unsigned int blueMask, int & redShift, int & greenShift, int & blueShift) const
{
  unsigned int t;

  redShift = 0;
  while (redMask >>= 1) {redShift++;}
  t = this->redMask;
  while (t >>= 1) {redShift--;}

  greenShift = 0;
  while (greenMask >>= 1) {greenShift++;}
  t = this->greenMask;
  while (t >>= 1) {greenShift--;}

  blueShift = 0;
  while (blueMask >>= 1) {blueShift++;}
  t = this->blueMask;
  while (t >>= 1) {blueShift--;}
}

unsigned int
PixelFormatRGBBits::getRGB (void * pixel) const
{
  int redShift;
  int greenShift;
  int blueShift;
  shift (0xFF0000, 0xFF00, 0xFF, redShift, greenShift, blueShift);

  unsigned int value;
  unsigned int r;
  unsigned int g;
  unsigned int b;

  switch (depth)
  {
    case 1:
	  value = *((unsigned char *) pixel);
	  break;
    case 2:
	  value = *((unsigned short *) pixel);
	  break;
    case 4:
    default:
	  value = *((unsigned int *) pixel);
	  break;
  }

  r = value & redMask;
  g = value & greenMask;
  b = value & blueMask;

  return   ((redShift   > 0 ? r << redShift   : r >> -redShift)   & 0xFF0000)
		 | ((greenShift > 0 ? g << greenShift : g >> -greenShift) &   0xFF00)
		 | ((blueShift  > 0 ? b << blueShift  : b >> -blueShift)  &     0xFF);
}

void
PixelFormatRGBBits::setRGB (void * pixel, unsigned int rgb) const
{
  unsigned int r = rgb & 0xFF0000;
  unsigned int g = rgb &   0xFF00;
  unsigned int b = rgb &     0xFF;

  int redShift;
  int greenShift;
  int blueShift;
  shift (0xFF0000, 0xFF00, 0xFF, redShift, greenShift, blueShift);

  unsigned int value =   ((redShift   > 0 ? r << redShift   : r >> -redShift)   & redMask)
	                   | ((greenShift > 0 ? g << greenShift : g >> -greenShift) & greenMask)
		               | ((blueShift  > 0 ? b << blueShift  : b >> -blueShift)  & blueMask);

  switch (depth)
  {
    case 1:
	  *((unsigned char *) pixel) = value;
	  break;
    case 2:
	  *((unsigned short *) pixel) = value;
	  break;
    case 4:
    default:
	  *((unsigned int *) pixel) = value;
	  break;
  }
}
